# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file
# --- Do not remove these imports ---
import json
import os
from datetime import datetime, timezone
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd
from pandas import DataFrame

from freqtrade.strategy import IStrategy, informative
import talib.abstract as ta
from technical import qtpylib


class GridBrainV1(IStrategy):
    """
    GridBrainV1 (Brain-only) — outputs a GridPlan JSON every 1h candle.
    - Does NOT trade.
    - Uses deterministic v1 rules (no ML yet, but fields are present).
    - Writes plan files under:
        user_data/grid_plans/<exchange>/<pair>/grid_plan.latest.json
        user_data/grid_plans/<exchange>/<pair>/grid_plan.<timestamp>.json

    Architecture:
      - Freqtrade/Strategy = Brain (signals + range + sizing + stop triggers)
      - Separate Executor places/maintains ladder orders on any CEX via CCXT
      - Separate Simulator replays candles/ticks and simulates fills accurately
    """

    INTERFACE_VERSION = 3

    # Brain outputs are hourly by design.
    # You can override via CLI/config, but defaults should be 1h.
    timeframe = "1h"
    can_short: bool = False

    # We deliberately do not want Freqtrade to manage exits/ROI/stoploss for trading.
    minimal_roi = {"0": 0.0}
    stoploss = -0.99
    trailing_stop = False

    process_only_new_candles = True
    startup_candle_count: int = 200  # need 7d lookback possible (168h) + buffer

    # ========= v1 locked defaults =========
    # Range builder
    primary_lookback_h = 48
    fallback_lookback_h_1 = 72
    fallback_lookback_h_2 = 168  # 7d on 1h candles

    atr_period = 14
    atr_pad_mult = 0.35

    # Regime gate
    adx_period = 14
    adx_4h_max = 22

    bb_window = 20
    bb_stds = 2.0
    bbw_nonexpand_mult = 1.05
    bbw_nonexpand_lookback = 3  # check last 3 bars

    rvol_window = 20
    rvol_spike = 1.8  # soft guard

    # Grid sizing
    target_step_pct = 0.007  # 0.70%
    n_min = 12
    n_max = 60

    # Width constraints
    min_width_pct = 0.035  # 3.5%
    wide_width_pct = 0.09  # 9%

    # Stop rules
    stop_confirm_bars = 2
    fast_stop_step_multiple = 1.0  # 1 * step beyond edge

    # Update policy
    soft_adjust_max_step_frac = 0.5  # if edges move < 0.5*step => "soft adjust" allowed

    # Capital policy (quote-only for now)
    grid_budget_pct = 0.70
    reserve_pct = 0.30

    # Output directory (inside container; user_data is mounted)
    plans_root_rel = "grid_plans"

    # -------- internal state (best-effort, per process) --------
    _last_written_ts_by_pair: Dict[str, int] = {}
    _last_plan_hash_by_pair: Dict[str, str] = {}

    # ========== Informative 4h for ADX ==========
    def informative_pairs(self):
        # Freqtrade will auto-cache this if used in populate_indicators via merge_informative_pair.
        return [(pair, "4h") for pair in self.dp.current_whitelist()] if self.dp else []

    @informative("4h")
    def populate_indicators_4h(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["adx_4h"] = ta.ADX(dataframe, timeperiod=self.adx_period)
        return dataframe

    # ========== Helpers ==========
    @staticmethod
    def _safe_float(x) -> Optional[float]:
        try:
            if x is None:
                return None
            if isinstance(x, (float, int, np.floating, np.integer)):
                if np.isnan(x):
                    return None
                return float(x)
            # pandas scalar
            xf = float(x)
            if np.isnan(xf):
                return None
            return xf
        except Exception:
            return None

    def _plan_dir(self, exchange_name: str, pair: str) -> str:
        # pair like "ETH/USDT" -> "ETH_USDT"
        safe_pair = pair.replace("/", "_").replace(":", "_")
        return os.path.join("/freqtrade/user_data", self.plans_root_rel, exchange_name, safe_pair)

    def _write_plan(self, exchange_name: str, pair: str, plan: dict) -> None:
        out_dir = self._plan_dir(exchange_name, pair)
        os.makedirs(out_dir, exist_ok=True)

        # Stable "latest" file + timestamped archive
        ts = plan.get("ts", datetime.now(timezone.utc).isoformat())
        ts_safe = ts.replace(":", "").replace("-", "").replace(".", "")
        latest_path = os.path.join(out_dir, "grid_plan.latest.json")
        archive_path = os.path.join(out_dir, f"grid_plan.{ts_safe}.json")

        payload = json.dumps(plan, indent=2, sort_keys=True)

        # Avoid rewriting identical payload every candle (noise reduction)
        payload_hash = str(hash(payload))
        last_hash = self._last_plan_hash_by_pair.get(pair)
        if last_hash == payload_hash:
            return

        with open(latest_path, "w", encoding="utf-8") as f:
            f.write(payload)
        with open(archive_path, "w", encoding="utf-8") as f:
            f.write(payload)

        self._last_plan_hash_by_pair[pair] = payload_hash

    def _compute_bbw(self, df: DataFrame) -> DataFrame:
        tp = qtpylib.typical_price(df)
        bb = qtpylib.bollinger_bands(tp, window=self.bb_window, stds=self.bb_stds)
        df["bb_mid"] = bb["mid"]
        df["bb_upper"] = bb["upper"]
        df["bb_lower"] = bb["lower"]
        df["bb_width"] = (df["bb_upper"] - df["bb_lower"]) / df["bb_mid"]
        return df

    def _range_candidate(self, df: DataFrame, lookback: int) -> Tuple[float, float]:
        """
        Returns (lo, hi) based on HighestHigh/LowestLow over 'lookback' bars.
        """
        hi = float(df["high"].rolling(lookback).max().iloc[-1])
        lo = float(df["low"].rolling(lookback).min().iloc[-1])
        return lo, hi

    def _build_range(self, df: DataFrame) -> Tuple[float, float, float, int, float]:
        """
        Builds the padded range with fallback:
          48h -> 72h -> 7d if width < min_width_pct.
        Returns: (lo_p, hi_p, width_pct, used_lookback, pad)
        """
        close = float(df["close"].iloc[-1])
        atr = float(df["atr_1h"].iloc[-1])
        pad = self.atr_pad_mult * atr

        def build_for(lb: int) -> Tuple[float, float, float]:
            lo, hi = self._range_candidate(df, lb)
            lo_p = lo - pad
            hi_p = hi + pad
            mid = (hi_p + lo_p) / 2.0
            width_pct = (hi_p - lo_p) / mid if mid > 0 else 0.0
            return lo_p, hi_p, width_pct

        lo_p, hi_p, w = build_for(self.primary_lookback_h)
        used = self.primary_lookback_h

        if w < self.min_width_pct and len(df) >= self.fallback_lookback_h_1:
            lo_p, hi_p, w = build_for(self.fallback_lookback_h_1)
            used = self.fallback_lookback_h_1

        if w < self.min_width_pct and len(df) >= self.fallback_lookback_h_2:
            lo_p, hi_p, w = build_for(self.fallback_lookback_h_2)
            used = self.fallback_lookback_h_2

        return lo_p, hi_p, w, used, pad

    def _grid_sizing(self, lo_p: float, hi_p: float) -> Tuple[int, float, float]:
        """
        Computes N and step_price from width and target_step_pct.
        Returns: (n_levels, step_price, step_pct_actual)
        """
        mid = (hi_p + lo_p) / 2.0
        width_pct = (hi_p - lo_p) / mid if mid > 0 else 0.0
        n_raw = int(np.floor(width_pct / self.target_step_pct)) if self.target_step_pct > 0 else self.n_min
        n_levels = int(np.clip(n_raw, self.n_min, self.n_max))
        step_price = (hi_p - lo_p) / float(n_levels) if n_levels > 0 else 0.0
        step_pct_actual = (step_price / mid) if mid > 0 else 0.0
        return n_levels, step_price, step_pct_actual

    def _bbw_nonexpanding(self, bbw: float, bbw_hist: np.ndarray) -> bool:
        """
        bbw_hist: array of last N bbw values excluding current (e.g. [bbw[-1], bbw[-2], bbw[-3]])
        Condition: bbw <= max(last N) * 1.05
        """
        if bbw is None or np.isnan(bbw):
            return False
        if bbw_hist is None or len(bbw_hist) == 0:
            return False
        m = float(np.nanmax(bbw_hist))
        if np.isnan(m):
            return False
        return bbw <= (m * self.bbw_nonexpand_mult)

    def _breakout_flags(self, close: float, lo_p: float, hi_p: float, step: float) -> Dict[str, bool]:
        close_outside_up = close > hi_p
        close_outside_dn = close < lo_p

        fast_up = (close - hi_p) > (self.fast_stop_step_multiple * step)
        fast_dn = (lo_p - close) > (self.fast_stop_step_multiple * step)

        return {
            "close_outside_up": close_outside_up,
            "close_outside_dn": close_outside_dn,
            "fast_outside_up": fast_up,
            "fast_outside_dn": fast_dn,
        }

    # ========== Main indicators + plan write ==========
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        pair = metadata.get("pair", "UNKNOWN/UNKNOWN")

        # 1h indicators (on base timeframe)
        dataframe["atr_1h"] = ta.ATR(dataframe, timeperiod=self.atr_period)
        dataframe["rvol_1h"] = dataframe["volume"] / dataframe["volume"].rolling(self.rvol_window).mean()

        # Donchian width proxy (48h)
        donch_hi = dataframe["high"].rolling(self.primary_lookback_h).max()
        donch_lo = dataframe["low"].rolling(self.primary_lookback_h).min()
        dataframe["donch_width_48h"] = (donch_hi - donch_lo) / dataframe["close"]

        # BB width
        dataframe = self._compute_bbw(dataframe)

        # Merge 4h ADX informative
        if self.dp:
            # merge_informative_pair is imported in template, but we use decorator-based informative.
            # Freqtrade will suffix informative columns automatically for decorator-based output.
            # For safety, we fallback if it doesn't exist.
            pass

        # 4h adx column name will be "adx_4h" in informative df, typically merged as "adx_4h_4h"
        # Depending on Freqtrade version, suffix can differ. We'll detect dynamically.
        adx_col_candidates = [c for c in dataframe.columns if c.startswith("adx_4h")]
        adx4h_col = None
        if "adx_4h_4h" in dataframe.columns:
            adx4h_col = "adx_4h_4h"
        elif "adx_4h" in dataframe.columns:
            adx4h_col = "adx_4h"
        elif len(adx_col_candidates) > 0:
            # pick the last candidate
            adx4h_col = adx_col_candidates[-1]

        # If we still don't have 4h ADX (e.g., no informative merge), compute a 4h-ish proxy:
        # Resample 1h to 4h using last/ohlc aggregation.
        if adx4h_col is None or dataframe[adx4h_col].isna().all():
            # Build 4h candles from 1h
            df = dataframe.copy()
            df = df.set_index("date") if "date" in df.columns else df
            if isinstance(df.index, pd.DatetimeIndex):
                o = df["open"].resample("4H").first()
                h = df["high"].resample("4H").max()
                l = df["low"].resample("4H").min()
                c = df["close"].resample("4H").last()
                v = df["volume"].resample("4H").sum()
                df4 = pd.DataFrame({"open": o, "high": h, "low": l, "close": c, "volume": v}).dropna()
                df4["adx_4h_proxy"] = ta.ADX(df4, timeperiod=self.adx_period)
                # forward-fill to 1h index
                df["adx_4h_proxy"] = df4["adx_4h_proxy"].reindex(df.index, method="ffill")
                dataframe["adx_4h_proxy"] = df["adx_4h_proxy"].values
                adx4h_col = "adx_4h_proxy"

        # ===== Build plan only on the latest candle (and only if enough data) =====
        if len(dataframe) < self.startup_candle_count:
            return dataframe

        last = dataframe.iloc[-1]
        close = float(last["close"])
        bbw = self._safe_float(last.get("bb_width"))
        rvol = self._safe_float(last.get("rvol_1h"))
        adx4h = self._safe_float(last.get(adx4h_col)) if adx4h_col else None

        # BBW non-expansion check: compare current bbw to max(previous 3)
        bbw_hist = []
        for i in range(1, self.bbw_nonexpand_lookback + 1):
            if len(dataframe) > i:
                bbw_hist.append(self._safe_float(dataframe["bb_width"].iloc[-1 - i]))
        bbw_hist = np.array([x for x in bbw_hist if x is not None], dtype=float)

        bbw_nonexp = self._bbw_nonexpanding(bbw if bbw is not None else np.nan, bbw_hist)
        adx_ok = (adx4h is not None) and (adx4h <= self.adx_4h_max)
        rule_range_ok = bool(adx_ok and bbw_nonexp)

        rvol_spike = (rvol is not None) and (rvol >= self.rvol_spike)

        # Build range + grid sizing
        lo_p, hi_p, width_pct, used_lb, pad = self._build_range(dataframe)
        n_levels, step_price, step_pct_actual = self._grid_sizing(lo_p, hi_p)

        # Breakout conditions using rule-based logic
        flags = self._breakout_flags(close, lo_p, hi_p, step_price)

        # 2 consecutive closes outside: use last two closes
        close_1 = float(dataframe["close"].iloc[-1])
        close_2 = float(dataframe["close"].iloc[-2])

        two_up = (close_1 > hi_p) and (close_2 > hi_p)
        two_dn = (close_1 < lo_p) and (close_2 < lo_p)

        stop_rule = bool(two_up or two_dn or flags["fast_outside_up"] or flags["fast_outside_dn"])

        # v1 "action" logic (rule-only; ML comes later)
        # - If stop rule triggers => STOP
        # - Else if range ok and not obvious spike => START suggestion
        # - Else HOLD
        if stop_rule:
            action = "STOP"
        elif rule_range_ok and (not rvol_spike):
            action = "START"
        else:
            action = "HOLD"

        # "Optional stuff" included in plan (even if not enforced yet):
        # - soft_adjust policy thresholds
        # - wide range flag (we don't reject yet)
        is_wide = width_pct >= self.wide_width_pct

        # ML placeholders (FreqAI will populate later)
        p_range = None
        p_breakout = None

        # Exchange name from config if available; otherwise fallback
        ex_name = (self.config.get("exchange", {}) or {}).get("name", "unknown")

        # Timestamp in local runtime (UTC ISO); executor can convert as needed
        ts = datetime.now(timezone.utc).isoformat()

        # Capital policy: quote-only for now
        # NOTE: We cannot read equity reliably in backtesting/live here without extra hooks.
        # Executor will fill actual balances; Brain gives policy percentages.
        plan = {
            "ts": ts,
            "exchange": ex_name,
            "symbol": pair,
            "action": action,
            "range": {
                "low": float(lo_p),
                "high": float(hi_p),
                "pad": float(pad),
                "lookback_hours_used": int(used_lb),
                "width_pct": float(width_pct),
                "is_wide": bool(is_wide),
            },
            "grid": {
                "n_levels": int(n_levels),
                "target_step_pct": float(self.target_step_pct),
                "step_pct_actual": float(step_pct_actual),
                "step_price": float(step_price),
                "post_only": True,  # executor should try maker first
            },
            "signals": {
                "adx_4h": adx4h,
                "bb_width_1h": bbw,
                "bb_width_nonexpanding": bool(bbw_nonexp),
                "rvol_1h": rvol,
                "rvol_spike": bool(rvol_spike),
                "rule_range_ok": bool(rule_range_ok),
                "p_range": p_range,
                "p_breakout": p_breakout,
            },
            "risk": {
                "stop_confirm_bars": int(self.stop_confirm_bars),
                "fast_stop_step_multiple": float(self.fast_stop_step_multiple),
                "stop_rule_triggered": bool(stop_rule),
                "stop_reasons": {
                    "two_consecutive_outside_up": bool(two_up),
                    "two_consecutive_outside_dn": bool(two_dn),
                    "fast_outside_up": bool(flags["fast_outside_up"]),
                    "fast_outside_dn": bool(flags["fast_outside_dn"]),
                    "close_outside_up": bool(flags["close_outside_up"]),
                    "close_outside_dn": bool(flags["close_outside_dn"]),
                },
                # Policy (we can refine later):
                "stop_policy": "DANGER_TO_QUOTE",
            },
            "update_policy": {
                "hourly_check": True,
                "event_driven": True,
                "soft_adjust_max_step_frac": float(self.soft_adjust_max_step_frac),
            },
            "capital_policy": {
                "mode": "QUOTE_ONLY",
                "grid_budget_pct": float(self.grid_budget_pct),
                "reserve_pct": float(self.reserve_pct),
                # Executor decides actual order size, rounding and min-notional checks
            },
            "notes": {
                "brain_mode": "rule_only_v1",
                "ml": "freqai_placeholders_present",
            },
        }

        # Write plan file (only once per candle timestamp)
        # Use candle time as de-dup key if present
        candle_ts = None
        if "date" in dataframe.columns:
            candle_ts = int(pd.Timestamp(last["date"]).timestamp())
        elif isinstance(dataframe.index, pd.DatetimeIndex):
            candle_ts = int(pd.Timestamp(dataframe.index[-1]).timestamp())

        if candle_ts is not None:
            last_written = self._last_written_ts_by_pair.get(pair)
            if last_written != candle_ts:
                self._write_plan(ex_name, pair, plan)
                self._last_written_ts_by_pair[pair] = candle_ts
        else:
            # fallback: just write (hash guard prevents spam)
            self._write_plan(ex_name, pair, plan)

        return dataframe

    # ========= Trading signals intentionally disabled =========
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["enter_long"] = 0
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["exit_long"] = 0
        return dataframe