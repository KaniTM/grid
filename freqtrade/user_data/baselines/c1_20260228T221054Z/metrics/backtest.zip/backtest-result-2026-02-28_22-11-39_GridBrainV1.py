# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa: F401
# isort: skip_file
# ruff: noqa
from dataclasses import dataclass

# --- Do not remove these imports ---
import json
import math
import os
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Optional, Tuple, List, Iterable
from uuid import uuid4
import numpy as np
import pandas as pd
from pandas import DataFrame

from freqtrade.configuration import Configuration as Config
from freqtrade.strategy import IStrategy, informative
import talib.abstract as ta
from core.atomic_json import write_json_atomic
from technical import qtpylib
from core.enums import (
    BlockReason,
    EventType,
    MaterialityClass,
    ModuleName,
    Severity,
    StopReason,
    WarningCode,
    category_of_code,
    is_canonical_code,
)
from core.plan_signature import (
    PLAN_SCHEMA_VERSION,
    PLANNER_VERSION_DEFAULT,
    compute_plan_hash,
    material_plan_changed_fields,
    material_plan_diff_snapshot,
    material_plan_payload,
)
from core.schema_validation import validate_schema
from analytics.execution_cost_calibrator import (
    EmpiricalCostCalibrator as ExternalEmpiricalCostCalibrator,
)
from data.data_quality_assessor import assess_data_quality
from execution.capacity_guard import load_capacity_hint_state
from planner.replan_policy import ReplanThresholds, evaluate_replan_materiality
from planner.start_stability import evaluate_start_stability
from planner.volatility_policy_adapter import (
    compute_n_level_bounds,
    compute_volatility_policy_view,
)
from planner.structure.order_blocks import (
    OrderBlockConfig,
    build_order_block_snapshot,
)
from planner.structure.liquidity_sweeps import (
    LiquiditySweepConfig,
    analyze_liquidity_sweeps,
)
from risk.meta_drift_guard import MetaDriftGuard as ExternalMetaDriftGuard

LOOKBACK_SUFFIXES = ("_bars", "_lookback", "_window", "_period")
REQUIRED_OHLC_COLUMNS = ("date", "open", "high", "low", "close", "volume")
FEATURE_CONTRACT_COLUMNS = (
    "close",
    "high",
    "low",
    "atr_15m",
    "rsi_15m",
    "bb_mid_15m",
    "bb_mid_1h",
    "bb_mid_4h",
    "adx_4h",
    "vwap_15m",
)


def _normalize_runtime_value(value: object) -> object:
    if isinstance(value, (np.generic,)):
        return value.item()
    if isinstance(value, (np.ndarray,)):
        return value.tolist()
    if isinstance(value, list):
        return [_normalize_runtime_value(v) for v in value]
    if isinstance(value, tuple):
        return tuple(_normalize_runtime_value(v) for v in value)
    if isinstance(value, dict):
        return {str(k): _normalize_runtime_value(v) for k, v in value.items()}
    if isinstance(value, (int, float, str, bool)):
        return value
    return str(value)


class EmpiricalCostCalibrator:
    """
    Lightweight rolling empirical cost estimator.

    The estimator can run off coarse proxy inputs when fill/order logs are unavailable,
    while still allowing conservative cost-floor escalation when reliable samples exist.
    """

    def __init__(self, window: int) -> None:
        self._window = max(int(window), 1)
        self._samples_by_pair: Dict[str, deque] = {}
        self._bars_seen_by_pair: Dict[str, int] = {}
        self._last_update_bar_by_pair: Dict[str, int] = {}

    def _samples(self, pair: str) -> deque:
        samples = self._samples_by_pair.get(pair)
        if samples is None or samples.maxlen != self._window:
            samples = deque(maxlen=self._window)
            self._samples_by_pair[pair] = samples
        return samples

    def observe(
        self,
        pair: str,
        *,
        spread_pct: Optional[float],
        adverse_selection_pct: Optional[float],
        retry_reject_rate: Optional[float],
        missed_fill_rate: Optional[float],
        retry_penalty_pct: float,
        missed_fill_penalty_pct: float,
        recommended_floor_pct: Optional[float] = None,
    ) -> Dict[str, Optional[float]]:
        bar_idx = int(self._bars_seen_by_pair.get(pair, 0) + 1)
        self._bars_seen_by_pair[pair] = bar_idx

        spread = float(max(spread_pct or 0.0, 0.0))
        adverse = float(max(adverse_selection_pct or 0.0, 0.0))
        retry_rate = float(np.clip(retry_reject_rate or 0.0, 0.0, 1.0))
        missed_rate = float(np.clip(missed_fill_rate or 0.0, 0.0, 1.0))
        retry_penalty = float(max(retry_penalty_pct, 0.0) * retry_rate)
        missed_penalty = float(max(missed_fill_penalty_pct, 0.0) * missed_rate)
        recommended = (
            float(max(recommended_floor_pct, 0.0))
            if recommended_floor_pct is not None
            else None
        )

        sample = {
            "spread_pct": float(spread),
            "adverse_selection_pct": float(adverse),
            "retry_reject_rate": float(retry_rate),
            "missed_fill_rate": float(missed_rate),
            "retry_penalty_pct": float(retry_penalty),
            "missed_fill_penalty_pct": float(missed_penalty),
            "total_pct": float(spread + adverse + retry_penalty + missed_penalty),
            "recommended_floor_pct": recommended,
            "bar_idx": int(bar_idx),
        }
        self._samples(pair).append(sample)
        self._last_update_bar_by_pair[pair] = bar_idx
        return sample

    def snapshot(
        self,
        pair: str,
        *,
        percentile: float,
        min_samples: int,
        stale_bars: int,
    ) -> Dict[str, object]:
        samples = list(self._samples(pair))
        sample_count = int(len(samples))
        p = float(np.clip(percentile, 0.0, 100.0))
        bars_seen = int(self._bars_seen_by_pair.get(pair, 0))
        last_update = self._last_update_bar_by_pair.get(pair)
        bars_since_update = (
            int(max(bars_seen - int(last_update), 0))
            if last_update is not None
            else None
        )

        out: Dict[str, object] = {
            "sample_count": int(sample_count),
            "bars_seen": int(bars_seen),
            "bars_since_update": int(bars_since_update) if bars_since_update is not None else None,
            "stale": True,
            "spread_pct_percentile": None,
            "adverse_selection_pct_percentile": None,
            "retry_reject_rate_percentile": None,
            "missed_fill_rate_percentile": None,
            "retry_penalty_pct_percentile": None,
            "missed_fill_penalty_pct_percentile": None,
            "total_cost_pct_percentile": None,
            "recommended_floor_pct_percentile": None,
            "empirical_floor_pct": None,
        }

        if sample_count == 0:
            return out

        def pct(name: str) -> Optional[float]:
            vals = [
                float(item[name])
                for item in samples
                if item.get(name) is not None and np.isfinite(float(item[name]))
            ]
            if not vals:
                return None
            return float(np.percentile(np.asarray(vals, dtype=float), p))

        spread_pct_p = pct("spread_pct")
        adverse_pct_p = pct("adverse_selection_pct")
        retry_rate_p = pct("retry_reject_rate")
        missed_rate_p = pct("missed_fill_rate")
        retry_penalty_p = pct("retry_penalty_pct")
        missed_penalty_p = pct("missed_fill_penalty_pct")
        total_cost_p = pct("total_pct")
        recommended_p = pct("recommended_floor_pct")

        empirical_floor_candidates = [x for x in [total_cost_p, recommended_p] if x is not None]
        empirical_floor = float(max(empirical_floor_candidates)) if empirical_floor_candidates else None

        stale = bool(
            sample_count < max(int(min_samples), 1)
            or (bars_since_update is not None and bars_since_update > max(int(stale_bars), 0))
        )

        out.update(
            {
                "stale": bool(stale),
                "spread_pct_percentile": spread_pct_p,
                "adverse_selection_pct_percentile": adverse_pct_p,
                "retry_reject_rate_percentile": retry_rate_p,
                "missed_fill_rate_percentile": missed_rate_p,
                "retry_penalty_pct_percentile": retry_penalty_p,
                "missed_fill_penalty_pct_percentile": missed_penalty_p,
                "total_cost_pct_percentile": total_cost_p,
                "recommended_floor_pct_percentile": recommended_p,
                "empirical_floor_pct": empirical_floor,
            }
        )
        return out


class MetaDriftGuard:
    """Lightweight per-pair drift detector using smoothed z-score + CUSUM/Page-Hinkley style accumulators."""

    def __init__(self, window: int, smoothing_alpha: float) -> None:
        self._window = max(int(window), 8)
        self._alpha = float(np.clip(smoothing_alpha, 0.01, 1.0))
        self._state_by_pair: Dict[str, Dict[str, object]] = {}

    def reset_pair(self, pair: str) -> None:
        self._state_by_pair.pop(pair, None)

    def _pair_state(self, pair: str) -> Dict[str, object]:
        state = self._state_by_pair.get(pair)
        if state is None:
            state = {
                "bars_seen": 0,
                "channels": {},
            }
            self._state_by_pair[pair] = state
        return state

    def observe(
        self,
        pair: str,
        channels: Dict[str, Optional[float]],
        *,
        min_samples: int,
        eps: float,
        z_soft: float,
        z_hard: float,
        cusum_k_sigma: float,
        cusum_soft: float,
        cusum_hard: float,
        ph_delta_sigma: float,
        ph_soft: float,
        ph_hard: float,
        soft_min_channels: int,
        hard_min_channels: int,
    ) -> Dict[str, object]:
        pair_state = self._pair_state(pair)
        pair_state["bars_seen"] = int(pair_state.get("bars_seen", 0) + 1)
        channels_state = pair_state.setdefault("channels", {})

        channel_details: Dict[str, Dict[str, object]] = {}
        ready_channels: List[str] = []
        soft_channels: List[str] = []
        hard_channels: List[str] = []

        for name, raw in channels.items():
            value = GridBrainV1Core._safe_float(raw)
            state = channels_state.get(name)
            if not isinstance(state, dict):
                state = {
                    "ema": None,
                    "history": deque(maxlen=self._window),
                    "cusum_pos": 0.0,
                    "cusum_neg": 0.0,
                    "ph_pos": 0.0,
                    "ph_neg": 0.0,
                }
                channels_state[name] = state

            if value is None or not np.isfinite(value):
                channel_details[name] = {
                    "available": False,
                    "value": None,
                    "smoothed": None,
                    "baseline_mean": None,
                    "baseline_std": None,
                    "z_score": None,
                    "cusum_score": None,
                    "page_hinkley_score": None,
                    "soft": False,
                    "hard": False,
                }
                continue

            prev_ema = GridBrainV1Core._safe_float(state.get("ema"))
            ema = float(value) if prev_ema is None else float((self._alpha * value) + ((1.0 - self._alpha) * prev_ema))
            history = state.get("history")
            if not isinstance(history, deque) or history.maxlen != self._window:
                history = deque(history if isinstance(history, (list, tuple, deque)) else [], maxlen=self._window)
                state["history"] = history

            baseline_ready = len(history) >= max(int(min_samples), 1)
            baseline_mean = None
            baseline_std = None
            z_score = None
            cusum_score = None
            page_hinkley_score = None
            soft_hit = False
            hard_hit = False

            if baseline_ready:
                hist_arr = np.asarray(list(history), dtype=float)
                if hist_arr.size > 0:
                    baseline_mean = float(np.mean(hist_arr))
                    baseline_std = float(max(np.std(hist_arr, ddof=1), max(float(eps), 1e-12)))
                    delta = float(ema - baseline_mean)
                    z_score = float(abs(delta) / baseline_std)

                    cusum_pos = float(max(float(state.get("cusum_pos", 0.0)) + delta - (float(cusum_k_sigma) * baseline_std), 0.0))
                    cusum_neg = float(max(float(state.get("cusum_neg", 0.0)) - delta - (float(cusum_k_sigma) * baseline_std), 0.0))
                    state["cusum_pos"] = cusum_pos
                    state["cusum_neg"] = cusum_neg
                    cusum_score = float(max(cusum_pos, cusum_neg) / baseline_std)

                    ph_pos = float(max(float(state.get("ph_pos", 0.0)) + delta - (float(ph_delta_sigma) * baseline_std), 0.0))
                    ph_neg = float(max(float(state.get("ph_neg", 0.0)) - delta - (float(ph_delta_sigma) * baseline_std), 0.0))
                    state["ph_pos"] = ph_pos
                    state["ph_neg"] = ph_neg
                    page_hinkley_score = float(max(ph_pos, ph_neg) / baseline_std)

                    soft_hit = bool(
                        z_score >= float(z_soft)
                        or cusum_score >= float(cusum_soft)
                        or page_hinkley_score >= float(ph_soft)
                    )
                    hard_hit = bool(
                        z_score >= float(z_hard)
                        or cusum_score >= float(cusum_hard)
                        or page_hinkley_score >= float(ph_hard)
                    )
                    ready_channels.append(str(name))
            else:
                state["cusum_pos"] = 0.0
                state["cusum_neg"] = 0.0
                state["ph_pos"] = 0.0
                state["ph_neg"] = 0.0

            state["ema"] = float(ema)
            history.append(float(ema))

            if soft_hit:
                soft_channels.append(str(name))
            if hard_hit:
                hard_channels.append(str(name))

            channel_details[name] = {
                "available": True,
                "value": float(value),
                "smoothed": float(ema),
                "baseline_mean": baseline_mean,
                "baseline_std": baseline_std,
                "z_score": z_score,
                "cusum_score": cusum_score,
                "page_hinkley_score": page_hinkley_score,
                "soft": bool(soft_hit),
                "hard": bool(hard_hit),
            }

        soft_unique = list(dict.fromkeys(soft_channels))
        hard_unique = list(dict.fromkeys(hard_channels))
        severity = "none"
        if len(hard_unique) >= max(int(hard_min_channels), 1):
            severity = "hard"
        elif len(soft_unique) >= max(int(soft_min_channels), 1):
            severity = "soft"
        drift_channels = hard_unique if severity == "hard" else soft_unique if severity == "soft" else []

        return {
            "bars_seen": int(pair_state.get("bars_seen", 0)),
            "min_samples": int(max(int(min_samples), 1)),
            "ready_channels": ready_channels,
            "channels": channel_details,
            "soft_channels": soft_unique,
            "hard_channels": hard_unique,
            "soft_count": int(len(soft_unique)),
            "hard_count": int(len(hard_unique)),
            "severity": str(severity),
            "drift_detected": bool(severity in {"soft", "hard"}),
            "drift_channels": drift_channels,
        }


@dataclass(frozen=True)
class GridBrainRuntimeSnapshot:
    timestamp: int
    knobs: Dict[str, object]
    lookbacks: Dict[str, int]

    @classmethod
    def from_strategy(
        cls, strategy: "GridBrainV1Core", lookback_summary: "GridBrainLookbackSummary"
    ) -> "GridBrainRuntimeSnapshot":
        knobs: Dict[str, object] = {}
        for name, value in vars(strategy.__class__).items():
            if name.startswith("_"):
                continue
            if name in ("__module__", "__doc__", "INTERFACE_VERSION"):
                continue
            if callable(value):
                continue
            knobs[name] = _normalize_runtime_value(value)
        knobs["timeframe"] = getattr(strategy, "timeframe", None)
        lookbacks = dict(lookback_summary.lookbacks) if lookback_summary else {}
        return cls(
            timestamp=int(datetime.now(timezone.utc).timestamp()),
            knobs=knobs,
            lookbacks=lookbacks,
        )

    def as_dict(self) -> Dict[str, object]:
        return {"timestamp": self.timestamp, "knobs": self.knobs, "lookbacks": self.lookbacks}


@dataclass(frozen=True)
class GridBrainLookbackSummary:
    lookbacks: Dict[str, int]
    buffer: int

    @classmethod
    def from_strategy(cls, strategy: "GridBrainV1Core", buffer: int) -> "GridBrainLookbackSummary":
        lookbacks: Dict[str, int] = {}
        if buffer < 0:
            buffer = 0
        for attr in dir(strategy.__class__):
            if attr.startswith("_"):
                continue
            if not attr.endswith(LOOKBACK_SUFFIXES):
                continue
            value = getattr(strategy.__class__, attr, None)
            if isinstance(value, (int, float)):
                lookbacks[attr] = max(int(math.ceil(float(value))), 1)
        return cls(lookbacks=lookbacks, buffer=buffer)

    def required_candles(self) -> int:
        if not self.lookbacks:
            return self.buffer
        return int(max(self.lookbacks.values()) + self.buffer)


class GridBrainV1Core(IStrategy):
    """
    GridBrainV1 (Brain-only) — outputs a GridPlan JSON every 15m candle.
    - Does NOT trade.
    - Uses deterministic v1 rules (no ML yet, but fields are present).
    - Writes plan files under:
        user_data/grid_plans/<exchange>/<pair>/grid_plan.latest.json
        user_data/grid_plans/<exchange>/<pair>/grid_plan.<timestamp>.json
      - Optional override for automation: GRID_PLANS_ROOT_REL

    Architecture:
      - Freqtrade/Strategy = Brain (signals + range + sizing + stop triggers)
      - Separate Executor places/maintains ladder orders on any CEX via CCXT
      - Separate Simulator replays candles/ticks and simulates fills accurately
    """

    def __init__(self, config: Config) -> None:
        super().__init__(config)
        self._chop_score_state_by_pair: Dict[str, bool] = {}
        self._neutral_bands_loaded = False
        self._neutral_bands_map: Dict[Tuple[str, str], Dict[str, object]] = {}
        self._neutral_bands_run_id = self._determine_regime_bands_run_id()
        self._feature_contract_logged_pairs: Dict[str, bool] = {}
        self._lookback_summary = GridBrainLookbackSummary.from_strategy(
            self, buffer=self.lookback_buffer
        )
        self.startup_candle_count = max(self._lookback_summary.required_candles(), 1)
        self._runtime_snapshot = GridBrainRuntimeSnapshot.from_strategy(
            self, self._lookback_summary
        )
        self._empirical_cost_calibrator = ExternalEmpiricalCostCalibrator(
            self.empirical_cost_window
        )
        self._execution_cost_artifact_cache_by_pair: Dict[str, Dict[str, object]] = {}
        self._execution_cost_artifact_mtime_by_pair: Dict[str, float] = {}
        self._meta_drift_guard = ExternalMetaDriftGuard(
            self.meta_drift_guard_window,
            self.meta_drift_guard_smoothing_alpha,
        )

    INTERFACE_VERSION = 3
    STOP_REASON_TREND_ADX = "STOP_TREND_ADX"
    STOP_REASON_VOL_EXPANSION = "STOP_VOL_EXPANSION"
    STOP_REASON_BOX_BREAK = "STOP_BOX_BREAK"
    STOP_REASON_META_DRIFT_HARD = str(StopReason.STOP_META_DRIFT_HARD)

    # ===== MTF PLAN ALIGNMENT =====
    # 15m: box + execution triggers
    # 1h : volatility / MA distance / vol gates
    # 4h : regime ADX
    timeframe = "15m"
    can_short: bool = False

    minimal_roi = {"0": 0.0}
    stoploss = -0.99
    trailing_stop = False

    process_only_new_candles = True
    lookback_buffer: int = 32

    # startup will be computed based on the heaviest lookback + buffer
    startup_candle_count: int = 1

    # Data quality enforcement (Section 4.2)
    data_quality_expected_candle_seconds: int = 900
    data_quality_gap_multiplier: float = 1.5
    data_quality_max_stale_minutes: float = 60.0
    data_quality_zero_volume_streak_bars: int = 4

    # Materiality Before Churn thresholds (Section 3.6)
    materiality_epoch_bars: int = 2
    materiality_box_mid_shift_max_step_frac: float = 0.5
    materiality_box_width_change_pct: float = 5.0
    materiality_tp_shift_max_step_frac: float = 0.75
    materiality_sl_shift_max_step_frac: float = 0.75

    poc_acceptance_enabled: bool = True
    poc_acceptance_lookback_bars: int = 8
    poc_alignment_enabled: bool = True
    poc_alignment_strict_enabled: bool = True
    poc_alignment_lookback_bars: int = 8
    poc_alignment_max_step_diff: float = 1.0
    poc_alignment_max_width_frac: float = 0.05

    # ========= v1 locked defaults =========
    # Box builder (15m)
    box_lookback_24h_bars = 96     # 24h on 15m
    box_lookback_48h_bars = 192    # 48h on 15m
    box_lookback_18h_bars = 72
    box_lookback_12h_bars = 48
    extremes_7d_bars = 7 * 24 * 4  # 672
    box_overlap_prune_threshold = 0.6
    box_overlap_history = 4
    box_band_overlap_required = 0.6
    box_band_adx_allow = 25.0
    box_band_rvol_allow = 1.2
    box_envelope_ratio_max = 2.0
    box_envelope_adx_threshold = 25.0
    box_envelope_rvol_threshold = 1.2
    session_box_pad_shrink_pct = 0.2

    # Structural breakout guard
    breakout_lookback_bars = 14
    breakout_block_bars = 20
    breakout_override_allowed = True
    breakout_straddle_step_buffer_frac = 0.25
    breakout_reason_code = BlockReason.BLOCK_FRESH_BREAKOUT
    min_range_len_bars = 20
    breakout_confirm_bars = 2
    breakout_confirm_buffer_mode = "step"  # step | atr | pct | abs
    breakout_confirm_buffer_value = 1.0

    atr_period_15m = 20
    atr_pad_mult = 0.35

    rsi_period_15m = 14
    rsi_min = 40
    rsi_max = 60

    # Regime gate (4h ADX)
    adx_period = 14
    adx_4h_max = 22

    # 1h gates
    ema_fast = 50
    ema_slow = 100
    ema_dist_max_frac = 0.012  # 1.2%

    bb_window = 20
    bb_stds = 2.0
    bbw_pct_lookback_1h = 252
    bbw_1h_pct_max = 50.0
    bbw_nonexp_lookback_bars = 3
    bbw_nonexp_tolerance_frac = 0.01
    context_7d_hard_veto = True

    vol_sma_window = 20
    vol_spike_mult = 1.5  # 1h volume <= 1.5 * SMA20
    rvol_window_15m = 20
    rvol_15m_max = 1.5

    # VRVP (fixed-window volume profile)
    vrvp_lookback_bars = 96
    vrvp_bins = 48
    vrvp_value_area_pct = 0.70
    vrvp_poc_outside_box_max_frac = 0.005
    vrvp_max_box_shift_frac = 0.005
    vrvp_reject_if_still_outside = True
    fallback_poc_estimator_enabled = True
    fallback_poc_lookback_bars = 96

    # BBWP + squeeze gates
    bbwp_enabled = True
    bbwp_lookback_s = 252  # 15m
    bbwp_lookback_m = 252  # 1h
    bbwp_lookback_l = 252  # 4h
    bbwp_s_max = 35.0
    bbwp_m_max = 50.0
    bbwp_l_max = 60.0
    bbwp_veto_pct = 90.0
    bbwp_cooloff_trigger_pct = 98.0
    bbwp_cooloff_release_s = 50.0
    bbwp_cooloff_release_m = 60.0
    bbwp_nonexp_bars = 3
    squeeze_enabled = True
    squeeze_require_on_1h = False
    squeeze_momentum_block_enabled = True
    squeeze_tp_nudge_enabled = True
    squeeze_tp_nudge_step_multiple = 0.5
    kc_atr_mult = 1.5

    # Optional strictness gates
    band_slope_veto_enabled = False
    band_slope_veto_bars = 20
    band_slope_veto_pct = 0.0035
    drift_slope_veto_enabled = False
    excursion_asymmetry_veto_enabled = False
    excursion_asymmetry_min_ratio = 0.7
    excursion_asymmetry_max_ratio = 1.5
    hvp_enabled = False
    hvp_lookback_bars = 32
    hvp_sma_bars = 8
    funding_filter_enabled = False
    funding_filter_pct = 0.0005

    # instrumentation lookbacks
    instrumentation_er_lookback = 20
    instrumentation_chop_lookback = 20
    instrumentation_di_flip_lookback = 50
    instrumentation_wickiness_lookback = 50
    instrumentation_containment_lookback = 96
    instrumentation_atr_pct_percentile = 10.0
    instrumentation_atr_pct_lookback = 96

    # os_dev regime state
    os_dev_enabled = True
    os_dev_n_strike = 2
    os_dev_range_band = 0.75
    os_dev_persist_bars = 24
    os_dev_rvol_max = 1.2
    os_dev_history_bars = 960

    # Micro-VAP + HVN/LVN
    micro_vap_enabled = True
    micro_vap_lookback_bars = 96
    micro_vap_bins = 64
    micro_hvn_quantile = 0.80
    micro_lvn_quantile = 0.20
    micro_extrema_count = 6
    micro_lvn_corridor_steps = 1.0
    micro_void_slope_threshold = 0.55

    # FVG stack (Defensive + IMFVG + Session FVG)
    fvg_enabled = True
    fvg_lookback_bars = 192
    fvg_min_gap_atr = 0.05
    fvg_straddle_veto_steps = 0.75
    fvg_position_avg_count = 8

    imfvg_enabled = True
    imfvg_mitigated_relax = True

    defensive_fvg_enabled = True
    defensive_fvg_min_gap_atr = 0.20
    defensive_fvg_body_frac = 0.55
    defensive_fvg_fresh_bars = 16

    session_fvg_enabled = True
    session_fvg_inside_gate = True
    session_fvg_pause_bars = 0

    # MRVD (multi-range volume distribution: day/week/month)
    mrvd_enabled = True
    mrvd_bins = 64
    mrvd_value_area_pct = 0.70
    mrvd_day_lookback_bars = 96         # 1 day on 15m
    mrvd_week_lookback_bars = 7 * 96    # 1 week on 15m
    mrvd_month_lookback_bars = 30 * 96  # 30 days on 15m (falls back to available bars)
    mrvd_required_overlap_count = 2     # >= 2/3 periods
    mrvd_va_overlap_min_frac = 0.10
    mrvd_near_poc_steps = 1.0
    mrvd_drift_guard_enabled = True
    mrvd_drift_guard_steps = 0.75

    # CVD (divergence + BOS nudges)
    cvd_enabled = True
    cvd_lookback_bars = 192
    cvd_pivot_left = 3
    cvd_pivot_right = 3
    cvd_divergence_max_age_bars = 64
    cvd_near_value_steps = 1.0
    cvd_bos_lookback = 20
    cvd_bos_freeze_bars = 4
    cvd_rung_bias_strength = 0.35

    # FreqAI confidence overlay (soft nudges; deterministic loop remains primary)
    freqai_overlay_enabled = False
    freqai_overlay_gate_mode = "advisory"  # advisory | strict
    freqai_overlay_strict_predict = False
    freqai_overlay_confidence_min = 0.55
    freqai_overlay_breakout_scale = 0.02
    freqai_overlay_breakout_quick_tp_thresh = 0.70
    freqai_overlay_rung_edge_cut_max = 0.45

    # Rung density bias (executor/simulator consume these weights)
    rung_weight_hvn_boost = 1.0
    rung_weight_lvn_penalty = 0.40
    rung_weight_min = 0.20
    rung_weight_max = 3.00

    # Grid sizing (cost-aware)
    # Net target per step (>=0.40%), gross = net + fee + spread
    target_net_step_pct = 0.0040
    est_fee_pct = 0.0020     # default 0.20% (tweak per exchange/VIP)
    est_spread_pct = 0.0005  # default 0.05% majors
    majors_gross_step_floor_pct = 0.0065
    n_min = 6
    n_max = 12
    n_volatility_adapter_enabled = True
    n_volatility_adapter_strength = 1.0
    volatility_min_step_buffer_bps = 0.0

    # Empirical cost calibration (Section 13.2).
    empirical_cost_enabled = True
    empirical_cost_window = 256
    empirical_cost_min_samples = 24
    empirical_cost_stale_bars = 96
    empirical_cost_percentile = 90.0
    empirical_cost_conservative_mode = True
    empirical_cost_require_live_samples = True
    empirical_cost_min_live_samples = 0
    empirical_spread_proxy_scale = 0.10
    empirical_adverse_selection_scale = 0.25
    empirical_retry_penalty_pct = 0.0010
    empirical_missed_fill_penalty_pct = 0.0010
    empirical_cost_floor_min_pct = 0.0
    execution_cost_artifact_enabled = True
    execution_cost_artifact_dir = "artifacts/execution_cost"
    execution_cost_artifact_filename = "execution_cost_calibration.latest.json"
    execution_cost_artifact_max_age_minutes = 180.0

    # Width constraints for the box
    min_width_pct = 0.035  # 3.5%
    max_width_pct = 0.060  # 6.0%
    box_width_avg_veto_enabled = True
    box_width_avg_veto_lookback = 20
    box_width_avg_veto_min_samples = 5
    box_width_avg_veto_max_ratio = 1.20

    # Stop rules (15m)
    stop_confirm_bars = 2
    fast_stop_step_multiple = 1.0  # 1 * step beyond edge
    range_shift_stop_pct = 0.007   # 0.7% mid shift vs previous plan
    tp_step_multiple = 0.75
    sl_step_multiple = 1.0
    reclaim_hours = 4.0
    cooldown_minutes = 90
    min_runtime_hours = 3.0
    neutral_stop_adx_bars = 3
    neutral_box_break_bars = 2
    neutral_box_break_step_multiple = 1.0
    drawdown_guard_enabled = True
    drawdown_guard_lookback_bars = 96
    drawdown_guard_max_pct = 0.030
    max_stops_window_enabled = True
    max_stops_window_minutes = 360
    max_stops_window_count = 4

    # Gate tuning profile (START gating debug/tune helper)
    gate_profile = "strict"  # strict | balanced | aggressive
    start_min_gate_pass_ratio = 1.0  # keep 1.0 for strict all-gates behavior
    start_stability_min_score = 1.0
    start_stability_k_fraction = 1.0
    start_box_position_guard_enabled = True
    start_box_position_min_frac = 0.35
    start_box_position_max_frac = 0.65
    basis_cross_confirm_enabled = False
    capacity_hint_path = ""
    capacity_hint_hard_block = False

    # Planner health / meta drift / runtime rails.
    planner_health_quarantine_on_gap = True
    planner_health_quarantine_on_misalign = True
    meta_drift_soft_block_enabled = True
    meta_drift_soft_block_steps = 0.75
    meta_drift_guard_enabled = True
    meta_drift_guard_window = 256
    meta_drift_guard_min_samples = 24
    meta_drift_guard_smoothing_alpha = 0.20
    meta_drift_guard_eps = 1e-6
    meta_drift_guard_z_soft = 2.5
    meta_drift_guard_z_hard = 4.0
    meta_drift_guard_cusum_k_sigma = 0.25
    meta_drift_guard_cusum_soft = 4.0
    meta_drift_guard_cusum_hard = 7.0
    meta_drift_guard_ph_delta_sigma = 0.10
    meta_drift_guard_ph_soft = 4.0
    meta_drift_guard_ph_hard = 7.0
    meta_drift_guard_soft_min_channels = 1
    meta_drift_guard_hard_min_channels = 2
    meta_drift_guard_cooldown_extend_minutes = 120
    meta_drift_guard_spread_proxy_scale = 0.10
    breakout_idle_reclaim_on_fresh = True
    hvp_quiet_exit_bias_enabled = False
    hvp_quiet_exit_step_multiple = 0.5

    # Regime router (intraday / neutral_choppy / swing / pause).
    regime_router_enabled = True
    regime_router_default_mode = "intraday"  # intraday | neutral_choppy | swing | pause
    regime_router_force_mode = ""  # empty for auto, else intraday | neutral_choppy | swing | pause
    regime_router_switch_persist_bars = 4
    regime_router_switch_cooldown_bars = 6
    regime_router_switch_margin = 1.0
    regime_router_allow_pause = True
    regime_router_score_enter = 0.7
    regime_router_score_exit = 0.55
    regime_router_score_persistence_bars = 4
    regime_router_score_artifact_run_id = ""
    regime_router_score_artifact_dir = "artifacts/regime_bands"
    regime_router_score_artifact_file = "neutral_bands.json"
    neutral_adx_enter_pct = 55.0
    neutral_adx_exit_pct = 65.0
    neutral_adx_veto_pct = 70.0
    neutral_bbwp_enter_min_pct = 20.0
    neutral_bbwp_enter_max_pct = 60.0
    neutral_bbwp_veto_pct = 85.0
    neutral_bbwp_dead_pct = 10.0
    neutral_atr_pct_min = 0.15
    neutral_spread_bps_max = 10.0
    neutral_spread_step_frac = 0.15

    # Neutral persistence knobs (from audit recommendations)
    neutral_enter_persist_min = 10
    neutral_enter_persist_max = 60
    neutral_exit_persist_ratio = 0.5
    neutral_cooldown_multiplier = 2.0
    neutral_min_runtime_hours_offset = 0.0
    neutral_persistence_default_enter = 24
    neutral_grid_levels_ratio = 0.6
    neutral_grid_budget_ratio = 0.5
    neutral_rebuild_shift_pct = 0.007
    neutral_rebuild_max_bars = 6

    def _determine_regime_bands_run_id(self) -> Optional[str]:
        cfg = getattr(self, "config", {}) or {}
        manual = str(cfg.get("regime_router_score_artifact_run_id") or self.regime_router_score_artifact_run_id or "").strip()
        if manual:
            return manual
        latest_refs_path = Path(str(cfg.get("user_data_dir") or "/freqtrade/user_data")).resolve() / "latest_refs" / "regime_audit.json"
        if latest_refs_path.is_file():
            try:
                with latest_refs_path.open("r", encoding="utf-8") as f:
                    payload = json.load(f)
                run_id = payload.get("run_id") or payload.get("latest_run_id")
                if run_id:
                    return str(run_id)
            except Exception:
                pass
        return None
    regime_threshold_profile = "manual"  # manual | research_v1

    # Intraday (scalper-ish) mode thresholds.
    intraday_adx_enter_max = 22.0
    intraday_adx_exit_min = 30.0
    intraday_adx_rising_bars = 3
    intraday_bbw_1h_pct_max = 30.0
    intraday_bbw_nonexp_lookback_bars = 3
    intraday_bbw_nonexp_tolerance_frac = 0.01
    intraday_ema_dist_max_frac = 0.005
    intraday_vol_spike_mult = 1.2
    intraday_rvol_15m_max = 1.2
    intraday_bbwp_s_enter_low = 15.0
    intraday_bbwp_s_enter_high = 45.0
    intraday_bbwp_m_enter_low = 10.0
    intraday_bbwp_m_enter_high = 55.0
    intraday_bbwp_l_enter_low = 10.0
    intraday_bbwp_l_enter_high = 65.0
    intraday_bbwp_stop_high = 90.0
    intraday_atr_pct_max = 0.015
    intraday_os_dev_persist_bars = 24
    intraday_os_dev_rvol_max = 1.2

    # Swing range mode thresholds.
    swing_adx_enter_max = 28.0
    swing_adx_exit_min = 35.0
    swing_adx_rising_bars = 2
    swing_bbw_1h_pct_max = 40.0
    swing_bbw_nonexp_lookback_bars = 3
    swing_bbw_nonexp_tolerance_frac = 0.015
    swing_ema_dist_max_frac = 0.010
    swing_vol_spike_mult = 1.8
    swing_rvol_15m_max = 1.8
    swing_bbwp_s_enter_low = 10.0
    swing_bbwp_s_enter_high = 65.0
    swing_bbwp_m_enter_low = 10.0
    swing_bbwp_m_enter_high = 65.0
    swing_bbwp_l_enter_low = 10.0
    swing_bbwp_l_enter_high = 75.0
    swing_bbwp_stop_high = 93.0
    swing_atr_pct_max = 0.030
    swing_os_dev_persist_bars = 12
    swing_os_dev_rvol_max = 1.8

    # Backtest/walk-forward: write full per-candle plan history for true replay.
    emit_per_candle_history_backtest = True

    # Update policy
    soft_adjust_max_step_frac = 0.5  # if edges move < 0.5*step => soft adjust allowed

    # Capital policy (quote-only for now)
    inventory_mode = "quote_only"
    inventory_target_base_min_pct = 0.0
    inventory_target_base_max_pct = 0.0
    topup_policy = "manual"
    max_concurrent_rebuilds = 1
    preferred_rung_cap = 0
    grid_budget_pct = 0.70
    reserve_pct = 0.30

    # TP/SL target expansion (Section 13.6).
    donchian_lookback_bars = 96
    basis_band_window = 96
    basis_band_stds = 2.0
    fvg_vp_enabled = False
    fvg_vp_bins = 32
    fvg_vp_lookback_bars = 256
    fvg_vp_poc_tag_step_frac = 0.30
    sl_lvn_avoid_steps = 0.25
    sl_fvg_buffer_steps = 0.10
    box_quality_log_space = True
    box_quality_extension_factor = 1.386
    midline_bias_fallback_enabled = True
    midline_bias_tp_candidate_enabled = True
    midline_bias_poc_neutral_step_frac = 0.35
    midline_bias_poc_neutral_width_frac = 0.01
    midline_bias_source_buffer_steps = 0.50
    midline_bias_source_buffer_width_frac = 0.02
    midline_bias_deadband_steps = 0.25
    midline_bias_deadband_width_frac = 0.005

    # Shared fill semantics metadata (Section 13.7).
    fill_confirmation_mode = "Touch"  # Touch | Reverse
    fill_no_repeat_lsi_guard = True
    fill_no_repeat_cooldown_bars = 1
    tick_size_step_frac = 0.01
    tick_size_floor = 1e-8

    # M505 / M809 / M1003 / M702 / M703 / M805 extensions.
    micro_reentry_pause_bars = 4
    micro_reentry_require_poc_reclaim = True
    micro_reentry_poc_buffer_steps = 0.25
    buy_ratio_bias_enabled = True
    buy_ratio_midband_half_width = 0.35
    buy_ratio_bullish_threshold = 0.58
    buy_ratio_bearish_threshold = 0.42
    buy_ratio_rung_bias_strength = 0.35
    buy_ratio_bearish_tp_step_multiple = 0.50
    smart_channel_enabled = True
    smart_channel_breakout_step_buffer = 0.25
    smart_channel_volume_confirm_enabled = True
    smart_channel_volume_rvol_min = 1.10
    smart_channel_tp_nudge_step_multiple = 0.50
    ob_enabled = True
    ob_tf = "1h"
    ob_use_wick_zone = True
    ob_impulse_lookahead = 3
    ob_impulse_atr_len = 14
    ob_impulse_atr_mult = 1.0
    ob_fresh_bars = 20
    ob_max_age_bars = 400
    ob_mitigation_mode = "wick"
    ob_straddle_min_step_mult = 1.0
    ob_tp_nudge_max_steps = 4.0
    zigzag_contraction_enabled = True
    zigzag_contraction_lookback_bars = 12
    zigzag_contraction_ratio_max = 0.95
    session_sweep_enabled = True
    session_sweep_retest_lookback_bars = 2
    sweeps_enabled = True
    sweep_pivot_len = 5
    sweep_max_age_bars = 200
    sweep_break_buffer_mode = "step"
    sweep_break_buffer_value = 0.2
    sweep_retest_window_bars = 12
    sweep_retest_buffer_mode = "step"
    sweep_retest_buffer_value = 0.2
    sweep_stop_if_through_box_edge = True
    sweep_retest_validation_mode = "Wick"
    sweep_min_level_separation_steps = 1.0
    order_flow_enabled = True
    order_flow_spread_soft_max_pct = 0.0030
    order_flow_depth_thin_soft_max = 0.65
    order_flow_imbalance_extreme = 0.85
    order_flow_jump_soft_max_pct = 0.0080
    order_flow_soft_veto_min_flags = 2
    order_flow_hard_block = False
    order_flow_confidence_penalty_per_flag = 0.10

    plans_root_rel = "grid_plans"
    plan_schema_version = PLAN_SCHEMA_VERSION
    planner_version = PLANNER_VERSION_DEFAULT
    plan_expiry_seconds = 0
    decision_log_enabled = True
    event_log_enabled = True
    decision_log_filename = "decision_log.jsonl"
    event_log_filename = "event_log.jsonl"
    decision_event_log_max_changed_fields = 24

    # -------- internal state (best-effort, per process) --------
    _last_written_ts_by_pair: Dict[str, int] = {}
    _last_plan_hash_by_pair: Dict[str, str] = {}
    _last_plan_base_hash_by_pair: Dict[str, str] = {}
    _last_material_plan_payload_by_pair: Dict[str, Dict[str, object]] = {}
    _last_plan_id_by_pair: Dict[str, str] = {}
    _last_decision_seq_by_pair: Dict[str, int] = {}
    _event_counter_by_pair: Dict[str, int] = {}
    _last_mid_by_pair: Dict[str, float] = {}
    _last_box_step_by_pair: Dict[str, float] = {}
    _reclaim_until_ts_by_pair: Dict[str, int] = {}
    _cooldown_until_ts_by_pair: Dict[str, int] = {}
    _micro_reentry_pause_until_ts_by_pair: Dict[str, int] = {}
    _stop_timestamps_by_pair: Dict[str, deque] = {}
    _active_since_ts_by_pair: Dict[str, int] = {}
    _running_by_pair: Dict[str, bool] = {}
    _bbwp_cooloff_by_pair: Dict[str, bool] = {}
    _os_dev_state_by_pair: Dict[str, int] = {}
    _os_dev_candidate_by_pair: Dict[str, int] = {}
    _os_dev_candidate_count_by_pair: Dict[str, int] = {}
    _os_dev_zero_persist_by_pair: Dict[str, int] = {}
    _mrvd_day_poc_prev_by_pair: Dict[str, float] = {}
    _cvd_freeze_bars_left_by_pair: Dict[str, int] = {}
    _last_adx_by_pair: Dict[str, float] = {}
    _adx_rising_count_by_pair: Dict[str, int] = {}
    _mode_by_pair: Dict[str, str] = {}
    _mode_candidate_by_pair: Dict[str, str] = {}
    _mode_candidate_count_by_pair: Dict[str, int] = {}
    _mode_cooldown_until_ts_by_pair: Dict[str, int] = {}
    _running_mode_by_pair: Dict[str, str] = {}
    _mode_at_entry_by_pair: Dict[str, str] = {}
    _mode_at_exit_by_pair: Dict[str, str] = {}
    _history_emit_in_progress_by_pair: Dict[str, bool] = {}
    _history_emit_end_ts_by_pair: Dict[str, int] = {}
    _box_state_by_pair: Dict[str, Dict[str, object]] = {}
    _box_rebuild_bars_since_by_pair: Dict[str, int] = {}
    _neutral_box_break_bars_by_pair: Dict[str, int] = {}
    _breakout_levels_by_pair: Dict[str, Dict[str, float]] = {}
    _breakout_bars_since_by_pair: Dict[str, int] = {}
    _box_signature_by_pair: Dict[str, str] = {}
    _data_quality_issues_by_pair: Dict[str, Dict[str, object]] = {}
    _materiality_epoch_bar_count_by_pair: Dict[str, int] = {}
    _box_history_by_pair: Dict[str, deque] = {}
    _box_width_history_by_pair: Dict[str, deque] = {}
    _last_width_pct_by_pair: Dict[str, float] = {}
    _last_tp_price_by_pair: Dict[str, float] = {}
    _last_sl_price_by_pair: Dict[str, float] = {}
    _ob_state_by_pair: Dict[str, Dict[str, object]] = {}
    _poc_acceptance_crossed_by_pair: Dict[str, bool] = {}
    _poc_alignment_crossed_by_pair: Dict[str, bool] = {}
    _plan_guard_decision_count_by_pair: Dict[str, int] = {}
    _mid_history_by_pair: Dict[str, deque] = {}
    _hvp_cooloff_by_pair: Dict[str, bool] = {}
    _box_quality_by_pair: Dict[str, Dict[str, object]] = {}
    _mid_history_by_pair: Dict[str, deque] = {}
    _hvp_cooloff_by_pair: Dict[str, bool] = {}
    _meta_drift_prev_box_pos_by_pair: Dict[str, float] = {}
    _external_mode_thresholds_path_cache: Optional[str] = None
    _external_mode_thresholds_mtime_cache: float = -1.0
    _external_mode_thresholds_cache: Dict[str, Dict[str, float]] = {}
    _neutral_persistence_state_by_pair: Dict[str, Dict[str, int]] = {}

    # ========== Informative pairs ==========
    def informative_pairs(self):
        wl: List[str] = []
        if getattr(self, "dp", None) is not None:
            try:
                wl = list(self.dp.current_whitelist() or [])
            except Exception:
                wl = []
        if not wl:
            try:
                cfg_wl = ((self.config or {}).get("exchange") or {}).get("pair_whitelist") or []
                wl = [str(p) for p in cfg_wl if str(p).strip()]
            except Exception:
                wl = []
        out = []
        for p in wl:
            out.append((p, "1h"))
            out.append((p, "4h"))
        return out

    @informative("4h")
    def populate_indicators_4h(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["adx_4h"] = ta.ADX(dataframe, timeperiod=self.adx_period)
        dataframe["plus_di_4h"] = ta.PLUS_DI(dataframe, timeperiod=self.adx_period)
        dataframe["minus_di_4h"] = ta.MINUS_DI(dataframe, timeperiod=self.adx_period)
        dataframe["atr_4h"] = ta.ATR(dataframe, timeperiod=self.bb_window)

        tp = qtpylib.typical_price(dataframe)
        bb = qtpylib.bollinger_bands(tp, window=self.bb_window, stds=self.bb_stds)
        dataframe["bb_mid_4h"] = bb["mid"]
        dataframe["bb_upper_4h"] = bb["upper"]
        dataframe["bb_lower_4h"] = bb["lower"]
        dataframe["bb_width_4h"] = (dataframe["bb_upper_4h"] - dataframe["bb_lower_4h"]) / dataframe["bb_mid_4h"]
        return dataframe

    @informative("1h")
    def populate_indicators_1h(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        tp = qtpylib.typical_price(dataframe)
        bb = qtpylib.bollinger_bands(tp, window=self.bb_window, stds=self.bb_stds)
        dataframe["bb_mid_1h"] = bb["mid"]
        dataframe["bb_upper_1h"] = bb["upper"]
        dataframe["bb_lower_1h"] = bb["lower"]
        dataframe["bb_width_1h"] = (dataframe["bb_upper_1h"] - dataframe["bb_lower_1h"]) / dataframe["bb_mid_1h"]

        dataframe["ema50_1h"] = ta.EMA(dataframe, timeperiod=self.ema_fast)
        dataframe["ema100_1h"] = ta.EMA(dataframe, timeperiod=self.ema_slow)

        dataframe["vol_sma20_1h"] = dataframe["volume"].rolling(self.vol_sma_window).mean()

        dataframe["kc_mid_1h"] = ta.EMA(dataframe, timeperiod=self.bb_window)
        dataframe["atr_1h"] = ta.ATR(dataframe, timeperiod=self.bb_window)
        dataframe["kc_upper_1h"] = dataframe["kc_mid_1h"] + (self.kc_atr_mult * dataframe["atr_1h"])
        dataframe["kc_lower_1h"] = dataframe["kc_mid_1h"] - (self.kc_atr_mult * dataframe["atr_1h"])
        dataframe["squeeze_on_1h"] = (
            (dataframe["bb_upper_1h"] < dataframe["kc_upper_1h"])
            & (dataframe["bb_lower_1h"] > dataframe["kc_lower_1h"])
        ).astype(int)
        # LazyBear-style squeeze momentum proxy used for Phase-2 start/TP nudges.
        highest_1h = dataframe["high"].rolling(window=self.bb_window, min_periods=self.bb_window).max()
        lowest_1h = dataframe["low"].rolling(window=self.bb_window, min_periods=self.bb_window).min()
        mean_hl = (highest_1h + lowest_1h) / 2.0
        mean_close = dataframe["close"].rolling(window=self.bb_window, min_periods=self.bb_window).mean()
        squeeze_source = dataframe["close"] - ((mean_hl + mean_close) / 2.0)
        dataframe["squeeze_val_1h"] = ta.LINEARREG(squeeze_source, timeperiod=self.bb_window)
        return dataframe

    # ========== Helpers ==========
    @staticmethod
    def _safe_float(x) -> Optional[float]:
        try:
            if x is None:
                return None
            if isinstance(x, (float, int, np.floating, np.integer)):
                if np.isnan(x):
                    return None
                return float(x)
            xf = float(x)
            if np.isnan(xf):
                return None
            return xf
        except Exception:
            return None

    def _record_mid_history(self, pair: str, mid: float) -> Optional[float]:
        window = max(int(self.band_slope_veto_bars), 2)
        history = self._mid_history_by_pair.get(pair)
        if history is None or history.maxlen != window:
            history = deque(maxlen=window)
            self._mid_history_by_pair[pair] = history
        prev_mid = history[0] if len(history) == window else None
        history.append(mid)
        return prev_mid

    def _compute_band_slope_pct(self, pair: str, mid: float) -> Optional[float]:
        prev_mid = self._record_mid_history(pair, mid)
        if prev_mid is None or prev_mid <= 0.0:
            return None
        try:
            return abs(mid - float(prev_mid)) / float(prev_mid)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _excursion_asymmetry_ratio(lo: float, hi: float, mid: float) -> Optional[float]:
        up_dev = hi - mid
        down_dev = mid - lo
        if up_dev <= 0.0 or down_dev <= 0.0:
            return None
        try:
            return up_dev / down_dev
        except (TypeError, ValueError):
            return None

    def _funding_gate_ok(self, fr_8h_pct: Optional[float]) -> bool:
        if not self.funding_filter_enabled:
            return True
        if fr_8h_pct is None:
            return True
        return bool(abs(fr_8h_pct) <= float(self.funding_filter_pct))

    def _hvp_stats(self, close_series: pd.Series) -> Tuple[Optional[float], Optional[float]]:
        if close_series is None or close_series.empty:
            return None, None
        returns = close_series.pct_change().abs()
        hvp_window = max(int(self.hvp_lookback_bars), 1)
        hvp_indicator = returns.rolling(window=hvp_window, min_periods=1).std()
        if hvp_indicator.empty:
            return None, None
        current = self._safe_float(hvp_indicator.iloc[-1])
        sma_window = max(int(self.hvp_sma_bars), 1)
        if len(hvp_indicator) >= sma_window:
            sma = self._safe_float(hvp_indicator.iloc[-sma_window :].mean())
        else:
            sma = self._safe_float(hvp_indicator.mean())
        return current, sma

    @staticmethod
    def _box_signature(lo: float, hi: float, lookback: int, pad: float) -> str:
        if lo is None or hi is None or pad is None:
            return f"{lo}-{hi}-{lookback}-{pad}"
        return f"{lo:.8f}:{hi:.8f}:{lookback}:{pad:.8f}"

    @staticmethod
    def _poc_cross_detected(df: DataFrame, poc: Optional[float], lookback: int) -> bool:
        if poc is None or lookback <= 0 or df is None or df.empty:
            return False
        bars = min(len(df), lookback)
        if bars <= 0:
            return False
        window = df.iloc[-bars:]
        for _, row in window.iterrows():
            open_val = GridBrainV1Core._safe_float(row.get("open"))
            close_val = GridBrainV1Core._safe_float(row.get("close"))
            if open_val is None or close_val is None:
                continue
            if (open_val < poc < close_val) or (open_val > poc > close_val):
                return True
        return False

    @staticmethod
    def _derive_box_block_reasons(fvg_state: Dict[str, object]) -> List[BlockReason]:
        reasons: List[BlockReason] = []
        if not fvg_state:
            return reasons
        if bool(fvg_state.get("straddle_veto", False)):
            reasons.append(BlockReason.BLOCK_BOX_STRADDLE_FVG_EDGE)
        if bool(fvg_state.get("defensive_conflict", False)):
            reasons.append(BlockReason.BLOCK_BOX_STRADDLE_FVG_AVG)
        session_conflict = bool(fvg_state.get("session_inside_block", False)) or bool(
            fvg_state.get("session_pause_active", False)
        )
        if session_conflict:
            reasons.append(BlockReason.BLOCK_BOX_STRADDLE_SESSION_FVG_AVG)
        return reasons

    def _box_straddles_cached_breakout(
        self, pair: str, box_low: float, box_high: float, step_price: float
    ) -> bool:
        if step_price <= 0 or box_low is None or box_high is None:
            return False
        bars_since = self._breakout_bars_since_by_pair.get(pair)
        if bars_since is None or int(bars_since) > int(self.breakout_block_bars):
            return False
        breakout = self._breakout_levels_by_pair.get(pair)
        if not breakout:
            return False
        return self._is_level_near_box(
            breakout.get("up"),
            box_low,
            box_high,
            step_price,
            self.breakout_straddle_step_buffer_frac,
        ) or self._is_level_near_box(
            breakout.get("dn"),
            box_low,
            box_high,
            step_price,
            self.breakout_straddle_step_buffer_frac,
        )

    def _box_straddles_level(
        self,
        pair: str,
        level: Optional[float],
        box_low: float,
        box_high: float,
        step_price: float,
        buffer_frac: float,
    ) -> bool:
        if level is None:
            return False
        return self._is_level_near_box(level, box_low, box_high, step_price, buffer_frac)

    def _box_level_straddle_reasons(
        self,
        pair: str,
        box_low: float,
        box_high: float,
        step_price: float,
        levels: List[Tuple[Optional[float], BlockReason]],
    ) -> List[BlockReason]:
        if box_low is None or box_high is None or step_price <= 0 or not levels:
            return []
        reasons: List[BlockReason] = []
        for level, reason in levels:
            if self._box_straddles_level(pair, level, box_low, box_high, step_price, self.breakout_straddle_step_buffer_frac):
                reasons.append(reason)
        return reasons

    @staticmethod
    def _squeeze_release_block_reason(release: bool) -> Optional[BlockReason]:
        return BlockReason.BLOCK_SQUEEZE_RELEASE_AGAINST_BIAS if release else None

    def _append_reason(self, reasons: List[BlockReason], reason: BlockReason) -> None:
        if reason not in reasons:
            reasons.append(reason)

    def _run_data_quality_checks(self, dataframe: DataFrame, pair: str) -> Dict[str, object]:
        data_quality_entry = assess_data_quality(
            dataframe,
            expected_candle_seconds=float(self.data_quality_expected_candle_seconds),
            gap_multiplier=float(self.data_quality_gap_multiplier),
            max_stale_minutes=float(self.data_quality_max_stale_minutes),
            zero_volume_streak_bars=int(self.data_quality_zero_volume_streak_bars),
            required_columns=("bb_mid_1h", "bb_mid_4h"),
        )
        self._data_quality_issues_by_pair[pair] = data_quality_entry
        return data_quality_entry

    @staticmethod
    def _percentile(series: pd.Series, percentile: float, lookback: int) -> Optional[float]:
        if lookback <= 0 or series is None or percentile < 0 or percentile > 100:
            return None
        values = series.dropna().astype(float)
        if values.empty:
            return None
        window = values.iloc[-lookback:]
        if window.empty:
            return None
        return float(np.percentile(window, percentile))

    def _poc_acceptance_status(
        self, pair: str, df: DataFrame, pocs: Optional[Iterable[float]]
    ) -> bool:
        if not self.poc_acceptance_enabled:
            return True
        if bool(self._poc_acceptance_crossed_by_pair.get(pair, False)):
            return True
        if df is None or df.empty:
            return False
        candidates: List[float] = []
        if isinstance(pocs, (int, float)):
            candidates.append(float(pocs))
        elif pocs:
            for candidate in pocs:
                if candidate is None:
                    continue
                candidates.append(float(candidate))
        for candidate in candidates:
            if self._poc_cross_detected(df, candidate, self.poc_acceptance_lookback_bars):
                self._poc_acceptance_crossed_by_pair[pair] = True
                return True
        return False

    @staticmethod
    def _fallback_poc_estimate(df: DataFrame, lookback: int) -> Optional[float]:
        if lookback <= 0 or df is None or df.empty:
            return None
        required = ("high", "low", "close")
        if any(col not in df.columns for col in required):
            return None
        window = df.iloc[-lookback:] if len(df) >= lookback else df
        if window.empty:
            return None
        highs = pd.to_numeric(window["high"], errors="coerce")
        lows = pd.to_numeric(window["low"], errors="coerce")
        closes = pd.to_numeric(window["close"], errors="coerce")
        typical = (highs + lows + closes) / 3.0
        if typical.dropna().empty:
            return None
        if "volume" in window.columns:
            volumes = pd.to_numeric(window["volume"], errors="coerce").fillna(0.0)
            volume_sum = float(volumes.sum())
            if volume_sum > 0.0:
                weighted = float((typical.fillna(0.0) * volumes).sum() / volume_sum)
                if np.isfinite(weighted):
                    return weighted
        median_typical = float(typical.dropna().median())
        return median_typical if np.isfinite(median_typical) else None

    def _box_width_history(self, pair: str) -> deque:
        window = max(int(self.box_width_avg_veto_lookback), 1)
        hist = self._box_width_history_by_pair.get(pair)
        if hist is None:
            hist = deque(maxlen=window)
            self._box_width_history_by_pair[pair] = hist
            return hist
        if hist.maxlen != window:
            hist = deque(list(hist), maxlen=window)
            self._box_width_history_by_pair[pair] = hist
        return hist

    def _box_width_avg_veto_state(self, pair: str, width_pct: float) -> Dict[str, object]:
        history = self._box_width_history(pair)
        samples = len(history)
        rolling_avg = float(np.mean(history)) if samples > 0 else None
        ratio = None
        if rolling_avg is not None and rolling_avg > 0.0:
            ratio = float(width_pct / rolling_avg)
        enabled = bool(self.box_width_avg_veto_enabled)
        min_samples = max(int(self.box_width_avg_veto_min_samples), 1)
        max_ratio = float(max(self.box_width_avg_veto_max_ratio, 1.0))
        veto = bool(
            enabled
            and rolling_avg is not None
            and samples >= min_samples
            and ratio is not None
            and ratio > max_ratio
        )
        return {
            "enabled": bool(enabled),
            "samples": int(samples),
            "lookback": int(max(int(self.box_width_avg_veto_lookback), 1)),
            "min_samples": int(min_samples),
            "max_ratio": float(max_ratio),
            "rolling_avg_width_pct": float(rolling_avg) if rolling_avg is not None else None,
            "width_pct": float(width_pct),
            "ratio_to_rolling_avg": float(ratio) if ratio is not None else None,
            "veto": bool(veto),
        }

    def _record_accepted_box_width(self, pair: str, width_pct: float) -> None:
        history = self._box_width_history(pair)
        history.append(float(width_pct))

    def _poc_alignment_state(
        self,
        pair: str,
        df: DataFrame,
        vrvp_poc: Optional[float],
        micro_poc: Optional[float],
        step_price: float,
        box_low: float,
        box_high: float,
    ) -> Dict[str, object]:
        enabled = bool(self.poc_alignment_enabled)
        strict = bool(self.poc_alignment_strict_enabled)
        lookback = max(int(self.poc_alignment_lookback_bars), 1)
        max_step_diff = float(max(self.poc_alignment_max_step_diff, 0.0))
        max_width_frac = float(max(self.poc_alignment_max_width_frac, 0.0))
        box_width = float(max(float(box_high) - float(box_low), 0.0))
        threshold = float(max(max_step_diff * max(step_price, 0.0), max_width_frac * box_width))

        vrvp_value = self._safe_float(vrvp_poc)
        micro_value = self._safe_float(micro_poc)
        if not enabled or vrvp_value is None or micro_value is None:
            return {
                "enabled": bool(enabled),
                "strict": bool(strict),
                "ok": True,
                "misaligned": False,
                "diff": None,
                "threshold": float(threshold),
                "crossed": True,
                "crossed_vrvp": None,
                "crossed_micro": None,
                "block_reason": None,
            }

        diff = abs(float(vrvp_value) - float(micro_value))
        misaligned = bool(diff > threshold)
        if not misaligned:
            self._poc_alignment_crossed_by_pair[pair] = True
            return {
                "enabled": bool(enabled),
                "strict": bool(strict),
                "ok": True,
                "misaligned": False,
                "diff": float(diff),
                "threshold": float(threshold),
                "crossed": True,
                "crossed_vrvp": None,
                "crossed_micro": None,
                "block_reason": None,
            }

        crossed_vrvp = bool(self._poc_cross_detected(df, vrvp_value, lookback))
        crossed_micro = bool(self._poc_cross_detected(df, micro_value, lookback))
        crossed_now = bool(crossed_vrvp and crossed_micro)
        crossed_prev = bool(self._poc_alignment_crossed_by_pair.get(pair, False))
        crossed = bool(crossed_prev or crossed_now)
        if crossed:
            self._poc_alignment_crossed_by_pair[pair] = True

        ok = bool((not strict) or crossed)
        block_reason = str(BlockReason.BLOCK_POC_ALIGNMENT_FAIL) if (strict and not crossed) else None
        return {
            "enabled": bool(enabled),
            "strict": bool(strict),
            "ok": bool(ok),
            "misaligned": bool(misaligned),
            "diff": float(diff),
            "threshold": float(threshold),
            "crossed": bool(crossed),
            "crossed_vrvp": bool(crossed_vrvp),
            "crossed_micro": bool(crossed_micro),
            "block_reason": block_reason,
        }

    @staticmethod
    def _efficiency_ratio(series: pd.Series, period: int) -> Optional[float]:
        if period <= 0 or series is None:
            return None
        window = series.dropna().astype(float)
        if len(window) < (period + 1):
            return None
        window = window.iloc[-(period + 1) :]
        change = abs(window.iloc[-1] - window.iloc[0])
        volatility = window.diff().abs().sum()
        if volatility is None or volatility <= 0:
            return None
        return float(change) / float(volatility)

    def _detect_structural_breakout(
        self,
        dataframe: DataFrame,
        lookback: int,
    ) -> Tuple[bool, Optional[str], Optional[float], Optional[float]]:
        if len(dataframe) <= lookback + 1:
            return False, None, None, None
        region = dataframe.iloc[-(lookback + 1):-1]
        hi_max = self._safe_float(region["high"].max())
        lo_min = self._safe_float(region["low"].min())
        close_now = self._safe_float(dataframe["close"].iloc[-1])
        if hi_max is None or lo_min is None or close_now is None:
            return False, None, hi_max, lo_min
        bull_break = bool(close_now > hi_max)
        bear_break = bool(close_now < lo_min)
        if bull_break:
            return True, "bull", hi_max, lo_min
        if bear_break:
            return True, "bear", hi_max, lo_min
        return False, None, hi_max, lo_min

    def _breakout_confirm_buffer(
        self,
        *,
        step_price: float,
        atr_15m: Optional[float],
        close: float,
    ) -> float:
        mode = str(getattr(self, "breakout_confirm_buffer_mode", "step") or "step").strip().lower()
        value = float(max(self._safe_float(getattr(self, "breakout_confirm_buffer_value", 0.0)) or 0.0, 0.0))
        if mode == "step":
            return float(value * max(float(step_price), 0.0))
        if mode == "atr":
            return float(value * max(float(atr_15m or 0.0), 0.0))
        if mode == "pct":
            return float(value * max(float(close), 0.0))
        if mode == "abs":
            return float(value)
        # Unknown modes fall back to step semantics to keep behavior deterministic.
        return float(value * max(float(step_price), 0.0))

    @staticmethod
    def _breakout_confirm_state(
        dataframe: DataFrame,
        *,
        box_low: float,
        box_high: float,
        buffer: float,
        confirm_bars: int,
    ) -> Dict[str, object]:
        k = max(int(confirm_bars), 0)
        out: Dict[str, object] = {
            "enabled": bool(k > 0),
            "confirm_bars": int(k),
            "buffer": float(max(float(buffer), 0.0)),
            "enough_history": False,
            "up_threshold": float(box_high + max(float(buffer), 0.0)),
            "dn_threshold": float(box_low - max(float(buffer), 0.0)),
            "confirmed_up": False,
            "confirmed_dn": False,
        }
        if k <= 0 or "close" not in dataframe.columns:
            return out
        closes = pd.to_numeric(dataframe["close"], errors="coerce").dropna().astype(float)
        if len(closes) < k:
            return out
        window = closes.iloc[-k:]
        if len(window) < k:
            return out
        up_threshold = float(out["up_threshold"])
        dn_threshold = float(out["dn_threshold"])
        confirmed_up = bool((window > up_threshold).all())
        confirmed_dn = bool((window < dn_threshold).all())
        out.update(
            {
                "enough_history": True,
                "confirmed_up": bool(confirmed_up),
                "confirmed_dn": bool(confirmed_dn),
            }
        )
        return out

    @staticmethod
    def _range_len_gate_state(
        *,
        current_bar_index: int,
        box_built_at_bar_index: int,
        min_range_len_bars: int,
        box_gen_id: str,
    ) -> Dict[str, object]:
        required = max(int(min_range_len_bars), 1)
        built_idx = int(box_built_at_bar_index)
        cur_idx = int(current_bar_index)
        range_len = int(max(cur_idx - built_idx + 1, 1))
        ok = bool(range_len >= required)
        return {
            "ok": bool(ok),
            "range_len_bars_current": int(range_len),
            "min_range_len_bars": int(required),
            "box_gen_id": str(box_gen_id),
            "block_reason": (
                str(BlockReason.BLOCK_MIN_RANGE_LEN_NOT_MET)
                if not ok
                else None
            ),
        }

    @staticmethod
    def _breakout_confirm_reason_state(
        *,
        confirmed_up: bool,
        confirmed_dn: bool,
        running_active: bool,
    ) -> Dict[str, object]:
        stop_reason = None
        block_reason = None
        if bool(confirmed_up):
            if bool(running_active):
                stop_reason = str(StopReason.STOP_BREAKOUT_CONFIRM_UP)
            else:
                block_reason = str(BlockReason.BLOCK_BREAKOUT_CONFIRM_UP)
        elif bool(confirmed_dn):
            if bool(running_active):
                stop_reason = str(StopReason.STOP_BREAKOUT_CONFIRM_DN)
            else:
                block_reason = str(BlockReason.BLOCK_BREAKOUT_CONFIRM_DN)
        return {
            "running_active": bool(running_active),
            "confirmed_up": bool(confirmed_up),
            "confirmed_dn": bool(confirmed_dn),
            "stop_reason": stop_reason,
            "block_reason": block_reason,
            "stop_up": bool(stop_reason == str(StopReason.STOP_BREAKOUT_CONFIRM_UP)),
            "stop_dn": bool(stop_reason == str(StopReason.STOP_BREAKOUT_CONFIRM_DN)),
            "block_up": bool(block_reason == str(BlockReason.BLOCK_BREAKOUT_CONFIRM_UP)),
            "block_dn": bool(block_reason == str(BlockReason.BLOCK_BREAKOUT_CONFIRM_DN)),
            "gate_ok": bool(block_reason is None),
        }

    @staticmethod
    def _bbw_nonexpanding(series: Optional[pd.Series], lookback: int, tolerance_frac: float) -> bool:
        if series is None:
            return False
        bars = max(int(lookback), 1)
        vals = pd.to_numeric(series, errors="coerce").dropna().astype(float)
        if len(vals) < (bars + 1):
            return False
        window = vals.iloc[-(bars + 1) :].to_numpy(dtype=float)
        tol = max(float(tolerance_frac), 0.0)
        for i in range(1, len(window)):
            prev = float(window[i - 1])
            cur = float(window[i])
            # Require no meaningful bar-over-bar expansion.
            if cur > (prev * (1.0 + tol)):
                return False
        return True

    def _update_breakout_fresh_state(
        self,
        pair: str,
        breakout_now: bool,
        breakout_hi: Optional[float],
        breakout_lo: Optional[float],
        close: float,
    ) -> Tuple[bool, float, float]:
        if breakout_now:
            up = breakout_hi if breakout_hi is not None else close
            dn = breakout_lo if breakout_lo is not None else close
            self._breakout_levels_by_pair[pair] = {"up": float(up), "dn": float(dn)}
            self._breakout_bars_since_by_pair[pair] = 0
        elif pair in self._breakout_bars_since_by_pair:
            self._breakout_bars_since_by_pair[pair] = int(self._breakout_bars_since_by_pair[pair]) + 1

        breakout_levels = self._breakout_levels_by_pair.get(pair, {})
        up_level = self._safe_float(breakout_levels.get("up"))
        dn_level = self._safe_float(breakout_levels.get("dn"))
        bars_since = self._breakout_bars_since_by_pair.get(pair)
        fresh_active = bars_since is not None and int(bars_since) <= int(self.breakout_block_bars)
        reclaim_override = False
        if (
            fresh_active
            and self.breakout_override_allowed
            and up_level is not None
            and dn_level is not None
            and dn_level <= close <= up_level
        ):
            reclaim_override = True
        fresh_block_active = bool(fresh_active and not reclaim_override)
        return fresh_block_active, up_level if up_level is not None else close, dn_level if dn_level is not None else close

    def _phase2_gate_failures_from_flags(
        self,
        adx_ok: bool,
        bbw_nonexp: bool,
        ema_dist_ok: bool,
        vol_ok: bool,
        inside_7d: bool,
    ) -> List[BlockReason]:
        reasons: List[BlockReason] = []
        if not adx_ok:
            reasons.append(BlockReason.BLOCK_ADX_HIGH)
        if not bbw_nonexp:
            reasons.append(BlockReason.BLOCK_BBW_EXPANDING)
        if not ema_dist_ok:
            reasons.append(BlockReason.BLOCK_EMA_DIST)
        if not vol_ok:
            reasons.append(BlockReason.BLOCK_RVOL_SPIKE)
        if not inside_7d:
            reasons.append(BlockReason.BLOCK_7D_EXTREME_CONTEXT)
        return reasons

    def _planner_health_state(self, data_quality_ok: bool, reasons: List[BlockReason]) -> str:
        if data_quality_ok:
            return "ok"
        reason_set = {str(r) for r in reasons}
        if (
            self.planner_health_quarantine_on_gap
            and str(BlockReason.BLOCK_DATA_GAP) in reason_set
        ):
            return "quarantine"
        if (
            self.planner_health_quarantine_on_misalign
            and str(BlockReason.BLOCK_DATA_MISALIGN) in reason_set
        ):
            return "quarantine"
        return "degraded"

    @staticmethod
    def _start_stability_state(
        gate_checks: List[Tuple[str, bool]],
        min_score: float,
        k_fraction: float,
    ) -> Dict[str, float]:
        return evaluate_start_stability(gate_checks, min_score, k_fraction)

    def _atomic_write_json(self, path: str, payload: Dict[str, object]) -> None:
        write_json_atomic(path, payload)

    def _evaluate_materiality(
        self,
        pair: str,
        mid: float,
        width_pct: float,
        step_price: float,
        tp_price: float,
        sl_price: float,
        hard_stop: bool,
        action: str,
    ) -> Dict[str, object]:
        prev_mid = self._last_mid_by_pair.get(pair)
        prev_width = self._last_width_pct_by_pair.get(pair)
        prev_tp = self._last_tp_price_by_pair.get(pair)
        prev_sl = self._last_sl_price_by_pair.get(pair)
        epoch_count = int(self._materiality_epoch_bar_count_by_pair.get(pair, 0) + 1)
        entry = evaluate_replan_materiality(
            prev_mid=prev_mid,
            prev_width_pct=prev_width,
            prev_tp=prev_tp,
            prev_sl=prev_sl,
            epoch_counter=epoch_count,
            thresholds=ReplanThresholds(
                epoch_bars=int(self.materiality_epoch_bars),
                box_mid_shift_max_step_frac=float(self.materiality_box_mid_shift_max_step_frac),
                box_width_change_pct=float(self.materiality_box_width_change_pct),
                tp_shift_max_step_frac=float(self.materiality_tp_shift_max_step_frac),
                sl_shift_max_step_frac=float(self.materiality_sl_shift_max_step_frac),
            ),
            mid=float(mid),
            width_pct=float(width_pct),
            step_price=float(step_price),
            tp_price=float(tp_price),
            sl_price=float(sl_price),
            hard_stop=bool(hard_stop),
            action=str(action),
        )
        self._materiality_epoch_bar_count_by_pair[pair] = int(entry.pop("next_epoch_counter"))
        return entry
    def _validate_feature_contract(self, dataframe: DataFrame, pair: str) -> bool:
        if len(dataframe) < self.startup_candle_count:
            return False

        missing_columns = [c for c in FEATURE_CONTRACT_COLUMNS if c not in dataframe.columns]
        if missing_columns:
            if not self._feature_contract_logged_pairs.get(pair):
                self._log_feature_contract_violation(pair, missing_columns, [])
            self._feature_contract_logged_pairs[pair] = True
            return False

        last = dataframe.iloc[-1]
        nan_columns = [c for c in FEATURE_CONTRACT_COLUMNS if pd.isna(last.get(c))]
        if nan_columns:
            if not self._feature_contract_logged_pairs.get(pair):
                self._log_feature_contract_violation(pair, [], nan_columns)
            self._feature_contract_logged_pairs[pair] = True
            return False

        if self._feature_contract_logged_pairs.get(pair):
            self._feature_contract_logged_pairs[pair] = False
        return True

    def _log_feature_contract_violation(
        self, pair: str, missing_columns: List[str], nan_columns: List[str]
    ) -> None:
        payload = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "module": "GridBrainV1Core",
            "level": "warning",
            "pair": pair,
            "startup_required": int(self.startup_candle_count),
            "missing_columns": missing_columns,
            "nan_columns": nan_columns,
        }
        print(json.dumps(payload, sort_keys=True))

    @staticmethod
    def _choppiness_index(highs: pd.Series, lows: pd.Series, atr: pd.Series, period: int) -> Optional[float]:
        if period <= 0 or highs is None or lows is None or atr is None:
            return None
        highs = highs.dropna().astype(float)
        lows = lows.dropna().astype(float)
        atr = atr.dropna().astype(float)
        if len(highs) < period or len(lows) < period or len(atr) < period:
            return None
        highs_win = highs.iloc[-period:]
        lows_win = lows.iloc[-period:]
        atr_win = atr.iloc[-period:]
        total_atr = float(atr_win.sum())
        range_high = float(highs_win.max())
        range_low = float(lows_win.min())
        price_range = range_high - range_low
        if total_atr <= 0 or price_range <= 0:
            return None
        try:
            ratio = total_atr / price_range
            return 100.0 * math.log10(ratio) / math.log10(period)
        except Exception:
            return None

    @staticmethod
    def _di_flip_rate(plus: pd.Series, minus: pd.Series, lookback: int) -> Optional[float]:
        if lookback <= 0 or plus is None or minus is None:
            return None
        di_diff = (plus - minus).dropna().astype(float)
        if len(di_diff) < 2:
            return None
        di_diff = di_diff.iloc[-lookback:]
        if len(di_diff) < 2:
            return None
        helpers = di_diff.apply(np.sign)
        valid = helpers.replace(0, np.nan).dropna()
        if len(valid) < 2:
            return None
        flips = 0
        prev = valid.iloc[0]
        for curr in valid.iloc[1:]:
            if curr != prev:
                flips += 1
            prev = curr
        denom = len(valid) - 1
        if denom <= 0:
            return None
        return float(flips) / float(denom)

    @staticmethod
    def _wickiness(highs: pd.Series, lows: pd.Series, opens: pd.Series, closes: pd.Series, period: int) -> Optional[float]:
        if period <= 0 or highs is None or lows is None or opens is None or closes is None:
            return None
        highs = highs.dropna().astype(float)
        lows = lows.dropna().astype(float)
        opens = opens.dropna().astype(float)
        closes = closes.dropna().astype(float)
        if len(highs) < period or len(lows) < period or len(opens) < period or len(closes) < period:
            return None
        highs_win = highs.iloc[-period:]
        lows_win = lows.iloc[-period:]
        opens_win = opens.iloc[-period:]
        closes_win = closes.iloc[-period:]
        wick_ratios = []
        for hi, lo, op, cl in zip(highs_win, lows_win, opens_win, closes_win):
            body = abs(op - cl)
            wick_up = max(hi - max(op, cl), 0.0)
            wick_down = max(min(op, cl) - lo, 0.0)
            body = max(body, 1e-9)
            ratio = (wick_up + wick_down) / body
            wick_ratios.append(ratio)
        if not wick_ratios:
            return None
        return float(np.percentile(wick_ratios, 50.0))

    @staticmethod
    def _containment_pct(highs: pd.Series, lows: pd.Series, closes: pd.Series, period: int) -> Optional[float]:
        if period <= 0 or highs is None or lows is None or closes is None:
            return None
        def _to_series(value: object) -> pd.Series:
            if isinstance(value, pd.Series):
                return value
            if value is None:
                return pd.Series(dtype=float)
            if isinstance(value, (list, tuple, np.ndarray)):
                return pd.Series(value)
            return pd.Series([value])

        highs = _to_series(highs).dropna().astype(float)
        lows = _to_series(lows).dropna().astype(float)
        closes = _to_series(closes).dropna().astype(float)
        if len(closes) < period or len(highs) < period or len(lows) < period:
            return None
        high_roll = highs.rolling(period).max().dropna()
        low_roll = lows.rolling(period).min().dropna()
        close_window = closes.iloc[-len(high_roll):]
        if len(close_window) == 0:
            return None
        contained = (
            (close_window <= high_roll.iloc[-len(close_window):])
            & (close_window >= low_roll.iloc[-len(close_window):])
        )
        if len(contained) == 0:
            return None
        return float(contained.sum()) / float(len(contained)) * 100.0

    @staticmethod
    def _adx_exit_hysteresis_trigger(
        adx_value: Optional[float],
        rising_count: int,
        exit_min: float,
        rising_bars_required: int,
    ) -> bool:
        adx = GridBrainV1Core._safe_float(adx_value)
        if adx is None:
            return False
        rb = int(max(int(rising_bars_required), 1))
        return bool(adx >= float(exit_min) and int(rising_count) >= rb)

    @staticmethod
    def _adx_di_down_risk_trigger(
        adx_value: Optional[float],
        plus_di_value: Optional[float],
        minus_di_value: Optional[float],
        rising_count: int,
        exit_min: float,
        rising_bars_required: int,
        early_margin: float = 2.0,
    ) -> bool:
        adx = GridBrainV1Core._safe_float(adx_value)
        plus_di = GridBrainV1Core._safe_float(plus_di_value)
        minus_di = GridBrainV1Core._safe_float(minus_di_value)
        if adx is None or plus_di is None or minus_di is None:
            return False
        if not bool(minus_di > plus_di):
            return False
        rb = int(max(int(rising_bars_required), 1))
        threshold = max(float(exit_min) - abs(float(early_margin)), 0.0)
        return bool(adx >= threshold and int(rising_count) >= rb)

    def _gate_profile_values(self) -> Dict[str, float]:
        profile = str(getattr(self, "gate_profile", "strict")).strip().lower()
        if profile not in ("strict", "balanced", "aggressive"):
            profile = "strict"

        cfg = {
            "profile": profile,
            "adx_4h_max": float(self.adx_4h_max),
            "bbw_1h_pct_max": float(self.bbw_1h_pct_max),
            "bbw_nonexp_lookback_bars": int(self.bbw_nonexp_lookback_bars),
            "bbw_nonexp_tolerance_frac": float(self.bbw_nonexp_tolerance_frac),
            "ema_dist_max_frac": float(self.ema_dist_max_frac),
            "vol_spike_mult": float(self.vol_spike_mult),
            "rvol_15m_max": float(self.rvol_15m_max),
            "context_7d_hard_veto": bool(self.context_7d_hard_veto),
            "bbwp_s_max": float(self.bbwp_s_max),
            "bbwp_m_max": float(self.bbwp_m_max),
            "bbwp_l_max": float(self.bbwp_l_max),
            "bbwp_veto_pct": float(self.bbwp_veto_pct),
            "bbwp_cooloff_trigger_pct": float(self.bbwp_cooloff_trigger_pct),
            "bbwp_cooloff_release_s": float(self.bbwp_cooloff_release_s),
            "bbwp_cooloff_release_m": float(self.bbwp_cooloff_release_m),
            "os_dev_persist_bars": int(self.os_dev_persist_bars),
            "os_dev_rvol_max": float(self.os_dev_rvol_max),
            "start_min_gate_pass_ratio": float(np.clip(self.start_min_gate_pass_ratio, 0.0, 1.0)),
        }

        if profile == "balanced":
            cfg["adx_4h_max"] = max(cfg["adx_4h_max"], 25.0)
            cfg["bbw_1h_pct_max"] = max(cfg["bbw_1h_pct_max"], 60.0)
            cfg["bbw_nonexp_tolerance_frac"] = max(cfg["bbw_nonexp_tolerance_frac"], 0.015)
            cfg["ema_dist_max_frac"] = max(cfg["ema_dist_max_frac"], 0.009)
            cfg["vol_spike_mult"] = max(cfg["vol_spike_mult"], 3.0)
            cfg["rvol_15m_max"] = max(cfg["rvol_15m_max"], 1.5)
            cfg["bbwp_s_max"] = max(cfg["bbwp_s_max"], 45.0)
            cfg["bbwp_m_max"] = max(cfg["bbwp_m_max"], 60.0)
            cfg["bbwp_l_max"] = max(cfg["bbwp_l_max"], 70.0)
            cfg["os_dev_persist_bars"] = min(cfg["os_dev_persist_bars"], 24)
            cfg["os_dev_rvol_max"] = max(cfg["os_dev_rvol_max"], 1.5)
        elif profile == "aggressive":
            cfg["adx_4h_max"] = max(cfg["adx_4h_max"], 30.0)
            cfg["bbw_1h_pct_max"] = max(cfg["bbw_1h_pct_max"], 70.0)
            cfg["bbw_nonexp_tolerance_frac"] = max(cfg["bbw_nonexp_tolerance_frac"], 0.02)
            cfg["ema_dist_max_frac"] = max(cfg["ema_dist_max_frac"], 0.015)
            cfg["vol_spike_mult"] = max(cfg["vol_spike_mult"], 4.0)
            cfg["rvol_15m_max"] = max(cfg["rvol_15m_max"], 1.8)
            cfg["bbwp_s_max"] = max(cfg["bbwp_s_max"], 60.0)
            cfg["bbwp_m_max"] = max(cfg["bbwp_m_max"], 75.0)
            cfg["bbwp_l_max"] = max(cfg["bbwp_l_max"], 85.0)
            cfg["os_dev_persist_bars"] = min(cfg["os_dev_persist_bars"], 12)
            cfg["os_dev_rvol_max"] = max(cfg["os_dev_rvol_max"], 1.8)

        return cfg

    MODE_TRADING = ("intraday", "swing", "neutral_choppy")
    MODE_TRADING_WITH_PAUSE = MODE_TRADING + ("pause",)

    MODE_VALUES = ("intraday", "swing", "pause", "neutral_choppy")

    @staticmethod
    def _normalize_mode_name(mode: Optional[str]) -> str:
        m = str(mode or "").strip().lower()
        if m == "swing":
            return "swing"
        if m == "pause":
            return "pause"
        if m in ("neutral_choppy", "neutral", "choppy"):
            return "neutral_choppy"
        return "intraday"

    def _neutral_adx_pct(self, adx_value: Optional[float], threshold: float) -> Optional[float]:
        if threshold <= 0 or adx_value is None:
            return None
        try:
            pct = (float(adx_value) / float(threshold)) * 100.0
            return float(max(0.0, min(100.0, pct)))
        except Exception:
            return None

    def _neutral_spread_bps(self, features: Dict[str, Optional[float]], fallback_mid: float) -> float:
        ask = self._safe_float(features.get("ask"))
        bid = self._safe_float(features.get("bid"))
        mid = self._safe_float(features.get("close")) or fallback_mid
        if ask is not None and bid is not None and mid and mid > 0.0 and ask >= bid:
            return float((ask - bid) * 10000.0 / mid)
        return float(self.est_spread_pct) * 10000.0

    def _neutral_step_bps(self, pair: str, mid_price: float) -> float:
        step_price = float(self._last_box_step_by_pair.get(pair, 0.0) or 0.0)
        if step_price <= 0.0 or mid_price <= 0.0:
            return 0.0
        return float(step_price) / float(mid_price) * 10000.0

    def _neutral_spread_threshold(self, step_bps: float) -> float:
        if step_bps <= 0.0:
            return float(self.neutral_spread_bps_max)
        return float(min(self.neutral_spread_bps_max, self.neutral_spread_step_frac * step_bps))

    def _active_threshold_profile(self) -> str:
        env_profile = str(os.getenv("GRID_REGIME_THRESHOLD_PROFILE", "") or "").strip().lower()
        if env_profile in ("manual", "research_v1"):
            return env_profile
        return str(getattr(self, "regime_threshold_profile", "manual") or "manual").strip().lower()

    def _external_mode_threshold_overrides(self) -> Dict[str, Dict[str, float]]:
        path = str(os.getenv("GRID_MODE_THRESHOLDS_PATH", "") or "").strip()
        if not path:
            self._external_mode_thresholds_path_cache = None
            self._external_mode_thresholds_mtime_cache = -1.0
            self._external_mode_thresholds_cache = {}
            return {}

        try:
            mtime = float(os.path.getmtime(path))
        except Exception:
            mtime = -1.0

        if (
            self._external_mode_thresholds_path_cache == path
            and self._external_mode_thresholds_mtime_cache == mtime
        ):
            return dict(self._external_mode_thresholds_cache)

        raw: Dict = {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                raw = json.load(f) or {}
        except Exception:
            raw = {}

        payload = raw.get("recommended_thresholds", raw)
        out: Dict[str, Dict[str, float]] = {}

        for mode in self.MODE_TRADING:
            src = payload.get(mode, {}) if isinstance(payload, dict) else {}
            if not isinstance(src, dict):
                continue

            normalized: Dict[str, float] = {}
            for key_raw, val_raw in src.items():
                key = str(key_raw).strip()
                if not key:
                    continue
                if key in ("atr_source",):
                    normalized[key] = str(val_raw).strip().lower()
                    continue
                if key in ("router_eligible",):
                    normalized[key] = bool(val_raw)
                    continue
                fv = self._safe_float(val_raw)
                if fv is None:
                    continue
                normalized[key] = float(fv)

            # Optional shorthand compatibility from audit report schema.
            if "bbwp_s_max" in normalized and "bbwp_s_enter_high" not in normalized:
                normalized["bbwp_s_enter_high"] = float(normalized["bbwp_s_max"])
            if "bbwp_m_max" in normalized and "bbwp_m_enter_high" not in normalized:
                normalized["bbwp_m_enter_high"] = float(normalized["bbwp_m_max"])
            if "bbwp_l_max" in normalized and "bbwp_l_enter_high" not in normalized:
                normalized["bbwp_l_enter_high"] = float(normalized["bbwp_l_max"])
            if "adx_exit_max" in normalized and "adx_exit_min" not in normalized:
                normalized["adx_exit_min"] = float(normalized["adx_exit_max"])
            if "adx_exit_min" in normalized and "adx_exit_max" not in normalized:
                normalized["adx_exit_max"] = float(normalized["adx_exit_min"])
            if "os_dev_persist_bars" in normalized:
                normalized["os_dev_persist_bars"] = int(round(float(normalized["os_dev_persist_bars"])))
            if "adx_rising_bars" in normalized:
                normalized["adx_rising_bars"] = int(round(float(normalized["adx_rising_bars"])))
            if "bbw_nonexp_lookback_bars" in normalized:
                normalized["bbw_nonexp_lookback_bars"] = int(
                    round(float(normalized["bbw_nonexp_lookback_bars"]))
                )
            if "router_eligible" not in normalized:
                normalized["router_eligible"] = True

            out[mode] = normalized

        self._external_mode_thresholds_path_cache = path
        self._external_mode_thresholds_mtime_cache = mtime
        self._external_mode_thresholds_cache = dict(out)
        return out

    def _mode_threshold_overrides(self, mode_name: str) -> Dict[str, float]:
        mode = self._normalize_mode_name(mode_name)
        profile = self._active_threshold_profile()
        overrides: Dict[str, float] = {}
        if profile == "research_v1":
            if mode == "intraday":
                overrides = {
                    "adx_enter_max": 24.0,
                    "adx_exit_min": 30.0,
                    "adx_exit_max": 30.0,
                    "adx_rising_bars": 3,
                    "bbw_1h_pct_max": 30.0,
                    "bbw_nonexp_lookback_bars": 3,
                    "bbw_nonexp_tolerance_frac": 0.01,
                    "ema_dist_max_frac": 0.005,
                    "vol_spike_mult": 1.2,
                    "rvol_15m_max": 1.2,
                    "bbwp_s_enter_low": 15.0,
                    "bbwp_s_enter_high": 45.0,
                    "bbwp_m_enter_low": 10.0,
                    "bbwp_m_enter_high": 55.0,
                    "bbwp_l_enter_low": 10.0,
                    "bbwp_l_enter_high": 65.0,
                    "bbwp_s_max": 45.0,
                    "bbwp_m_max": 55.0,
                    "bbwp_l_max": 65.0,
                    "bbwp_stop_high": 90.0,
                    "atr_source": "1h",
                    "atr_pct_max": 0.015,
                    "os_dev_persist_bars": 24,
                    "os_dev_rvol_max": 1.2,
                    "router_eligible": True,
                }
            elif mode == "swing":
                overrides = {
                    "adx_enter_max": 30.0,
                    "adx_exit_min": 35.0,
                    "adx_exit_max": 35.0,
                    "adx_rising_bars": 2,
                    "bbw_1h_pct_max": 40.0,
                    "bbw_nonexp_lookback_bars": 3,
                    "bbw_nonexp_tolerance_frac": 0.015,
                    "ema_dist_max_frac": 0.010,
                    "vol_spike_mult": 1.5,
                    "rvol_15m_max": 1.8,
                    "bbwp_s_enter_low": 10.0,
                    "bbwp_s_enter_high": 65.0,
                    "bbwp_m_enter_low": 10.0,
                    "bbwp_m_enter_high": 65.0,
                    "bbwp_l_enter_low": 10.0,
                    "bbwp_l_enter_high": 75.0,
                    "bbwp_s_max": 65.0,
                    "bbwp_m_max": 65.0,
                    "bbwp_l_max": 75.0,
                    "bbwp_stop_high": 93.0,
                    "atr_source": "4h",
                    "atr_pct_max": 0.030,
                    "os_dev_persist_bars": 12,
                    "os_dev_rvol_max": 1.5,
                    "router_eligible": True,
                }
        external = self._external_mode_threshold_overrides().get(mode, {})
        if external:
            overrides.update(external)
        return overrides

    def _mode_threshold_block(self, mode_name: str) -> Dict[str, float]:
        mode = self._normalize_mode_name(mode_name)
        base_mode_label = mode if mode in self.MODE_TRADING else "intraday"
        intraday_block = {
            "mode": base_mode_label,
            "adx_enter_max": float(self.intraday_adx_enter_max),
            "adx_exit_min": float(self.intraday_adx_exit_min),
            "adx_exit_max": float(self.intraday_adx_exit_min),
            "adx_rising_bars": int(self.intraday_adx_rising_bars),
            "bbw_1h_pct_max": float(self.intraday_bbw_1h_pct_max),
            "bbw_nonexp_lookback_bars": int(self.intraday_bbw_nonexp_lookback_bars),
            "bbw_nonexp_tolerance_frac": float(self.intraday_bbw_nonexp_tolerance_frac),
            "ema_dist_max_frac": float(self.intraday_ema_dist_max_frac),
            "vol_spike_mult": float(self.intraday_vol_spike_mult),
            "rvol_15m_max": float(self.intraday_rvol_15m_max),
            "bbwp_s_enter_low": float(self.intraday_bbwp_s_enter_low),
            "bbwp_s_enter_high": float(self.intraday_bbwp_s_enter_high),
            "bbwp_m_enter_low": float(self.intraday_bbwp_m_enter_low),
            "bbwp_m_enter_high": float(self.intraday_bbwp_m_enter_high),
            "bbwp_l_enter_low": float(self.intraday_bbwp_l_enter_low),
            "bbwp_l_enter_high": float(self.intraday_bbwp_l_enter_high),
            "bbwp_s_max": float(self.intraday_bbwp_s_enter_high),
            "bbwp_m_max": float(self.intraday_bbwp_m_enter_high),
            "bbwp_l_max": float(self.intraday_bbwp_l_enter_high),
            "bbwp_stop_high": float(self.intraday_bbwp_stop_high),
            "atr_source": "1h",
            "atr_pct_max": float(self.intraday_atr_pct_max),
            "os_dev_persist_bars": int(self.intraday_os_dev_persist_bars),
            "os_dev_rvol_max": float(self.intraday_os_dev_rvol_max),
            "router_eligible": True,
        }
        intraday_block.update(self._mode_threshold_overrides("intraday"))
        if mode == "neutral_choppy":
            intraday_block.update(self._mode_threshold_overrides("neutral_choppy"))
        if mode == "swing":
            swing_block = {
                "mode": "swing",
                "adx_enter_max": float(self.swing_adx_enter_max),
                "adx_exit_min": float(self.swing_adx_exit_min),
                "adx_exit_max": float(self.swing_adx_exit_min),
                "adx_rising_bars": int(self.swing_adx_rising_bars),
                "bbw_1h_pct_max": float(self.swing_bbw_1h_pct_max),
                "bbw_nonexp_lookback_bars": int(self.swing_bbw_nonexp_lookback_bars),
                "bbw_nonexp_tolerance_frac": float(self.swing_bbw_nonexp_tolerance_frac),
                "ema_dist_max_frac": float(self.swing_ema_dist_max_frac),
                "vol_spike_mult": float(self.swing_vol_spike_mult),
                "rvol_15m_max": float(self.swing_rvol_15m_max),
                "bbwp_s_enter_low": float(self.swing_bbwp_s_enter_low),
                "bbwp_s_enter_high": float(self.swing_bbwp_s_enter_high),
                "bbwp_m_enter_low": float(self.swing_bbwp_m_enter_low),
                "bbwp_m_enter_high": float(self.swing_bbwp_m_enter_high),
                "bbwp_l_enter_low": float(self.swing_bbwp_l_enter_low),
                "bbwp_l_enter_high": float(self.swing_bbwp_l_enter_high),
                "bbwp_s_max": float(self.swing_bbwp_s_enter_high),
                "bbwp_m_max": float(self.swing_bbwp_m_enter_high),
                "bbwp_l_max": float(self.swing_bbwp_l_enter_high),
                "bbwp_stop_high": float(self.swing_bbwp_stop_high),
                "atr_source": "4h",
                "atr_pct_max": float(self.swing_atr_pct_max),
                "os_dev_persist_bars": int(self.swing_os_dev_persist_bars),
                "os_dev_rvol_max": float(self.swing_os_dev_rvol_max),
                "router_eligible": True,
            }
            swing_block.update(self._mode_threshold_overrides("swing"))
            return swing_block
        if mode == "pause":
            pause_block = dict(intraday_block)
            pause_block["mode"] = "pause"
            pause_block["router_eligible"] = False
            return pause_block
        return intraday_block

    def _mode_router_score(self, cfg: Dict[str, float], features: Dict[str, Optional[float]]) -> Dict[str, object]:
        adx = self._safe_float(features.get("adx_4h"))
        ema_dist = self._safe_float(features.get("ema_dist_frac_1h"))
        bbw_pct = self._safe_float(features.get("bb_width_1h_pct"))
        vol_ratio = self._safe_float(features.get("vol_ratio_1h"))
        bbwp_s = self._safe_float(features.get("bbwp_15m_pct"))
        bbwp_m = self._safe_float(features.get("bbwp_1h_pct"))
        bbwp_l = self._safe_float(features.get("bbwp_4h_pct"))
        rvol_15m = self._safe_float(features.get("rvol_15m"))
        atr_1h_pct = self._safe_float(features.get("atr_1h_pct"))
        atr_4h_pct = self._safe_float(features.get("atr_4h_pct"))
        atr_source = str(cfg.get("atr_source", "1h")).strip().lower()
        atr_pct = atr_4h_pct if atr_source == "4h" else atr_1h_pct

        checks: Dict[str, Optional[bool]] = {
            "adx_enter_ok": None if adx is None else bool(adx <= float(cfg["adx_enter_max"])),
            "ema_dist_ok": None if ema_dist is None else bool(ema_dist <= float(cfg["ema_dist_max_frac"])),
            "bbw_1h_pct_ok": None if bbw_pct is None else bool(bbw_pct <= float(cfg["bbw_1h_pct_max"])),
            "vol_ratio_ok": None if vol_ratio is None else bool(vol_ratio <= float(cfg["vol_spike_mult"])),
            "bbwp_s_ok": None if bbwp_s is None else bool(float(cfg["bbwp_s_enter_low"]) <= bbwp_s <= float(cfg["bbwp_s_enter_high"])),
            "bbwp_m_ok": None if bbwp_m is None else bool(float(cfg["bbwp_m_enter_low"]) <= bbwp_m <= float(cfg["bbwp_m_enter_high"])),
            "bbwp_l_ok": None if bbwp_l is None else bool(float(cfg["bbwp_l_enter_low"]) <= bbwp_l <= float(cfg["bbwp_l_enter_high"])),
            "atr_pct_ok": None if atr_pct is None else bool(atr_pct <= float(cfg["atr_pct_max"])),
            "rvol_15m_ok": None if rvol_15m is None else bool(rvol_15m <= float(cfg.get("rvol_15m_max", cfg["os_dev_rvol_max"]))),
        }
        known = [v for v in checks.values() if v is not None]
        passed = int(sum(1 for v in known if bool(v)))
        total = int(len(known))
        ratio = float(passed / total) if total > 0 else 0.0
        score = float(passed) + ratio
        required_fields = [
            "adx_enter_ok",
            "ema_dist_ok",
            "bbw_1h_pct_ok",
            "vol_ratio_ok",
            "bbwp_s_ok",
            "bbwp_m_ok",
            "bbwp_l_ok",
            "atr_pct_ok",
            "rvol_15m_ok",
        ]
        router_eligible = bool(cfg.get("router_eligible", True))
        known_required = [checks.get(k) for k in required_fields]
        eligible = bool(
            router_eligible
            and all(v is not None for v in known_required)
            and all(bool(v) for v in known_required)
        )
        return {
            "checks": checks,
            "passed": int(passed),
            "total": int(total),
            "ratio": float(ratio),
            "score": float(score),
            "eligible": bool(eligible),
            "atr_source": atr_source,
            "atr_pct": atr_pct,
        }

    def _regime_router_state(
        self,
        pair: str,
        clock_ts: int,
        features: Dict[str, Optional[float]],
    ) -> Dict[str, object]:
        default_mode = self._normalize_mode_name(getattr(self, "regime_router_default_mode", "intraday"))
        forced_raw = str(getattr(self, "regime_router_force_mode", "") or "").strip().lower()
        forced_mode = forced_raw if forced_raw in self.MODE_TRADING_WITH_PAUSE else None
        enabled = bool(getattr(self, "regime_router_enabled", True))
        allow_pause = bool(getattr(self, "regime_router_allow_pause", True))

        current_mode = self._normalize_mode_name(self._mode_by_pair.get(pair, default_mode))
        intraday_cfg = self._mode_threshold_block("intraday")
        swing_cfg = self._mode_threshold_block("swing")
        intraday_eval = self._mode_router_score(intraday_cfg, features)
        swing_eval = self._mode_router_score(swing_cfg, features)
        chop_score_info = self._compute_chop_score(pair, features)
        running_active = bool(features.get("running_active", False))
        running_mode_raw = features.get("running_mode")
        running_mode = None
        if running_active and str(running_mode_raw or "").strip():
            running_mode = self._normalize_mode_name(running_mode_raw)
        adx4h = self._safe_float(features.get("adx_4h"))
        close_price = self._safe_float(features.get("close"))
        last_mid = float(self._last_mid_by_pair.get(pair, 0.0) or 0.0)
        last_step = float(self._last_box_step_by_pair.get(pair, 0.0) or 0.0)
        safe_band_half = 0.5 * last_step if last_step > 0 else 0.0
        safe_band_active = bool(last_step > 0.0 and last_mid > 0.0 and close_price is not None)
        price_within_safe_band = (
            bool(abs(close_price - last_mid) <= safe_band_half) if safe_band_active else True
        )
        neutral_step_bps = self._neutral_step_bps(pair, last_mid)
        neutral_spread_threshold = self._neutral_spread_threshold(neutral_step_bps)
        calm_flags: List[bool] = []
        for feat_name, threshold in [
            ("adx_4h", float(intraday_cfg["adx_enter_max"])),
            ("ema_dist_frac_1h", float(intraday_cfg["ema_dist_max_frac"])),
            ("bb_width_1h_pct", float(intraday_cfg["bbw_1h_pct_max"])),
            ("vol_ratio_1h", float(intraday_cfg["vol_spike_mult"])),
            ("bbwp_15m_pct", float(intraday_cfg["bbwp_s_max"])),
            ("bbwp_1h_pct", float(intraday_cfg["bbwp_m_max"])),
            ("bbwp_4h_pct", float(intraday_cfg["bbwp_l_max"])),
        ]:
            val = self._safe_float(features.get(feat_name))
            if val is None:
                continue
            calm_flags.append(bool(val <= threshold))
        calm_ratio = float(sum(1 for x in calm_flags if x) / len(calm_flags)) if calm_flags else 0.0
        intraday_score_adj = float(intraday_eval["score"]) + calm_ratio
        swing_score_adj = float(swing_eval["score"]) - calm_ratio

        intraday_eligible = bool(intraday_eval.get("eligible", False))
        swing_eligible = bool(swing_eval.get("eligible", False))

        score_value = chop_score_info.get("score")
        score_state = bool(self._chop_score_state_by_pair.get(pair, False))
        if score_value is not None:
            enter_thresh = float(chop_score_info.get("enter_score", self.regime_router_score_enter))
            exit_thresh = float(chop_score_info.get("exit_score", self.regime_router_score_exit))
            if score_value >= enter_thresh:
                score_state = True
            elif score_value <= exit_thresh:
                score_state = False
            self._chop_score_state_by_pair[pair] = score_state
            if score_state:
                intraday_score_adj += 0.10
            else:
                swing_score_adj += 0.10

        neutral_bbwp_pct = self._safe_float(features.get("bbwp_15m_pct"))
        neutral_atr_pct = self._safe_float(features.get("atr_pct_15m"))
        neutral_adx_pct = self._neutral_adx_pct(adx4h, float(intraday_cfg["adx_enter_max"]))
        fallback_mid = last_mid if last_mid > 0.0 else (close_price or 0.0)
        spread_bps = self._neutral_spread_bps(features, fallback_mid)
        neutral_bbwp_ok = bool(
            neutral_bbwp_pct is not None
            and self.neutral_bbwp_enter_min_pct <= neutral_bbwp_pct <= self.neutral_bbwp_enter_max_pct
        )
        neutral_bbwp_veto = bool(neutral_bbwp_pct is not None and neutral_bbwp_pct >= self.neutral_bbwp_veto_pct)
        neutral_bbwp_dead = bool(neutral_bbwp_pct is not None and neutral_bbwp_pct <= self.neutral_bbwp_dead_pct)
        neutral_atr_ok = bool(neutral_atr_pct is not None and neutral_atr_pct >= self.neutral_atr_pct_min)
        neutral_trend_entry = bool(neutral_adx_pct is not None and neutral_adx_pct <= self.neutral_adx_enter_pct)
        neutral_trend_exit = bool(neutral_adx_pct is not None and neutral_adx_pct >= self.neutral_adx_exit_pct)
        neutral_trend_veto = bool(neutral_adx_pct is not None and neutral_adx_pct >= self.neutral_adx_veto_pct)
        neutral_spread_ok = bool(spread_bps <= neutral_spread_threshold)
        neutral_dead_vol_block = bool(neutral_bbwp_dead and not neutral_atr_ok)
        neutral_conditions_met = (
            bool(score_state)
            and neutral_bbwp_ok
            and neutral_atr_ok
            and neutral_trend_entry
            and (not neutral_trend_veto)
            and (not neutral_bbwp_veto)
            and neutral_spread_ok
            and not neutral_dead_vol_block
        )
        neutral_must_exit = bool(
            neutral_trend_exit
            or neutral_trend_veto
            or (neutral_bbwp_pct is not None and not neutral_bbwp_ok)
            or neutral_bbwp_veto
            or neutral_dead_vol_block
            or (not neutral_spread_ok)
        )
        neutral_candidate_ready = bool(neutral_conditions_met and (not neutral_must_exit))
        neutral_metrics = {
            "adx_pct": neutral_adx_pct,
            "bbwp_pct": neutral_bbwp_pct,
            "atr_pct": neutral_atr_pct,
            "spread_bps": spread_bps,
            "spread_threshold_bps": neutral_spread_threshold,
            "spread_ok": neutral_spread_ok,
            "bbwp_ok": neutral_bbwp_ok,
            "bbwp_veto": neutral_bbwp_veto,
            "bbwp_dead": neutral_bbwp_dead,
            "atr_ok": neutral_atr_ok,
            "trend_entry": neutral_trend_entry,
            "trend_exit": neutral_trend_exit,
            "trend_veto": neutral_trend_veto,
            "dead_vol_block": neutral_dead_vol_block,
            "candidate_ready": neutral_candidate_ready,
            "must_exit": neutral_must_exit,
            "step_bps": neutral_step_bps,
        }

        margin = max(float(getattr(self, "regime_router_switch_margin", 0.0)), 0.0)
        if forced_mode is not None:
            desired_mode = forced_mode
            desired_reason = "forced_mode"
        elif not enabled:
            desired_mode = current_mode
            desired_reason = "router_disabled"
        else:
            if intraday_eligible:
                desired_mode = "intraday"
                desired_reason = "intraday_eligible"
            elif neutral_candidate_ready:
                desired_mode = "neutral_choppy"
                desired_reason = "neutral_candidate_ready"
            elif swing_eligible:
                desired_mode = "swing"
                desired_reason = "swing_eligible_only"
            else:
                if allow_pause:
                    desired_mode = "pause"
                    desired_reason = "no_mode_eligible_pause"
                else:
                    desired_mode = current_mode
                    desired_reason = "no_mode_eligible_hold_current"

        if score_value is not None and desired_mode in ("intraday", "swing"):
            if score_state and desired_mode == "swing" and intraday_eligible:
                desired_mode = "intraday"
                desired_reason = "score_engaged_bias"
            elif (not score_state) and desired_mode == "intraday" and swing_eligible:
                desired_mode = "swing"
                desired_reason = "score_exited_bias"

        if forced_mode is None and neutral_candidate_ready and desired_mode == "intraday":
            desired_mode = "neutral_choppy"
            desired_reason = "neutral_candidate_ready"
        if forced_mode is None and desired_mode == "neutral_choppy" and neutral_must_exit:
            desired_mode = "intraday"
            desired_reason = "neutral_trend_risk"

        reverse_handoff_allowed = (
            forced_mode is None
            and running_active
            and (running_mode == "swing")
            and (desired_mode in ("intraday", "neutral_choppy"))
            and price_within_safe_band
            and (not neutral_must_exit)
        )
        handoff_blocked_running_inventory = False
        target_mode = str(desired_mode)
        target_reason = str(desired_reason)
        if (
            forced_mode is None
            and running_active
            and (running_mode in self.MODE_TRADING)
            and (desired_mode in self.MODE_TRADING)
            and (desired_mode != running_mode)
            and (not reverse_handoff_allowed)
        ):
            handoff_blocked_running_inventory = True
            target_mode = str(running_mode)
            target_reason = "handoff_blocked_running_inventory"
        handoff_blocked_unsafe_inventory = False
        if (
            forced_mode is None
            and (not handoff_blocked_running_inventory)
            and running_active
            and (running_mode in self.MODE_TRADING)
            and (desired_mode in self.MODE_TRADING)
            and (desired_mode != running_mode)
            and (not price_within_safe_band)
        ):
            handoff_blocked_unsafe_inventory = True
            target_mode = str(running_mode)
            target_reason = "handoff_blocked_unsafe_inventory"

        persist_bars = max(int(getattr(self, "regime_router_switch_persist_bars", 1)), 1)
        cooldown_bars = max(int(getattr(self, "regime_router_switch_cooldown_bars", 0)), 0)
        tf_secs = 15 * 60
        cooldown_until_ts = int(self._mode_cooldown_until_ts_by_pair.get(pair, 0) or 0)
        cooldown_active = bool(cooldown_until_ts and int(clock_ts) < cooldown_until_ts)

        candidate_mode = self._normalize_mode_name(self._mode_candidate_by_pair.get(pair, current_mode))
        candidate_count = int(self._mode_candidate_count_by_pair.get(pair, 0) or 0)
        switched = False

        if forced_mode is not None:
            switched = bool(current_mode != forced_mode)
            current_mode = self._normalize_mode_name(forced_mode)
            candidate_mode = current_mode
            candidate_count = 0
            cooldown_until_ts = 0
            cooldown_active = False
        elif target_mode == current_mode:
            candidate_mode = target_mode
            candidate_count = 0
        else:
            if target_mode == candidate_mode:
                candidate_count += 1
            else:
                candidate_mode = target_mode
                candidate_count = 1
            if (not cooldown_active) and (candidate_count >= persist_bars):
                current_mode = target_mode
                switched = True
                candidate_mode = current_mode
                candidate_count = 0
                cooldown_until_ts = int(clock_ts) + (cooldown_bars * tf_secs)
                cooldown_active = bool(cooldown_until_ts and int(clock_ts) < cooldown_until_ts)

        self._mode_by_pair[pair] = self._normalize_mode_name(current_mode)
        self._mode_candidate_by_pair[pair] = self._normalize_mode_name(candidate_mode)
        self._mode_candidate_count_by_pair[pair] = int(candidate_count)
        self._mode_cooldown_until_ts_by_pair[pair] = int(cooldown_until_ts)

        active_cfg = self._mode_threshold_block(current_mode)
        return {
            "enabled": bool(enabled),
            "forced_mode": forced_mode,
            "active_mode": self._normalize_mode_name(current_mode),
            "active_cfg": active_cfg,
            "desired_mode": self._normalize_mode_name(desired_mode),
            "desired_reason": str(desired_reason),
            "target_mode": self._normalize_mode_name(target_mode),
            "target_reason": str(target_reason),
            "candidate_mode": self._normalize_mode_name(candidate_mode),
            "candidate_count": int(candidate_count),
            "switch_persist_bars": int(persist_bars),
            "switch_cooldown_bars": int(cooldown_bars),
            "switch_margin": float(margin),
            "switch_cooldown_until_ts": int(cooldown_until_ts) if cooldown_until_ts else None,
            "switch_cooldown_active": bool(cooldown_active),
            "switched": bool(switched),
            "running_active": bool(running_active),
            "running_mode": running_mode if running_mode in self.MODE_TRADING_WITH_PAUSE else None,
            "handoff_blocked_running_inventory": bool(handoff_blocked_running_inventory),
            "handoff_blocked_unsafe_inventory": bool(handoff_blocked_unsafe_inventory),
            "reverse_handoff_allowed": bool(reverse_handoff_allowed),
            "inventory_safe_band": bool(price_within_safe_band),
            "inventory_safe_band_half": float(safe_band_half),
            "scores": {
                "calm_ratio": float(calm_ratio),
                "intraday": dict(intraday_eval, **{"score_adjusted": float(intraday_score_adj)}),
                "swing": dict(swing_eval, **{"score_adjusted": float(swing_score_adj)}),
                "chop": dict(chop_score_info),
                "chop_score_state": bool(self._chop_score_state_by_pair.get(pair, False)),
                "neutral": dict(neutral_metrics),
            },
        }

    def _runmode_name(self) -> str:
        rm = None
        try:
            if getattr(self, "dp", None) is not None and hasattr(self.dp, "runmode"):
                rm = getattr(self.dp, "runmode")
        except Exception:
            rm = None
        if rm is None:
            try:
                rm = (self.config or {}).get("runmode")
            except Exception:
                rm = None
        try:
            if hasattr(rm, "value"):
                rm = rm.value
            return str(rm or "").strip().lower()
        except Exception:
            return ""

    def _should_emit_per_candle_history(self) -> bool:
        if not bool(self.emit_per_candle_history_backtest):
            return False
        rm = self._runmode_name()
        return ("backtest" in rm) or ("hyperopt" in rm)

    def _reset_pair_runtime_state(self, pair: str) -> None:
        stores = [
            self._last_written_ts_by_pair,
            self._last_plan_hash_by_pair,
            self._last_plan_base_hash_by_pair,
            self._last_material_plan_payload_by_pair,
            self._last_plan_id_by_pair,
            self._last_decision_seq_by_pair,
            self._event_counter_by_pair,
            self._last_mid_by_pair,
            self._last_box_step_by_pair,
            self._reclaim_until_ts_by_pair,
            self._cooldown_until_ts_by_pair,
            self._micro_reentry_pause_until_ts_by_pair,
            self._stop_timestamps_by_pair,
            self._active_since_ts_by_pair,
            self._running_by_pair,
            self._bbwp_cooloff_by_pair,
            self._os_dev_state_by_pair,
            self._os_dev_candidate_by_pair,
            self._os_dev_candidate_count_by_pair,
            self._os_dev_zero_persist_by_pair,
            self._mrvd_day_poc_prev_by_pair,
            self._cvd_freeze_bars_left_by_pair,
            self._last_adx_by_pair,
            self._adx_rising_count_by_pair,
            self._mode_by_pair,
            self._mode_candidate_by_pair,
            self._mode_candidate_count_by_pair,
            self._mode_cooldown_until_ts_by_pair,
            self._running_mode_by_pair,
            self._mode_at_entry_by_pair,
            self._mode_at_exit_by_pair,
            self._history_emit_end_ts_by_pair,
            self._neutral_box_break_bars_by_pair,
            self._plan_guard_decision_count_by_pair,
            self._breakout_bars_since_by_pair,
            self._breakout_levels_by_pair,
            self._ob_state_by_pair,
            self._meta_drift_prev_box_pos_by_pair,
        ]
        for store in stores:
            store.pop(pair, None)
        if hasattr(self, "_meta_drift_guard") and self._meta_drift_guard is not None:
            self._meta_drift_guard.reset_pair(pair)

    @staticmethod
    def _ts_to_iso(ts: Optional[int]) -> Optional[str]:
        if ts is None:
            return None
        try:
            return pd.to_datetime(int(ts), unit="s", utc=True).isoformat()
        except Exception:
            return None

    def _plan_dir(self, exchange_name: str, pair: str) -> str:
        safe_pair = pair.replace("/", "_").replace(":", "_")
        root_rel_env = str(os.getenv("GRID_PLANS_ROOT_REL", "") or "").strip()
        if root_rel_env:
            root_base = (
                root_rel_env
                if os.path.isabs(root_rel_env)
                else os.path.join("/freqtrade/user_data", root_rel_env)
            )
        else:
            root_base = os.path.join("/freqtrade/user_data", self.plans_root_rel)
        return os.path.join(root_base, exchange_name, safe_pair)

    def _seed_plan_signature_state(self, exchange_name: str, pair: str) -> None:
        need_seq = pair not in self._last_decision_seq_by_pair
        need_id = pair not in self._last_plan_id_by_pair
        need_hash = pair not in self._last_plan_hash_by_pair
        need_material = pair not in self._last_material_plan_payload_by_pair
        if not (need_seq or need_id or need_hash or need_material):
            return

        latest_path = os.path.join(self._plan_dir(exchange_name, pair), "grid_plan.latest.json")
        if not os.path.isfile(latest_path):
            return
        try:
            with open(latest_path, "r", encoding="utf-8") as handle:
                payload = json.load(handle)
            if not isinstance(payload, dict):
                return
        except Exception:
            return

        if need_seq:
            try:
                seq = int(payload.get("decision_seq") or 0)
                if seq > 0:
                    self._last_decision_seq_by_pair[pair] = seq
            except Exception:
                pass

        if need_id:
            plan_id = str(payload.get("plan_id") or "").strip()
            if plan_id:
                self._last_plan_id_by_pair[pair] = plan_id

        if need_hash:
            plan_hash = str(payload.get("plan_hash") or "").strip()
            if plan_hash:
                self._last_plan_hash_by_pair[pair] = plan_hash

        if need_material:
            self._last_material_plan_payload_by_pair[pair] = material_plan_payload(payload)

    def _next_plan_identity(self, exchange_name: str, pair: str) -> Tuple[str, int, Optional[str]]:
        self._seed_plan_signature_state(exchange_name, pair)
        supersedes_plan_id = self._last_plan_id_by_pair.get(pair)
        prev_seq = int(self._last_decision_seq_by_pair.get(pair, 0))
        decision_seq = max(prev_seq + 1, 1)
        return str(uuid4()), int(decision_seq), supersedes_plan_id

    def _write_plan(
        self,
        exchange_name: str,
        pair: str,
        plan: dict,
        base_plan_hash: Optional[str] = None,
    ) -> None:
        if hasattr(self, "_runtime_snapshot"):
            plan["runtime_config"] = self._runtime_snapshot.as_dict()

        out_dir = self._plan_dir(exchange_name, pair)
        os.makedirs(out_dir, exist_ok=True)
        self._seed_plan_signature_state(exchange_name, pair)

        ts_safe = None
        cts = plan.get("candle_ts")
        if cts is not None:
            try:
                dt = datetime.fromtimestamp(int(cts), tz=timezone.utc)
                ts_safe = dt.strftime("%Y%m%dT%H%M%S%z")
            except Exception:
                ts_safe = None

        if ts_safe is None:
            ctime = plan.get("candle_time_utc")
            if ctime:
                try:
                    dt = pd.Timestamp(ctime)
                    if dt.tzinfo is None:
                        dt = dt.tz_localize("UTC")
                    else:
                        dt = dt.tz_convert("UTC")
                    ts_safe = dt.strftime("%Y%m%dT%H%M%S%z")
                except Exception:
                    ts_safe = None

        if ts_safe is None:
            ts = plan.get("ts", datetime.now(timezone.utc).isoformat())
            ts_safe = str(ts).replace(":", "").replace("-", "").replace(".", "")

        latest_path = os.path.join(out_dir, "grid_plan.latest.json")
        archive_path = os.path.join(out_dir, f"grid_plan.{ts_safe}.json")

        schema_errors = validate_schema(plan, "grid_plan.schema.json")
        if schema_errors:
            summary = "; ".join(schema_errors[:3])
            raise ValueError(f"grid_plan schema validation failed: {summary}")

        payload_hash = str(plan.get("plan_hash") or "").strip()
        if not payload_hash:
            payload_hash = compute_plan_hash(plan)
            plan["plan_hash"] = payload_hash
        last_hash = self._last_plan_hash_by_pair.get(pair)
        if last_hash == payload_hash:
            if base_plan_hash is not None:
                self._last_plan_base_hash_by_pair[pair] = base_plan_hash
            self._last_material_plan_payload_by_pair[pair] = material_plan_payload(plan)
            return

        self._atomic_write_json(latest_path, plan)
        self._atomic_write_json(archive_path, plan)

        self._last_plan_hash_by_pair[pair] = payload_hash
        plan_id = str(plan.get("plan_id") or "").strip()
        if plan_id:
            self._last_plan_id_by_pair[pair] = plan_id
        try:
            decision_seq = int(plan.get("decision_seq") or 0)
            if decision_seq > 0:
                self._last_decision_seq_by_pair[pair] = decision_seq
        except Exception:
            pass
        self._last_material_plan_payload_by_pair[pair] = material_plan_payload(plan)
        if base_plan_hash is not None:
            self._last_plan_base_hash_by_pair[pair] = base_plan_hash

    def _decision_log_path(self, exchange_name: str, pair: str) -> Path:
        return Path(self._plan_dir(exchange_name, pair)) / str(
            self.decision_log_filename or "decision_log.jsonl"
        )

    def _event_log_path(self, exchange_name: str, pair: str) -> Path:
        return Path(self._plan_dir(exchange_name, pair)) / str(
            self.event_log_filename or "event_log.jsonl"
        )

    @staticmethod
    def _append_jsonl(path: Path, payload: Dict[str, object]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, sort_keys=True, ensure_ascii=True))
            handle.write("\n")

    @staticmethod
    def _severity_for_code(code: str) -> str:
        cat = category_of_code(str(code)) if is_canonical_code(str(code)) else str(code).split("_", 1)[0]
        c = str(code or "")
        if cat in {"BLOCK", "STOP"}:
            return str(Severity.HARD)
        if cat == "PAUSE":
            return str(Severity.SOFT)
        if cat == "WARN":
            return str(Severity.ADVISORY)
        if c in {
            str(EventType.EVENT_META_DRIFT_HARD),
            str(EventType.EVENT_CHANNEL_STRONG_BREAK_UP),
            str(EventType.EVENT_CHANNEL_STRONG_BREAK_DN),
            str(EventType.EVENT_DONCHIAN_STRONG_BREAK_UP),
            str(EventType.EVENT_DONCHIAN_STRONG_BREAK_DN),
            str(EventType.EVENT_SWEEP_BREAK_RETEST_HIGH),
            str(EventType.EVENT_SWEEP_BREAK_RETEST_LOW),
            str(EventType.EVENT_DATA_GAP_DETECTED),
            str(EventType.EVENT_DATA_MISALIGN_DETECTED),
        }:
            return str(Severity.HARD)
        if c in {
            str(EventType.EVENT_META_DRIFT_SOFT),
            str(EventType.EVENT_SPREAD_SPIKE),
            str(EventType.EVENT_DEPTH_THIN),
            str(EventType.EVENT_JUMP_DETECTED),
            str(EventType.EVENT_POST_ONLY_REJECT_BURST),
        }:
            return str(Severity.ADVISORY)
        return str(Severity.INFO)

    @staticmethod
    def _source_module_for_code(code: str) -> str:
        c = str(code or "")
        if c.startswith("BLOCK_STEP_") or c.startswith("WARN_COST_MODEL_"):
            return str(ModuleName.COST_MODEL)
        if c in {
            str(BlockReason.BLOCK_DRAWDOWN_GUARD),
            str(BlockReason.BLOCK_MAX_STOPS_WINDOW),
            str(StopReason.STOP_DRAWDOWN_GUARD),
        }:
            return str(ModuleName.PROTECTIONS)
        if c.startswith("BLOCK_CAPACITY_") or c.startswith("EXEC_CAPACITY_"):
            return str(ModuleName.CAPACITY_GUARD)
        if c in {
            str(StopReason.STOP_CHANNEL_STRONG_BREAK),
            str(EventType.EVENT_CHANNEL_STRONG_BREAK_UP),
            str(EventType.EVENT_CHANNEL_STRONG_BREAK_DN),
            str(EventType.EVENT_CHANNEL_MIDLINE_TOUCH),
            str(EventType.EVENT_DONCHIAN_STRONG_BREAK_UP),
            str(EventType.EVENT_DONCHIAN_STRONG_BREAK_DN),
        }:
            return str(ModuleName.CHANNEL_MODULE)
        if c in {
            str(EventType.EVENT_SWEEP_WICK_HIGH),
            str(EventType.EVENT_SWEEP_WICK_LOW),
            str(EventType.EVENT_SWEEP_BREAK_RETEST_HIGH),
            str(EventType.EVENT_SWEEP_BREAK_RETEST_LOW),
            str(EventType.EVENT_SESSION_HIGH_SWEEP),
            str(EventType.EVENT_SESSION_LOW_SWEEP),
            str(StopReason.STOP_LIQUIDITY_SWEEP_BREAK_RETEST),
        }:
            return str(ModuleName.LIQUIDITY_SWEEPS)
        if c in {
            str(BlockReason.BLOCK_FRESH_OB_COOLOFF),
            str(BlockReason.BLOCK_BOX_STRADDLE_OB_EDGE),
            str(EventType.EVENT_OB_NEW_BULL),
            str(EventType.EVENT_OB_NEW_BEAR),
            str(EventType.EVENT_OB_TAGGED_BULL),
            str(EventType.EVENT_OB_TAGGED_BEAR),
        }:
            return str(ModuleName.OB_MODULE)
        if c in {
            str(EventType.EVENT_FVG_POC_TAG),
        }:
            return str(ModuleName.FVG_VP)
        if c in {
            str(EventType.EVENT_VRVP_POC_SHIFT),
            str(EventType.EVENT_MICRO_POC_SHIFT),
            str(EventType.EVENT_HVN_TOUCH),
            str(EventType.EVENT_LVN_TOUCH),
            str(EventType.EVENT_LVN_VOID_EXIT),
        }:
            return str(ModuleName.MICRO_VAP)
        if c in {
            str(EventType.EVENT_SPREAD_SPIKE),
            str(EventType.EVENT_DEPTH_THIN),
            str(EventType.EVENT_JUMP_DETECTED),
            str(EventType.EVENT_POST_ONLY_REJECT_BURST),
        }:
            return str(ModuleName.CONFIRM_ENTRY_HOOK)
        if c.startswith("STOP_"):
            return str(ModuleName.STOP_FRAMEWORK)
        if c.startswith("BLOCK_DATA_") or c.startswith("PAUSE_DATA_"):
            return str(ModuleName.DATA_QUALITY_MONITOR)
        if c in {
            str(EventType.EVENT_DATA_GAP_DETECTED),
            str(EventType.EVENT_DATA_MISALIGN_DETECTED),
        }:
            return str(ModuleName.DATA_QUALITY_MONITOR)
        if c.startswith("BLOCK_META_DRIFT_") or c.startswith("EVENT_META_DRIFT_"):
            return str(ModuleName.META_DRIFT_GUARD)
        if c.startswith("REPLAN_"):
            return str(ModuleName.REPLAN_POLICY)
        return str(ModuleName.CONFLUENCE_AGGREGATOR)

    def _next_event_id(self, pair: str, valid_for_candle_ts: int) -> str:
        counter = int(self._event_counter_by_pair.get(pair, 0) + 1)
        self._event_counter_by_pair[pair] = counter
        return f"{self._pair_fs(pair)}-{int(valid_for_candle_ts)}-{counter:04d}"

    def _emit_decision_and_event_logs(
        self,
        exchange_name: str,
        pair: str,
        plan: Dict[str, object],
        *,
        prev_plan_hash: Optional[str],
        new_plan_hash: Optional[str],
        changed_fields: List[str],
        diff_snapshot: Dict[str, Dict[str, object]],
        mode_candidate: Optional[str],
        mode_final: Optional[str],
        start_stability: Dict[str, object],
        meta_drift_state: Dict[str, object],
        planner_health_state: str,
        blocker_codes: List[str],
        warning_codes: List[str],
        stop_codes: List[str],
        close_price: float,
        event_types: Optional[List[str]] = None,
        event_metadata: Optional[Dict[str, Dict[str, object]]] = None,
    ) -> List[str]:
        event_ids: List[str] = []
        valid_for_candle_ts = int(plan.get("valid_for_candle_ts") or 0)
        event_path = self._event_log_path(exchange_name, pair)
        decision_path = self._decision_log_path(exchange_name, pair)
        ts = str(plan.get("generated_at") or datetime.now(timezone.utc).isoformat())

        if bool(getattr(self, "event_log_enabled", True)):
            reason_codes = [str(x) for x in blocker_codes + warning_codes + stop_codes if str(x).strip()]
            taxonomy_codes = [str(x) for x in (event_types or []) if str(x).strip()]
            event_codes = list(dict.fromkeys(reason_codes + taxonomy_codes))
            metadata_by_type = event_metadata if isinstance(event_metadata, dict) else {}
            safe_price = float(close_price) if math.isfinite(float(close_price)) else 0.0
            for code in event_codes:
                event_id = self._next_event_id(pair, valid_for_candle_ts)
                event_meta = dict(metadata_by_type.get(str(code), {})) if str(code) in metadata_by_type else {}
                event_kind = "taxonomy_event" if str(code).startswith("EVENT_") else "reason_code"
                event_row: Dict[str, object] = {
                    "event_id": event_id,
                    "ts": ts,
                    "pair": str(pair),
                    "event_type": str(code),
                    "severity": self._severity_for_code(code),
                    "source_module": self._source_module_for_code(code),
                    "price": safe_price,
                    "side": "long",
                    "metadata": {
                        "action": str(plan.get("action") or ""),
                        "planner_health_state": str(planner_health_state),
                        "canonical_code": bool(is_canonical_code(str(code))),
                        "event_kind": str(event_kind),
                        "taxonomy_event": bool(event_kind == "taxonomy_event"),
                    },
                }
                if event_meta:
                    event_row["metadata"].update(event_meta)
                if validate_schema(event_row, "event_log.schema.json"):
                    continue
                self._append_jsonl(event_path, event_row)
                event_ids.append(event_id)

        if bool(getattr(self, "decision_log_enabled", True)):
            features = plan.get("signals_snapshot")
            if not isinstance(features, dict):
                features = {}
            decision_row: Dict[str, object] = {
                "timestamp": ts,
                "pair": str(pair),
                "mode_candidate": str(mode_candidate or ""),
                "mode_final": str(mode_final or plan.get("mode") or ""),
                "action": str(plan.get("action") or "HOLD"),
                "blockers": [str(x) for x in blocker_codes],
                "key_features_snapshot": {
                    "close": features.get("close"),
                    "rsi_15m": features.get("rsi_15m"),
                    "adx_4h": features.get("adx_4h"),
                    "bbw_1h_pct": features.get("bbw_1h_pct"),
                    "rvol_15m": features.get("rvol_15m"),
                    "price_in_box": features.get("price_in_box"),
                    "start_signal": features.get("start_signal"),
                },
                "box_grid_params": {
                    "box": dict(plan.get("box") or {}),
                    "grid": dict(plan.get("grid") or {}),
                    "risk": dict(plan.get("risk") or {}),
                },
                "start_stability": dict(start_stability or {}),
                "meta_drift": dict(meta_drift_state or {}),
                "planner_health": {
                    "state": str(planner_health_state),
                },
                "replan_decision": str(plan.get("replan_decision") or ""),
                "replan_reasons": [str(x) for x in (plan.get("replan_reasons") or [])],
                "prev_plan_hash": str(prev_plan_hash) if prev_plan_hash else None,
                "new_plan_hash": str(new_plan_hash) if new_plan_hash else None,
                "changed_fields": [str(x) for x in changed_fields],
                "event_ids_emitted": list(event_ids),
                "plan_diff_snapshot": diff_snapshot,
            }
            if not validate_schema(decision_row, "decision_log.schema.json"):
                self._append_jsonl(decision_path, decision_row)

        return event_ids

    def _range_candidate(self, df: DataFrame, lookback: int) -> Tuple[float, float]:
        hi = float(df["high"].rolling(lookback).max().iloc[-1])
        lo = float(df["low"].rolling(lookback).min().iloc[-1])
        return lo, hi

    def _build_box_15m(
        self,
        df: DataFrame,
        *,
        min_width_pct: Optional[float] = None,
        max_width_pct: Optional[float] = None,
    ) -> Tuple[float, float, float, int, float]:
        """
        Build 24h H/L box ± pad (0.35*ATR20 15m) and adjust width into [3.5%..6%]
        deterministically by switching lookback.
        Returns: (lo_p, hi_p, width_pct, used_lookback_bars, pad)
        """
        atr = float(df["atr_15m"].iloc[-1])
        pad = self.atr_pad_mult * atr

        def build_for(lb: int) -> Tuple[float, float, float]:
            lo, hi = self._range_candidate(df, lb)
            lo_p = lo - pad
            hi_p = hi + pad
            mid = (hi_p + lo_p) / 2.0
            width_pct = (hi_p - lo_p) / mid if mid > 0 else 0.0
            return lo_p, hi_p, width_pct

        min_width = float(min_width_pct if min_width_pct is not None else self.min_width_pct)
        max_width = float(max_width_pct if max_width_pct is not None else self.max_width_pct)
        if max_width < min_width:
            max_width = min_width

        # Start with 24h
        lo_p, hi_p, w = build_for(self.box_lookback_24h_bars)
        used = self.box_lookback_24h_bars

        # If too narrow, expand to 48h
        if w < min_width and len(df) >= self.box_lookback_48h_bars:
            lo_p, hi_p, w = build_for(self.box_lookback_48h_bars)
            used = self.box_lookback_48h_bars

        # If too wide, shrink to 18h then 12h
        if w > max_width and len(df) >= self.box_lookback_18h_bars:
            lo_p, hi_p, w = build_for(self.box_lookback_18h_bars)
            used = self.box_lookback_18h_bars

        if w > max_width and len(df) >= self.box_lookback_12h_bars:
            lo_p, hi_p, w = build_for(self.box_lookback_12h_bars)
            used = self.box_lookback_12h_bars

        return lo_p, hi_p, w, used, pad

    @staticmethod
    def _latest_daily_vwap(df: DataFrame) -> Optional[float]:
        if "date" not in df.columns or "volume" not in df.columns:
            return None
        dates = pd.to_datetime(df["date"], utc=True, errors="coerce")
        if dates.isnull().all():
            return None
        latest_day = dates.dropna().iloc[-1].floor("D")
        if pd.isna(latest_day):
            return None
        mask = dates.dt.floor("D") == latest_day
        subset = df.loc[mask]
        if subset.empty:
            return None
        vols = pd.to_numeric(subset["volume"], errors="coerce").fillna(0.0)
        tp = (subset.get("high") + subset.get("low") + subset.get("close")) / 3.0
        tp = pd.to_numeric(tp, errors="coerce").fillna(0.0)
        denom = float(vols.sum())
        if denom <= 0:
            return None
        return float((tp * vols).sum() / denom)

    @staticmethod
    def _is_level_near_box(
        level: Optional[float],
        box_low: float,
        box_high: float,
        step_price: float,
        buffer_frac: float,
        *,
        min_dist_step_mult: float = 1.0,
    ) -> bool:
        if level is None or step_price <= 0.0:
            return False
        buffer = max(float(buffer_frac) * float(step_price), 0.0)
        if not (box_low - buffer <= float(level) <= box_high + buffer):
            return False
        level_val = float(level)
        if level_val < box_low:
            min_dist = float(box_low - level_val)
        elif level_val > box_high:
            min_dist = float(level_val - box_high)
        else:
            min_dist = float(min(level_val - box_low, box_high - level_val))
        threshold = float(max(min_dist_step_mult, 0.0) * float(step_price))
        if threshold <= 0.0:
            threshold = float(step_price)
        return bool(min_dist < threshold)

    def _box_quality_levels(self, lo_p: float, hi_p: float) -> Dict[str, float]:
        lo = float(lo_p)
        hi = float(hi_p)
        if hi < lo:
            lo, hi = hi, lo
        span = hi - lo
        ext_factor = max(float(getattr(self, "box_quality_extension_factor", 1.386)), 1.0)
        ext_delta = ext_factor - 1.0

        if span <= 0.0:
            return {
                "q1": lo,
                "q2": lo,
                "q3": lo,
                "extension_lo": lo,
                "extension_hi": hi,
                "space": "degenerate",
                "extension_factor": float(ext_factor),
            }

        use_log = bool(getattr(self, "box_quality_log_space", True)) and lo > 0.0 and hi > 0.0
        if use_log:
            lo_log = math.log(lo)
            hi_log = math.log(hi)
            log_span = hi_log - lo_log
            if log_span > 0.0:
                q1 = math.exp(lo_log + 0.25 * log_span)
                q2 = math.exp(lo_log + 0.50 * log_span)
                q3 = math.exp(lo_log + 0.75 * log_span)
                ext_lo = math.exp(lo_log - ext_delta * log_span)
                ext_hi = math.exp(hi_log + ext_delta * log_span)
                return {
                    "q1": float(q1),
                    "q2": float(q2),
                    "q3": float(q3),
                    "extension_lo": float(ext_lo),
                    "extension_hi": float(ext_hi),
                    "space": "log",
                    "extension_factor": float(ext_factor),
                }

        q1 = lo + 0.25 * span
        q2 = lo + 0.50 * span
        q3 = lo + 0.75 * span
        ext_lo = lo - ext_delta * span
        ext_hi = hi + ext_delta * span
        return {
            "q1": float(q1),
            "q2": float(q2),
            "q3": float(q3),
            "extension_lo": float(ext_lo),
            "extension_hi": float(ext_hi),
            "space": "linear_fallback",
            "extension_factor": float(ext_factor),
        }

    def _midline_bias_fallback_state(
        self,
        *,
        close: float,
        box_low: float,
        box_high: float,
        step_price: float,
        vrvp_poc: Optional[float],
        channel_midline: Optional[float],
        basis_mid: Optional[float],
        donchian_mid: Optional[float],
        session_vwap: Optional[float],
        daily_vwap: Optional[float],
    ) -> Dict[str, object]:
        lo = float(min(box_low, box_high))
        hi = float(max(box_low, box_high))
        box_mid = float((lo + hi) / 2.0) if (lo + hi) else 0.0
        box_width = float(max(hi - lo, 0.0))
        step_ref = float(max(step_price, 0.0))

        neutral_thresh = float(
            max(
                float(self.midline_bias_poc_neutral_step_frac) * step_ref,
                float(self.midline_bias_poc_neutral_width_frac) * box_width,
            )
        )
        poc = self._safe_float(vrvp_poc)
        poc_dist_from_mid = abs(float(poc) - box_mid) if poc is not None else None
        poc_neutral = bool(poc is None or (poc_dist_from_mid is not None and poc_dist_from_mid <= neutral_thresh))
        enabled = bool(self.midline_bias_fallback_enabled)
        active = bool(enabled and poc_neutral)

        source_buffer = float(
            max(
                float(self.midline_bias_source_buffer_steps) * step_ref,
                float(self.midline_bias_source_buffer_width_frac) * box_width,
            )
        )

        source_candidates = [
            ("channel_midline", channel_midline),
            ("basis_mid", basis_mid),
            ("donchian_mid", donchian_mid),
            ("session_vwap", session_vwap),
            ("daily_vwap", daily_vwap),
            ("box_mid", box_mid),
        ]
        source_used = "box_mid"
        anchor = float(box_mid)
        for source_name, source_value in source_candidates:
            value = self._safe_float(source_value)
            if value is None:
                continue
            if source_name != "box_mid":
                if value < (lo - source_buffer) or value > (hi + source_buffer):
                    continue
            source_used = str(source_name)
            anchor = float(value)
            break

        deadband = float(
            max(
                float(self.midline_bias_deadband_steps) * step_ref,
                float(self.midline_bias_deadband_width_frac) * box_width,
            )
        )
        delta_from_box_mid = float(anchor - box_mid)
        direction = "neutral"
        if delta_from_box_mid > deadband:
            direction = "bullish"
        elif delta_from_box_mid < (-deadband):
            direction = "bearish"

        tp_candidate = None
        if bool(self.midline_bias_tp_candidate_enabled) and active and anchor > float(close):
            tp_candidate = float(anchor)

        return {
            "enabled": bool(enabled),
            "active": bool(active),
            "poc_neutral": bool(poc_neutral),
            "poc_dist_from_mid": float(poc_dist_from_mid) if poc_dist_from_mid is not None else None,
            "poc_neutral_threshold": float(neutral_thresh),
            "box_mid": float(box_mid),
            "source": str(source_used),
            "anchor": float(anchor),
            "delta_from_box_mid": float(delta_from_box_mid),
            "direction": str(direction),
            "deadband": float(deadband),
            "tp_candidate": float(tp_candidate) if tp_candidate is not None else None,
            "source_buffer": float(source_buffer),
        }

    def _update_box_quality(
        self,
        pair: str,
        lo_p: float,
        hi_p: float,
        pad: float,
        lookback: int,
        dataframe: DataFrame,
    ) -> Dict[str, object]:
        mid = (hi_p + lo_p) / 2.0 if (hi_p + lo_p) else 0.0
        width_pct = (hi_p - lo_p) / mid if mid > 0 else 0.0
        pad_pct = (pad / mid) if (mid > 0) else 0.0
        levels = self._box_quality_levels(lo_p, hi_p)
        diagnostics = {
            "lookback_bars": int(lookback),
            "width_pct": float(width_pct),
            "pad": float(pad),
            "pad_pct": float(pad_pct),
            "q1": float(levels["q1"]),
            "q2": float(levels["q2"]),
            "q3": float(levels["q3"]),
            "extension_lo": float(levels["extension_lo"]),
            "extension_hi": float(levels["extension_hi"]),
            "quartile_space": str(levels["space"]),
            "extension_factor": float(levels["extension_factor"]),
        }
        self._box_quality_by_pair[pair] = diagnostics
        return diagnostics

    @staticmethod
    def _box_overlap_fraction(
        lo_a: float, hi_a: float, lo_b: float, hi_b: float
    ) -> float:
        if hi_a <= lo_a or hi_b <= lo_b:
            return 0.0
        overlap_lo = max(lo_a, lo_b)
        overlap_hi = min(hi_a, hi_b)
        if overlap_hi <= overlap_lo:
            return 0.0
        overlap = overlap_hi - overlap_lo
        width = min(hi_a - lo_a, hi_b - lo_b)
        if width <= 0:
            return 0.0
        return float(overlap / width)

    def _box_overlap_prune(self, pair: str, lo_p: float, hi_p: float) -> bool:
        history = self._box_history_by_pair.get(pair)
        if not history:
            return False
        threshold = float(self.box_overlap_prune_threshold)
        for stored_lo, stored_hi in history:
            if self._box_overlap_fraction(lo_p, hi_p, stored_lo, stored_hi) >= threshold:
                return True
        return False

    def _record_box_history(self, pair: str, lo_p: float, hi_p: float) -> None:
        hist = self._box_history_by_pair.get(pair)
        if hist is None:
            hist = deque(maxlen=max(1, int(self.box_overlap_history)))
            self._box_history_by_pair[pair] = hist
        hist.append((float(lo_p), float(hi_p)))

    @staticmethod
    def _bbw_percentile_ok(pct: Optional[float], max_pct: float) -> bool:
        if pct is None or not np.isfinite(float(pct)):
            return False
        return float(pct) <= float(max_pct)

    @staticmethod
    def _bbwp_percentile_last(series: pd.Series, lookback: int) -> Optional[float]:
        if series is None or lookback <= 1 or len(series) < 2:
            return None
        window = series.iloc[-lookback:] if len(series) >= lookback else series
        vals = pd.to_numeric(window, errors="coerce").dropna().astype(float)
        if len(vals) < 2:
            return None
        cur = float(vals.iloc[-1])
        hist = vals.to_numpy(dtype=float)
        return float((np.sum(hist <= cur) / len(hist)) * 100.0)

    def _user_data_dir(self) -> Path:
        cfg = getattr(self, "config", {}) or {}
        base = str(cfg.get("user_data_dir") or "/freqtrade/user_data")
        return Path(base).resolve()

    def _regime_bands_artifact_path(self) -> Optional[Path]:
        run_id = getattr(self, "_neutral_bands_run_id", None)
        if not run_id:
            return None
        art_dir = self._user_data_dir() / self.regime_router_score_artifact_dir / run_id
        return art_dir / self.regime_router_score_artifact_file

    @staticmethod
    def _pair_fs(pair: str) -> str:
        return str(pair or "unknown_pair").replace("/", "_").replace(":", "_").strip("_")

    def _execution_cost_artifact_path(self, pair: str) -> Path:
        base = self._user_data_dir() / str(self.execution_cost_artifact_dir or "artifacts/execution_cost")
        pair_dir = base / self._pair_fs(pair)
        return pair_dir / str(self.execution_cost_artifact_filename or "execution_cost_calibration.latest.json")

    def _load_execution_cost_artifact(self, pair: str) -> Optional[Dict[str, object]]:
        if not bool(getattr(self, "execution_cost_artifact_enabled", True)):
            return None
        path = self._execution_cost_artifact_path(pair)
        if not path.is_file():
            return None

        cache = getattr(self, "_execution_cost_artifact_cache_by_pair", None)
        if cache is None:
            self._execution_cost_artifact_cache_by_pair = {}
            cache = self._execution_cost_artifact_cache_by_pair
        mtime_map = getattr(self, "_execution_cost_artifact_mtime_by_pair", None)
        if mtime_map is None:
            self._execution_cost_artifact_mtime_by_pair = {}
            mtime_map = self._execution_cost_artifact_mtime_by_pair

        try:
            mtime = float(path.stat().st_mtime)
        except Exception:
            mtime = -1.0
        cached_mtime = self._safe_float(mtime_map.get(pair))
        if cached_mtime is not None and abs(cached_mtime - mtime) <= 1e-9:
            cached = cache.get(pair)
            if isinstance(cached, dict):
                return cached

        try:
            with path.open("r", encoding="utf-8") as handle:
                payload = json.load(handle)
        except Exception:
            return None
        if not isinstance(payload, dict):
            return None
        if str(payload.get("pair") or "").strip() not in ("", str(pair)):
            return None
        errors = validate_schema(payload, "execution_cost_calibration.schema.json")
        if errors:
            return None

        generated_at = payload.get("generated_at")
        stale = False
        if generated_at is not None:
            try:
                ts = pd.Timestamp(generated_at)
                if ts.tzinfo is None:
                    ts = ts.tz_localize("UTC")
                age_minutes = (
                    pd.Timestamp.now(tz="UTC") - ts.tz_convert("UTC")
                ).total_seconds() / 60.0
                stale = bool(age_minutes > float(self.execution_cost_artifact_max_age_minutes))
            except Exception:
                stale = False

        normalized = {
            "pair": str(payload.get("pair") or pair),
            "generated_at": payload.get("generated_at"),
            "cost_model_source": str(payload.get("cost_model_source") or "static"),
            "sample_count": int(self._safe_float(payload.get("sample_count")) or 0),
            "stale": bool(stale),
            "spread_pct": self._safe_float(payload.get("realized_spread_pct")),
            "adverse_selection_pct": self._safe_float(payload.get("adverse_selection_pct")),
            "retry_reject_rate": self._safe_float(payload.get("post_only_retry_reject_rate")),
            "missed_fill_rate": self._safe_float(payload.get("missed_fill_opportunity_rate")),
            "recommended_floor_pct": (
                self._safe_float(payload.get("recommended_cost_floor_bps")) / 10_000.0
                if self._safe_float(payload.get("recommended_cost_floor_bps")) is not None
                else None
            ),
            "artifact_path": str(path),
        }
        cache[pair] = normalized
        mtime_map[pair] = float(mtime)
        return normalized

    def _load_regime_bands_entries(self) -> None:
        if self._neutral_bands_loaded:
            return
        path = self._regime_bands_artifact_path()
        if path is None or not path.is_file():
            self._neutral_bands_loaded = True
            return
        try:
            with path.open("r", encoding="utf-8") as f:
                payload = json.load(f)
        except Exception:
            self._neutral_bands_loaded = True
            return
        entries = payload.get("entries") or payload.get("bands") or []
        for entry in entries:
            pair = str(entry.get("pair") or "").strip()
            horizon = str(entry.get("horizon") or "").strip().lower()
            if not pair or not horizon:
                continue
            self._neutral_bands_map[(pair, horizon)] = entry
        self._neutral_bands_loaded = True

    def _neutral_band_entry(self, pair: str, horizon: str) -> Optional[Dict[str, object]]:
        self._load_regime_bands_entries()
        return self._neutral_bands_map.get((pair, horizon.lower()))

    @staticmethod
    def _normalize_from_band(value: Optional[float], band: Optional[Dict[str, object]], key: str) -> Optional[float]:
        if value is None or band is None:
            return None
        features = band.get("features") or {}
        stats = features.get(key) or band.get(key)
        if not isinstance(stats, dict):
            return None
        p10 = stats.get("p10")
        p90 = stats.get("p90")
        if p10 is None or p90 is None:
            return None
        try:
            p10 = float(p10)
            p90 = float(p90)
        except Exception:
            return None
        rng = p90 - p10
        if rng <= 0:
            return None
        val = float(value)
        norm = (val - p10) / rng
        return float(max(0.0, min(1.0, norm)))

    def _neutral_persistence_for_pair(self, pair: str) -> Tuple[int, int]:
        entry = self._neutral_band_entry(pair, "15m")
        raw_value = None
        if entry:
            raw_value = entry.get("persistence_bars")
        if raw_value is None:
            raw_value = self.neutral_persistence_default_enter
        try:
            base = int(round(float(raw_value)))
        except Exception:
            base = int(self.neutral_enter_persist_min)
        clamped = max(self.neutral_enter_persist_min, min(self.neutral_enter_persist_max, base))
        exit_bars = max(1, int(round(clamped * self.neutral_exit_persist_ratio)))
        self._neutral_persistence_state_by_pair[pair] = {"enter": clamped, "exit": exit_bars}
        return clamped, exit_bars

    def _compute_chop_score(self, pair: str, features: Dict[str, Optional[float]]) -> Dict[str, Optional[float]]:
        base_entry = self._neutral_band_entry(pair, "15m")
        adx_entry = self._neutral_band_entry(pair, "4h")
        er_norm = self._normalize_from_band(features.get("er_15m"), base_entry, "er_15m")
        chop_norm = self._normalize_from_band(features.get("chop_15m"), base_entry, "chop_15m")
        atr_norm = self._normalize_from_band(features.get("atr_pct_15m"), base_entry, "atr_pct_15m")
        adx_norm = self._normalize_from_band(features.get("adx_4h"), adx_entry, "adx_4h")
        if None in (er_norm, chop_norm, atr_norm, adx_norm):
            score_value = None
        else:
            score_value = (
                0.35 * (1.0 - er_norm)
                + 0.35 * chop_norm
                + 0.20 * (1.0 - adx_norm)
                + 0.10 * (1.0 - atr_norm)
            )
        enter_score = float(base_entry.get("enter_score", self.regime_router_score_enter)) if base_entry else float(
            self.regime_router_score_enter
        )
        exit_score = float(base_entry.get("exit_score", self.regime_router_score_exit)) if base_entry else float(
            self.regime_router_score_exit
        )
        persistence = int(base_entry.get("persistence_bars", self.regime_router_score_persistence_bars)) if base_entry else int(
            self.regime_router_score_persistence_bars
        )
        neutral_enter_persist, neutral_exit_persist = self._neutral_persistence_for_pair(pair)
        return {
            "score": float(score_value) if score_value is not None else None,
            "enter_score": enter_score,
            "exit_score": exit_score,
            "persistence_bars": persistence,
            "neutral_enter_persist": neutral_enter_persist,
            "neutral_exit_persist": neutral_exit_persist,
            "er_norm": er_norm,
            "chop_norm": chop_norm,
            "atr_norm": atr_norm,
            "adx_norm": adx_norm,
        }
    @staticmethod
    def _vrvp_profile(df: DataFrame, lookback: int, bins: int, value_area_pct: float) -> Dict[str, Optional[float]]:
        if bins <= 1 or len(df) == 0:
            return {"poc": None, "vah": None, "val": None}

        work = df.iloc[-lookback:] if len(df) >= lookback else df
        lows = pd.to_numeric(work["low"], errors="coerce").to_numpy(dtype=float)
        highs = pd.to_numeric(work["high"], errors="coerce").to_numpy(dtype=float)
        closes = pd.to_numeric(work["close"], errors="coerce").to_numpy(dtype=float)
        vols = pd.to_numeric(work["volume"], errors="coerce").to_numpy(dtype=float)

        if len(lows) == 0:
            return {"poc": None, "vah": None, "val": None}

        pmin = float(np.nanmin(lows))
        pmax = float(np.nanmax(highs))
        if not np.isfinite(pmin) or not np.isfinite(pmax):
            return {"poc": None, "vah": None, "val": None}

        if pmax <= pmin:
            px = float(pmin)
            return {"poc": px, "vah": px, "val": px}

        typ = (highs + lows + closes) / 3.0
        edges = np.linspace(pmin, pmax, bins + 1, dtype=float)
        idx = np.searchsorted(edges, typ, side="right") - 1
        idx = np.clip(idx, 0, bins - 1)

        hist = np.zeros(bins, dtype=float)
        for i, vol in zip(idx, vols):
            if np.isfinite(vol) and vol > 0:
                hist[int(i)] += float(vol)

        if not np.isfinite(hist).all() or float(np.sum(hist)) <= 0:
            px = float((pmin + pmax) / 2.0)
            return {"poc": px, "vah": px, "val": px}

        poc_idx = int(np.argmax(hist))
        total = float(np.sum(hist))
        target = float(np.clip(value_area_pct, 0.0, 1.0) * total)
        left = poc_idx
        right = poc_idx
        acc = float(hist[poc_idx])

        while acc < target and (left > 0 or right < bins - 1):
            lv = float(hist[left - 1]) if left > 0 else -1.0
            rv = float(hist[right + 1]) if right < bins - 1 else -1.0
            if rv > lv:
                right += 1
                acc += float(hist[right])
            else:
                left -= 1
                acc += float(hist[left])

        centers = (edges[:-1] + edges[1:]) / 2.0
        poc = float(centers[poc_idx])
        vah = float(edges[right + 1])
        val = float(edges[left])
        return {"poc": poc, "vah": vah, "val": val}

    @staticmethod
    def _interval_overlap_frac(a_low: float, a_high: float, b_low: float, b_high: float) -> float:
        a0 = float(min(a_low, a_high))
        a1 = float(max(a_low, a_high))
        b0 = float(min(b_low, b_high))
        b1 = float(max(b_low, b_high))
        wa = float(a1 - a0)
        if wa <= 0:
            return 0.0
        inter = max(0.0, min(a1, b1) - max(a0, b0))
        return float(inter / wa)

    @staticmethod
    def _mrvd_profile(df: DataFrame, lookback: int, bins: int, value_area_pct: float) -> Dict:
        out = {
            "lookback_bars": int(max(lookback, 0)),
            "bars_used": 0,
            "poc": None,
            "vah": None,
            "val": None,
            "buy_volume": 0.0,
            "sell_volume": 0.0,
            "buy_sell_ratio": None,
            "buy_sell_imbalance": None,
        }
        if bins <= 1 or len(df) == 0:
            return out

        work = df.iloc[-lookback:] if len(df) >= lookback else df
        out["bars_used"] = int(len(work))
        if len(work) == 0:
            return out

        lows = pd.to_numeric(work["low"], errors="coerce").to_numpy(dtype=float)
        highs = pd.to_numeric(work["high"], errors="coerce").to_numpy(dtype=float)
        closes = pd.to_numeric(work["close"], errors="coerce").to_numpy(dtype=float)
        opens = pd.to_numeric(work["open"], errors="coerce").to_numpy(dtype=float)
        vols = pd.to_numeric(work["volume"], errors="coerce").to_numpy(dtype=float)

        if len(lows) == 0:
            return out

        pmin = float(np.nanmin(lows))
        pmax = float(np.nanmax(highs))
        if not np.isfinite(pmin) or not np.isfinite(pmax):
            return out

        buy_total = 0.0
        sell_total = 0.0
        for o, c, v in zip(opens, closes, vols):
            if not np.isfinite(v) or v <= 0:
                continue
            if np.isfinite(c) and np.isfinite(o) and c >= o:
                buy_total += float(v)
            else:
                sell_total += float(v)

        vol_total = buy_total + sell_total
        ratio = (buy_total / sell_total) if sell_total > 0 else None
        imbalance = ((buy_total - sell_total) / vol_total) if vol_total > 0 else None

        out["buy_volume"] = float(buy_total)
        out["sell_volume"] = float(sell_total)
        out["buy_sell_ratio"] = float(ratio) if ratio is not None else None
        out["buy_sell_imbalance"] = float(imbalance) if imbalance is not None else None

        if pmax <= pmin:
            px = float(pmin)
            out["poc"] = px
            out["vah"] = px
            out["val"] = px
            return out

        typ = (highs + lows + closes) / 3.0
        edges = np.linspace(pmin, pmax, bins + 1, dtype=float)
        idx = np.searchsorted(edges, typ, side="right") - 1
        idx = np.clip(idx, 0, bins - 1)

        hist = np.zeros(bins, dtype=float)
        for i, vol in zip(idx, vols):
            if np.isfinite(vol) and vol > 0:
                hist[int(i)] += float(vol)

        if not np.isfinite(hist).all() or float(np.sum(hist)) <= 0:
            px = float((pmin + pmax) / 2.0)
            out["poc"] = px
            out["vah"] = px
            out["val"] = px
            return out

        poc_idx = int(np.argmax(hist))
        total = float(np.sum(hist))
        target = float(np.clip(value_area_pct, 0.0, 1.0) * total)
        left = poc_idx
        right = poc_idx
        acc = float(hist[poc_idx])

        while acc < target and (left > 0 or right < bins - 1):
            lv = float(hist[left - 1]) if left > 0 else -1.0
            rv = float(hist[right + 1]) if right < bins - 1 else -1.0
            if rv > lv:
                right += 1
                acc += float(hist[right])
            else:
                left -= 1
                acc += float(hist[left])

        centers = (edges[:-1] + edges[1:]) / 2.0
        out["poc"] = float(centers[poc_idx])
        out["vah"] = float(edges[right + 1])
        out["val"] = float(edges[left])
        return out

    @staticmethod
    def _pivot_indices(values: np.ndarray, left: int, right: int, is_low: bool) -> List[int]:
        pivots: List[int] = []
        n = len(values)
        if n == 0:
            return pivots
        left = max(int(left), 1)
        right = max(int(right), 1)
        if n < (left + right + 1):
            return pivots

        for i in range(left, n - right):
            v = values[i]
            if not np.isfinite(v):
                continue
            lwin = values[i - left:i]
            rwin = values[i + 1:i + 1 + right]
            if len(lwin) == 0 or len(rwin) == 0:
                continue
            if not np.isfinite(lwin).all() or not np.isfinite(rwin).all():
                continue
            if is_low:
                if v <= float(np.min(lwin)) and v < float(np.min(rwin)):
                    pivots.append(i)
            else:
                if v >= float(np.max(lwin)) and v > float(np.max(rwin)):
                    pivots.append(i)
        return pivots

    def _cvd_state(
        self,
        df: DataFrame,
        lookback: int,
        step_price: float,
        box_low: float,
        box_high: float,
        close: float,
        vrvp_val: Optional[float],
        vrvp_vah: Optional[float],
    ) -> Dict:
        out = {
            "enabled": bool(self.cvd_enabled),
            "lookback_bars": int(lookback),
            "bars_used": 0,
            "cvd": None,
            "cvd_delta": None,
            "near_bottom": False,
            "near_top": False,
            "bull_divergence": False,
            "bear_divergence": False,
            "bull_divergence_near_bottom": False,
            "bear_divergence_near_top": False,
            "bos_up": False,
            "bos_down": False,
            "bos_up_near_bottom": False,
            "bos_down_near_top": False,
            "price_pivot_low_prev": None,
            "price_pivot_low_last": None,
            "price_pivot_high_prev": None,
            "price_pivot_high_last": None,
            "cvd_pivot_low_prev": None,
            "cvd_pivot_low_last": None,
            "cvd_pivot_high_prev": None,
            "cvd_pivot_high_last": None,
            "freeze_bars_left": 0,
            "freeze_active": False,
            "gate_ok": True,
        }
        if not self.cvd_enabled:
            return out

        lb = max(int(lookback), 16)
        work = df.iloc[-lb:] if len(df) >= lb else df
        out["bars_used"] = int(len(work))
        if len(work) < max(self.cvd_bos_lookback + 2, (self.cvd_pivot_left + self.cvd_pivot_right + 3)):
            return out

        lows = pd.to_numeric(work["low"], errors="coerce").to_numpy(dtype=float)
        highs = pd.to_numeric(work["high"], errors="coerce").to_numpy(dtype=float)
        cvd_src = work["cvd_15m"] if "cvd_15m" in work.columns else pd.Series(np.nan, index=work.index)
        cvd_delta_src = (
            work["cvd_delta_15m"] if "cvd_delta_15m" in work.columns else pd.Series(np.nan, index=work.index)
        )
        cvd = pd.to_numeric(cvd_src, errors="coerce").to_numpy(dtype=float)
        cvd_delta = pd.to_numeric(cvd_delta_src, errors="coerce").to_numpy(dtype=float)
        if len(cvd) == 0 or not np.isfinite(cvd[-1]):
            return out

        out["cvd"] = float(cvd[-1])
        if len(cvd_delta) > 0 and np.isfinite(cvd_delta[-1]):
            out["cvd_delta"] = float(cvd_delta[-1])

        near_thr = max(float(self.cvd_near_value_steps) * max(step_price, 0.0), 0.0)
        low_ref = float(vrvp_val) if vrvp_val is not None else float(box_low)
        high_ref = float(vrvp_vah) if vrvp_vah is not None else float(box_high)
        near_bottom = bool(close <= (low_ref + near_thr))
        near_top = bool(close >= (high_ref - near_thr))
        out["near_bottom"] = bool(near_bottom)
        out["near_top"] = bool(near_top)

        low_piv = self._pivot_indices(lows, self.cvd_pivot_left, self.cvd_pivot_right, is_low=True)
        if len(low_piv) >= 2:
            i1, i2 = low_piv[-2], low_piv[-1]
            out["price_pivot_low_prev"] = float(lows[i1]) if np.isfinite(lows[i1]) else None
            out["price_pivot_low_last"] = float(lows[i2]) if np.isfinite(lows[i2]) else None
            out["cvd_pivot_low_prev"] = float(cvd[i1]) if np.isfinite(cvd[i1]) else None
            out["cvd_pivot_low_last"] = float(cvd[i2]) if np.isfinite(cvd[i2]) else None
            if (
                np.isfinite(lows[i1])
                and np.isfinite(lows[i2])
                and np.isfinite(cvd[i1])
                and np.isfinite(cvd[i2])
                and ((len(lows) - 1 - i2) <= int(max(self.cvd_divergence_max_age_bars, 1)))
            ):
                bull_div = bool((lows[i2] < lows[i1]) and (cvd[i2] > cvd[i1]))
                out["bull_divergence"] = bool(bull_div)
                out["bull_divergence_near_bottom"] = bool(bull_div and near_bottom)

        high_piv = self._pivot_indices(highs, self.cvd_pivot_left, self.cvd_pivot_right, is_low=False)
        if len(high_piv) >= 2:
            i1, i2 = high_piv[-2], high_piv[-1]
            out["price_pivot_high_prev"] = float(highs[i1]) if np.isfinite(highs[i1]) else None
            out["price_pivot_high_last"] = float(highs[i2]) if np.isfinite(highs[i2]) else None
            out["cvd_pivot_high_prev"] = float(cvd[i1]) if np.isfinite(cvd[i1]) else None
            out["cvd_pivot_high_last"] = float(cvd[i2]) if np.isfinite(cvd[i2]) else None
            if (
                np.isfinite(highs[i1])
                and np.isfinite(highs[i2])
                and np.isfinite(cvd[i1])
                and np.isfinite(cvd[i2])
                and ((len(highs) - 1 - i2) <= int(max(self.cvd_divergence_max_age_bars, 1)))
            ):
                bear_div = bool((highs[i2] > highs[i1]) and (cvd[i2] < cvd[i1]))
                out["bear_divergence"] = bool(bear_div)
                out["bear_divergence_near_top"] = bool(bear_div and near_top)

        bos_lb = int(max(self.cvd_bos_lookback, 2))
        if len(cvd) >= bos_lb + 1 and np.isfinite(cvd[-1]) and np.isfinite(cvd[-2]):
            prev = cvd[-(bos_lb + 1):-1]
            prev_fin = prev[np.isfinite(prev)]
            if len(prev_fin) > 0:
                prev_max = float(np.max(prev_fin))
                prev_min = float(np.min(prev_fin))
                cur = float(cvd[-1])
                prv = float(cvd[-2])
                bos_up = bool(cur > prev_max and prv <= prev_max)
                bos_down = bool(cur < prev_min and prv >= prev_min)
                out["bos_up"] = bool(bos_up)
                out["bos_down"] = bool(bos_down)
                out["bos_up_near_bottom"] = bool(bos_up and near_bottom)
                out["bos_down_near_top"] = bool(bos_down and near_top)

        return out

    @staticmethod
    def _apply_cvd_rung_bias(
        levels: np.ndarray,
        rung_weights: List[float],
        box_low: float,
        box_high: float,
        bull_div_near_bottom: bool,
        bear_div_near_top: bool,
        strength: float,
        w_min: float,
        w_max: float,
    ) -> List[float]:
        if len(levels) == 0:
            return []
        if len(rung_weights) != len(levels):
            return [float(x) for x in rung_weights]
        if not bull_div_near_bottom and not bear_div_near_top:
            return [float(x) for x in rung_weights]

        width = float(box_high - box_low)
        if width <= 0:
            return [float(x) for x in rung_weights]

        lev = np.array(levels, dtype=float)
        w = np.array(rung_weights, dtype=float)
        pos = np.clip((lev - float(box_low)) / width, 0.0, 1.0)

        s = max(float(strength), 0.0)
        mult = np.ones_like(w)
        if bull_div_near_bottom:
            mult *= (1.0 + s * (1.0 - pos))
        if bear_div_near_top:
            mult *= (1.0 + s * pos)

        out = np.clip(w * mult, float(w_min), float(w_max))
        return [float(x) for x in out.tolist()]

    def _find_numeric_row(
        self,
        row: pd.Series,
        exact: Optional[List[str]] = None,
        contains: Optional[List[str]] = None,
    ) -> Optional[float]:
        exact = exact or []
        contains = contains or []
        idx_map = {str(c).lower(): c for c in row.index}

        for key in exact:
            c = idx_map.get(str(key).lower())
            if c is None:
                continue
            v = self._safe_float(row.get(c))
            if v is not None:
                return v

        if contains:
            for c in row.index:
                lc = str(c).lower()
                if any(token in lc for token in contains):
                    v = self._safe_float(row.get(c))
                    if v is not None:
                        return v
        return None

    def _freqai_overlay_state(
        self,
        last_row: pd.Series,
        close: float,
        step_price: float,
        q1: float,
        q2: float,
        q3: float,
        vrvp_poc: Optional[float],
    ) -> Dict:
        out = {
            "enabled": bool(self.freqai_overlay_enabled),
            "source": "none",
            "do_predict": None,
            "p_range": None,
            "p_breakout": None,
            "ml_confidence": None,
            "strict_predict": bool(self.freqai_overlay_strict_predict),
            "gate_ok": True,
            "breakout_risk_high": False,
            "quick_tp_candidate": None,
        }
        if not self.freqai_overlay_enabled:
            return out

        do_predict_raw = self._find_numeric_row(
            last_row,
            exact=["do_predict", "freqai_do_predict", "predict_ok"],
            contains=["do_predict"],
        )
        do_predict = None
        if do_predict_raw is not None:
            do_predict = 1 if float(do_predict_raw) >= 0.5 else 0

        p_range = self._find_numeric_row(
            last_row,
            exact=["p_range", "prob_range", "range_probability", "&-p_range", "&-s_range"],
            contains=["p_range", "range_prob"],
        )
        p_breakout = self._find_numeric_row(
            last_row,
            exact=["p_breakout", "prob_breakout", "breakout_probability"],
            contains=["p_breakout", "breakout_prob"],
        )
        ml_conf = self._find_numeric_row(
            last_row,
            exact=["ml_confidence", "freqai_confidence", "do_predict_prob", "prediction_confidence"],
            contains=["ml_confidence", "predict_prob", "confidence"],
        )

        source = "none"
        if p_range is not None or p_breakout is not None:
            source = "prob_columns"

        if p_range is None and p_breakout is None:
            s_close = self._find_numeric_row(
                last_row,
                exact=["&-s_close", "s_close", "&-target"],
                contains=["&-s_close", "s_close"],
            )
            if s_close is not None:
                scale = max(float(self.freqai_overlay_breakout_scale), 1e-9)
                pb = float(np.clip(abs(float(s_close)) / scale, 0.0, 1.0))
                p_breakout = pb
                p_range = float(1.0 - pb)
                source = "s_close_proxy"

        if p_range is not None:
            p_range = float(np.clip(p_range, 0.0, 1.0))
        if p_breakout is not None:
            p_breakout = float(np.clip(p_breakout, 0.0, 1.0))
        if p_range is not None and p_breakout is not None:
            s = float(p_range + p_breakout)
            if s > 0:
                p_range = float(p_range / s)
                p_breakout = float(p_breakout / s)

        if ml_conf is not None:
            ml_conf = float(np.clip(ml_conf, 0.0, 1.0))
        elif p_range is not None or p_breakout is not None:
            ml_conf = float(max(p_range or 0.0, p_breakout or 0.0))
        elif do_predict is not None:
            ml_conf = float(1.0 if do_predict == 1 else 0.0)

        gate_ok = True
        if self.freqai_overlay_strict_predict:
            gate_ok = bool(
                do_predict == 1
                and ml_conf is not None
                and ml_conf >= float(self.freqai_overlay_confidence_min)
            )

        breakout_risk_high = bool(
            p_breakout is not None and p_breakout >= float(self.freqai_overlay_breakout_quick_tp_thresh)
        )
        quick_tp_candidate = None
        if breakout_risk_high:
            candidates: List[float] = []
            for px in [vrvp_poc, q2, q1, q3]:
                pxf = self._safe_float(px)
                if pxf is not None and pxf > close:
                    candidates.append(float(pxf))
            if candidates:
                quick_tp_candidate = float(min(candidates))

        out["source"] = source
        out["do_predict"] = do_predict
        out["p_range"] = p_range
        out["p_breakout"] = p_breakout
        out["ml_confidence"] = ml_conf
        out["gate_ok"] = bool(gate_ok)
        out["breakout_risk_high"] = bool(breakout_risk_high)
        out["quick_tp_candidate"] = quick_tp_candidate
        return out

    @staticmethod
    def _apply_ml_rung_safety(
        levels: np.ndarray,
        rung_weights: List[float],
        box_low: float,
        box_high: float,
        p_breakout: Optional[float],
        edge_cut_max: float,
        w_min: float,
        w_max: float,
    ) -> List[float]:
        if p_breakout is None:
            return [float(x) for x in rung_weights]
        if len(levels) == 0 or len(rung_weights) != len(levels):
            return [float(x) for x in rung_weights]
        width = float(box_high - box_low)
        if width <= 0:
            return [float(x) for x in rung_weights]

        risk = float(np.clip(p_breakout, 0.0, 1.0))
        cut = float(max(edge_cut_max, 0.0))
        if risk <= 0 or cut <= 0:
            return [float(x) for x in rung_weights]

        lev = np.array(levels, dtype=float)
        w = np.array(rung_weights, dtype=float)
        pos = np.clip((lev - float(box_low)) / width, 0.0, 1.0)
        edge = np.abs(pos - 0.5) * 2.0
        mult = 1.0 - (risk * cut * edge)
        mult = np.clip(mult, 0.05, 1.0)

        out = np.clip(w * mult, float(w_min), float(w_max))
        return [float(x) for x in out.tolist()]

    @staticmethod
    def _os_dev_from_history(
        closes: np.ndarray,
        mid: float,
        half_span: float,
        range_band: float,
        n_strike: int,
    ) -> Tuple[int, int, int, int]:
        """
        Rebuild os_dev state from historical closes.
        This keeps behavior deterministic in batch backtests where in-memory
        strike counters may not advance candle-by-candle.
        """
        if len(closes) == 0 or half_span <= 0:
            return 0, 0, 0, 0

        state = 0
        candidate = 0
        candidate_count = 0
        zero_persist = 0
        n_strike = max(int(n_strike), 1)

        for c in closes:
            if not np.isfinite(c):
                continue
            norm = (float(c) - float(mid)) / float(half_span)
            raw = 1 if norm > float(range_band) else (-1 if norm < -float(range_band) else 0)

            if raw == state:
                candidate = state
                candidate_count = 0
            else:
                if candidate == raw:
                    candidate_count += 1
                else:
                    candidate = raw
                    candidate_count = 1
                if candidate_count >= n_strike:
                    state = int(raw)
                    candidate = state
                    candidate_count = 0

            if state == 0:
                zero_persist += 1
            else:
                zero_persist = 0

        return int(state), int(candidate), int(candidate_count), int(zero_persist)

    @staticmethod
    def _micro_vap_inside_box(
        df: DataFrame,
        lookback: int,
        bins: int,
        box_low: float,
        box_high: float,
        hvn_quantile: float,
        lvn_quantile: float,
        extrema_count: int,
    ) -> Dict:
        out = {
            "poc": None,
            "hvn_levels": [],
            "lvn_levels": [],
            "density": [],
            "edges": [],
            "lvn_density_threshold": None,
            "top_void": 0.0,
            "bottom_void": 0.0,
            "void_slope": 0.0,
        }
        if bins <= 1 or box_high <= box_low or len(df) == 0:
            return out

        work = df.iloc[-lookback:] if len(df) >= lookback else df
        highs = pd.to_numeric(work["high"], errors="coerce").to_numpy(dtype=float)
        lows = pd.to_numeric(work["low"], errors="coerce").to_numpy(dtype=float)
        closes = pd.to_numeric(work["close"], errors="coerce").to_numpy(dtype=float)
        vols = pd.to_numeric(work["volume"], errors="coerce").to_numpy(dtype=float)
        typ = (highs + lows + closes) / 3.0

        mask = np.isfinite(typ) & np.isfinite(vols) & (vols > 0) & (typ >= box_low) & (typ <= box_high)
        if np.sum(mask) < 2:
            return out

        typ = typ[mask]
        vols = vols[mask]

        edges = np.linspace(float(box_low), float(box_high), int(bins) + 1, dtype=float)
        idx = np.searchsorted(edges, typ, side="right") - 1
        idx = np.clip(idx, 0, int(bins) - 1)
        hist = np.zeros(int(bins), dtype=float)
        for i, vol in zip(idx, vols):
            hist[int(i)] += float(vol)

        total = float(np.sum(hist))
        if total <= 0:
            return out

        dens = hist / total
        centers = (edges[:-1] + edges[1:]) / 2.0
        poc_idx = int(np.argmax(dens))
        poc = float(centers[poc_idx])

        hvn_q = float(np.clip(hvn_quantile, 0.0, 1.0))
        lvn_q = float(np.clip(lvn_quantile, 0.0, 1.0))
        hvn_thr = float(np.quantile(dens, hvn_q))
        lvn_thr = float(np.quantile(dens, lvn_q))

        hvn_idx = np.where(dens >= hvn_thr)[0]
        lvn_idx = np.where(dens <= lvn_thr)[0]

        max_n = max(int(extrema_count), 1)
        if len(hvn_idx) > max_n:
            hvn_idx = hvn_idx[np.argsort(dens[hvn_idx])[-max_n:]]
        if len(lvn_idx) > max_n:
            lvn_idx = lvn_idx[np.argsort(dens[lvn_idx])[:max_n]]

        hvn_levels = sorted([float(centers[i]) for i in hvn_idx])
        lvn_levels = sorted([float(centers[i]) for i in lvn_idx])

        edge_bins = max(2, int(round(int(bins) * 0.12)))
        edge_bins = min(edge_bins, int(bins))
        global_mean = float(np.mean(dens))
        top_mean = float(np.mean(dens[-edge_bins:]))
        bottom_mean = float(np.mean(dens[:edge_bins]))
        if global_mean > 0:
            top_void = float(np.clip((global_mean - top_mean) / global_mean, 0.0, 1.0))
            bottom_void = float(np.clip((global_mean - bottom_mean) / global_mean, 0.0, 1.0))
        else:
            top_void = 0.0
            bottom_void = 0.0
        void_slope = float(max(top_void, bottom_void))

        out["poc"] = poc
        out["hvn_levels"] = hvn_levels
        out["lvn_levels"] = lvn_levels
        out["density"] = [float(x) for x in dens.tolist()]
        out["edges"] = [float(x) for x in edges.tolist()]
        out["lvn_density_threshold"] = float(lvn_thr)
        out["top_void"] = top_void
        out["bottom_void"] = bottom_void
        out["void_slope"] = void_slope
        return out

    @staticmethod
    def _rung_weights_from_micro_vap(
        levels: np.ndarray,
        edges: List[float],
        density: List[float],
        lvn_density_threshold: Optional[float],
        hvn_boost: float,
        lvn_penalty: float,
        w_min: float,
        w_max: float,
    ) -> List[float]:
        n = len(levels)
        if n == 0:
            return []

        try:
            edges_arr = np.array(edges, dtype=float)
            dens_arr = np.array(density, dtype=float)
        except Exception:
            return [1.0] * n

        if len(edges_arr) != len(dens_arr) + 1 or len(dens_arr) == 0:
            return [1.0] * n

        lev = np.array(levels, dtype=float)
        idx = np.searchsorted(edges_arr, lev, side="right") - 1
        idx = np.clip(idx, 0, len(dens_arr) - 1)
        d = dens_arr[idx]

        mean_d = float(np.mean(dens_arr))
        std_d = float(np.std(dens_arr))
        if std_d <= 1e-12:
            z = np.zeros_like(d)
        else:
            z = (d - mean_d) / std_d

        w = 1.0 + float(hvn_boost) * np.maximum(z, 0.0)
        if lvn_density_threshold is not None:
            mask_lvn = d <= float(lvn_density_threshold)
            w = np.where(mask_lvn, w * float(lvn_penalty), w)

        w = np.clip(w, float(w_min), float(w_max))
        return [float(x) for x in w.tolist()]

    def _fvg_stack_state(
        self,
        df: DataFrame,
        lookback: int,
        step_price: float,
        box_low: float,
        box_high: float,
        close: float,
    ) -> Dict:
        out = {
            "enabled": bool(self.fvg_enabled),
            "lookback_bars": int(lookback),
            "count_total": 0,
            "count_bull": 0,
            "count_bear": 0,
            "count_defensive_bull": 0,
            "count_defensive_bear": 0,
            "count_session": 0,
            "nearest_bullish": None,
            "nearest_bearish": None,
            "nearest_defensive_bullish": None,
            "nearest_defensive_bearish": None,
            "straddle_veto_bull": False,
            "straddle_veto_bear": False,
            "straddle_veto": False,
            "imfvg_relax_applied_bull": False,
            "imfvg_relax_applied_bear": False,
            "defensive_bull_conflict": False,
            "defensive_bear_conflict": False,
            "defensive_conflict": False,
            "fresh_defensive_pause": False,
            "session_new_print": False,
            "session_pause_active": False,
            "session_inside_block": False,
            "session_gate_ok": True,
            "gate_ok": True,
            "imfvg_avg_bull": None,
            "imfvg_avg_bear": None,
            "session_fvg_avg": None,
            "positioning_up_avg": None,
            "positioning_down_avg": None,
        }

        if not self.fvg_enabled:
            return out

        if len(df) < 3:
            out["gate_ok"] = False
            out["session_gate_ok"] = False
            return out

        lb = max(int(lookback), 3)
        work = df.iloc[-(lb + 3):] if len(df) > (lb + 3) else df
        n = len(work)
        if n < 3:
            out["gate_ok"] = False
            out["session_gate_ok"] = False
            return out

        highs = pd.to_numeric(work["high"], errors="coerce").to_numpy(dtype=float)
        lows = pd.to_numeric(work["low"], errors="coerce").to_numpy(dtype=float)
        opens = pd.to_numeric(work["open"], errors="coerce").to_numpy(dtype=float)
        closes = pd.to_numeric(work["close"], errors="coerce").to_numpy(dtype=float)
        atr_src = work["atr_15m"] if "atr_15m" in work.columns else pd.Series(np.nan, index=work.index)
        atrs = pd.to_numeric(atr_src, errors="coerce").to_numpy(dtype=float)

        if "date" in work.columns:
            dates = pd.to_datetime(work["date"], utc=True, errors="coerce").to_numpy()
        else:
            dates = pd.to_datetime(work.index, utc=True, errors="coerce").to_numpy()

        last_session = None
        if len(dates) > 0:
            try:
                last_dt = pd.Timestamp(dates[-1])
                if not pd.isna(last_dt):
                    last_session = last_dt.floor("D")
            except Exception:
                last_session = None

        zones: List[Dict] = []
        for i in range(2, n):
            h2 = highs[i - 2]
            l2 = lows[i - 2]
            hi = highs[i]
            lo = lows[i]
            if not np.isfinite(h2) or not np.isfinite(l2) or not np.isfinite(hi) or not np.isfinite(lo):
                continue

            side = None
            z_low = None
            z_high = None

            if lo > h2:
                side = "bull"
                z_low = float(h2)
                z_high = float(lo)
            elif hi < l2:
                side = "bear"
                z_low = float(hi)
                z_high = float(l2)
            else:
                continue

            if z_high <= z_low:
                continue

            gap = float(z_high - z_low)
            atr_ref = float(atrs[i]) if i < len(atrs) and np.isfinite(atrs[i]) and atrs[i] > 0 else None
            gap_atr = (gap / atr_ref) if atr_ref is not None else None
            if gap_atr is not None and gap_atr < float(self.fvg_min_gap_atr):
                continue

            if i - 1 >= 0 and np.isfinite(highs[i - 1]) and np.isfinite(lows[i - 1]):
                r = float(highs[i - 1] - lows[i - 1])
                b = abs(float(closes[i - 1] - opens[i - 1])) if np.isfinite(closes[i - 1]) and np.isfinite(opens[i - 1]) else 0.0
                body_frac = (b / r) if r > 0 else 0.0
                imp_up = bool(closes[i - 1] > opens[i - 1]) if np.isfinite(closes[i - 1]) and np.isfinite(opens[i - 1]) else False
                imp_dn = bool(closes[i - 1] < opens[i - 1]) if np.isfinite(closes[i - 1]) and np.isfinite(opens[i - 1]) else False
            else:
                body_frac = 0.0
                imp_up = False
                imp_dn = False

            defensive = bool(
                self.defensive_fvg_enabled
                and gap_atr is not None
                and gap_atr >= float(self.defensive_fvg_min_gap_atr)
                and body_frac >= float(self.defensive_fvg_body_frac)
                and ((side == "bull" and imp_up) or (side == "bear" and imp_dn))
            )

            mitigated = False
            filled = False
            if i + 1 < n:
                post_l = lows[i + 1:]
                post_h = highs[i + 1:]
                if side == "bull":
                    mitigated = bool(np.any(post_l <= z_high))
                    filled = bool(np.any(post_l <= z_low))
                else:
                    mitigated = bool(np.any(post_h >= z_low))
                    filled = bool(np.any(post_h >= z_high))

            bars_ago = int((n - 1) - i)
            session_match = False
            if last_session is not None:
                try:
                    zi = pd.Timestamp(dates[i])
                    session_match = bool(not pd.isna(zi) and zi.floor("D") == last_session)
                except Exception:
                    session_match = False

            zones.append(
                {
                    "side": side,
                    "low": float(z_low),
                    "high": float(z_high),
                    "mid": float((z_low + z_high) / 2.0),
                    "gap": float(gap),
                    "gap_atr": float(gap_atr) if gap_atr is not None else None,
                    "bars_ago": int(bars_ago),
                    "mitigated": bool(mitigated),
                    "filled": bool(filled),
                    "defensive": bool(defensive),
                    "session_match": bool(session_match),
                }
            )

        if not zones:
            out["gate_ok"] = True
            out["session_gate_ok"] = True
            return out

        bull = [z for z in zones if z["side"] == "bull"]
        bear = [z for z in zones if z["side"] == "bear"]
        def_bull = [z for z in bull if z["defensive"]]
        def_bear = [z for z in bear if z["defensive"]]
        session_zones = [z for z in zones if z["session_match"]]

        out["count_total"] = int(len(zones))
        out["count_bull"] = int(len(bull))
        out["count_bear"] = int(len(bear))
        out["count_defensive_bull"] = int(len(def_bull))
        out["count_defensive_bear"] = int(len(def_bear))
        out["count_session"] = int(len(session_zones))

        def nearest(zs: List[Dict], edge: float, edge_key: str) -> Optional[Dict]:
            if not zs:
                return None
            return min(zs, key=lambda z: abs(float(edge) - float(z[edge_key])))

        def zone_view(z: Optional[Dict]) -> Optional[Dict]:
            if z is None:
                return None
            return {
                "low": float(z["low"]),
                "high": float(z["high"]),
                "mid": float(z["mid"]),
                "gap_atr": z["gap_atr"],
                "bars_ago": int(z["bars_ago"]),
                "mitigated": bool(z["mitigated"]),
                "filled": bool(z["filled"]),
                "defensive": bool(z["defensive"]),
                "session_match": bool(z["session_match"]),
            }

        near_bull = nearest([z for z in bull if not z["filled"]], box_low, "high")
        near_bear = nearest([z for z in bear if not z["filled"]], box_high, "low")
        near_def_bull = nearest([z for z in def_bull if not z["mitigated"]], box_low, "high")
        near_def_bear = nearest([z for z in def_bear if not z["mitigated"]], box_high, "low")

        out["nearest_bullish"] = zone_view(near_bull)
        out["nearest_bearish"] = zone_view(near_bear)
        out["nearest_defensive_bullish"] = zone_view(near_def_bull)
        out["nearest_defensive_bearish"] = zone_view(near_def_bear)

        near_limit = float(max(0.0, self.fvg_straddle_veto_steps * max(step_price, 0.0)))

        def zone_conflict(z: Optional[Dict], edge_price: float, edge_key: str) -> bool:
            if z is None:
                return False
            overlap = min(float(z["high"]), float(box_high)) - max(float(z["low"]), float(box_low))
            inside_or_overlap = bool(overlap > 0.0)
            if inside_or_overlap:
                return True
            if near_limit <= 0:
                return False
            dist = abs(float(edge_price) - float(z[edge_key]))
            return bool(dist <= near_limit)

        bull_conflict_raw = zone_conflict(near_bull, box_low, "high")
        bear_conflict_raw = zone_conflict(near_bear, box_high, "low")

        relax_bull = bool(
            self.imfvg_enabled
            and self.imfvg_mitigated_relax
            and near_bull is not None
            and bool(near_bull["mitigated"])
        )
        relax_bear = bool(
            self.imfvg_enabled
            and self.imfvg_mitigated_relax
            and near_bear is not None
            and bool(near_bear["mitigated"])
        )
        bull_conflict = bool(bull_conflict_raw and not relax_bull)
        bear_conflict = bool(bear_conflict_raw and not relax_bear)
        out["straddle_veto_bull"] = bool(bull_conflict)
        out["straddle_veto_bear"] = bool(bear_conflict)
        out["straddle_veto"] = bool(bull_conflict or bear_conflict)
        out["imfvg_relax_applied_bull"] = bool(relax_bull and bull_conflict_raw)
        out["imfvg_relax_applied_bear"] = bool(relax_bear and bear_conflict_raw)

        def_bull_conflict = zone_conflict(near_def_bull, box_low, "high")
        def_bear_conflict = zone_conflict(near_def_bear, box_high, "low")
        out["defensive_bull_conflict"] = bool(def_bull_conflict)
        out["defensive_bear_conflict"] = bool(def_bear_conflict)
        out["defensive_conflict"] = bool(def_bull_conflict or def_bear_conflict)

        fresh_pause = False
        for z in def_bull + def_bear:
            if z["mitigated"]:
                continue
            if int(z["bars_ago"]) > int(self.defensive_fvg_fresh_bars):
                continue
            if z["side"] == "bull":
                if zone_conflict(z, box_low, "high"):
                    fresh_pause = True
                    break
            elif z["side"] == "bear":
                if zone_conflict(z, box_high, "low"):
                    fresh_pause = True
                    break
        out["fresh_defensive_pause"] = bool(fresh_pause)

        session_new_print = bool(any(int(z["bars_ago"]) == 0 for z in session_zones))
        inside_session = bool(
            any((not z["mitigated"]) and (float(z["low"]) <= float(close) <= float(z["high"])) for z in session_zones)
        )
        session_pause_bars = max(int(self.session_fvg_pause_bars), 0)
        session_pause_active = bool(
            self.session_fvg_enabled
            and session_pause_bars > 0
            and any(int(z["bars_ago"]) < session_pause_bars for z in session_zones)
        )
        session_inside_block = bool(self.session_fvg_enabled and self.session_fvg_inside_gate and inside_session)
        session_gate_ok = bool(not session_pause_active and not session_inside_block)

        out["session_new_print"] = bool(session_new_print)
        out["session_pause_active"] = bool(session_pause_active)
        out["session_inside_block"] = bool(session_inside_block)
        out["session_gate_ok"] = bool(session_gate_ok)
        out["session_high"] = float(max(z["high"] for z in session_zones)) if session_zones else None
        out["session_low"] = float(min(z["low"] for z in session_zones)) if session_zones else None

        imfvg_bull = [float(z["mid"]) for z in bull if z["mitigated"]]
        imfvg_bear = [float(z["mid"]) for z in bear if z["mitigated"]]
        sess_mid = [float(z["mid"]) for z in session_zones]

        out["imfvg_avg_bull"] = float(np.mean(imfvg_bull)) if len(imfvg_bull) else None
        out["imfvg_avg_bear"] = float(np.mean(imfvg_bear)) if len(imfvg_bear) else None
        out["session_fvg_avg"] = float(np.mean(sess_mid)) if len(sess_mid) else None
        out["session_vwap"] = float(np.mean(sess_mid)) if len(sess_mid) else None

        up_edges = [float(z["high"]) for z in bull]
        dn_edges = [float(z["low"]) for z in bear]
        if len(up_edges):
            out["positioning_up_avg"] = float(np.mean(up_edges[-int(self.fvg_position_avg_count):]))
        if len(dn_edges):
            out["positioning_down_avg"] = float(np.mean(dn_edges[-int(self.fvg_position_avg_count):]))

        out["gate_ok"] = bool(
            not out["straddle_veto"]
            and not out["defensive_conflict"]
            and not out["fresh_defensive_pause"]
            and out["session_gate_ok"]
        )
        return out

    def _capacity_hint_state(self, pair: str) -> Dict[str, object]:
        return load_capacity_hint_state(
            pair,
            capacity_hint_path=str(self.capacity_hint_path or ""),
            capacity_hint_hard_block=bool(self.capacity_hint_hard_block),
        )

    def _empirical_cost_sample(
        self,
        pair: str,
        last_row: pd.Series,
        close: float,
    ) -> Dict[str, Optional[float]]:
        spread_direct = self._safe_float(last_row.get("spread_pct"))
        if spread_direct is None and close > 0:
            hi = self._safe_float(last_row.get("high"))
            lo = self._safe_float(last_row.get("low"))
            if hi is not None and lo is not None and hi >= lo:
                spread_direct = float(((hi - lo) / close) * float(self.empirical_spread_proxy_scale))

        open_px = self._safe_float(last_row.get("open"))
        adverse_pct = None
        if open_px is not None and close > 0:
            adverse_pct = float((abs(close - open_px) / close) * float(self.empirical_adverse_selection_scale))

        retry_reject_rate = self._safe_float(last_row.get("post_only_retry_reject_rate"))
        missed_fill_rate = self._safe_float(last_row.get("missed_fill_rate"))
        recommended_floor_pct = self._safe_float(last_row.get("recommended_cost_floor_pct"))
        artifact = self._load_execution_cost_artifact(pair)
        artifact_used = False
        artifact_source = None
        artifact_generated_at = None
        sample_source = "proxy"
        if isinstance(artifact, dict) and not bool(artifact.get("stale", False)):
            artifact_spread = self._safe_float(artifact.get("spread_pct"))
            artifact_adverse = self._safe_float(artifact.get("adverse_selection_pct"))
            artifact_retry = self._safe_float(artifact.get("retry_reject_rate"))
            artifact_missed = self._safe_float(artifact.get("missed_fill_rate"))
            artifact_floor = self._safe_float(artifact.get("recommended_floor_pct"))
            spread_direct = artifact_spread if artifact_spread is not None else spread_direct
            adverse_pct = artifact_adverse if artifact_adverse is not None else adverse_pct
            retry_reject_rate = artifact_retry if artifact_retry is not None else retry_reject_rate
            missed_fill_rate = artifact_missed if artifact_missed is not None else missed_fill_rate
            recommended_floor_pct = artifact_floor if artifact_floor is not None else recommended_floor_pct
            artifact_used = True
            artifact_source = str(artifact.get("cost_model_source") or "empirical")
            artifact_generated_at = artifact.get("generated_at")

        if retry_reject_rate is not None or missed_fill_rate is not None or recommended_floor_pct is not None:
            sample_source = "lifecycle"
        if artifact_used:
            sample_source = (
                "artifact_empirical"
                if str(artifact_source).lower() == "empirical"
                else "artifact_static"
            )

        market_state_bucket = last_row.get("market_state_bucket")
        if market_state_bucket is None:
            market_state_bucket = last_row.get("vol_bucket")
        if market_state_bucket is not None:
            market_state_bucket = str(market_state_bucket).strip() or None

        return {
            "spread_pct": spread_direct,
            "adverse_selection_pct": adverse_pct,
            "retry_reject_rate": retry_reject_rate,
            "missed_fill_rate": missed_fill_rate,
            "recommended_floor_pct": recommended_floor_pct,
            "sample_source": str(sample_source),
            "market_state_bucket": market_state_bucket,
            "live_sample": bool(sample_source in {"artifact_empirical", "lifecycle"}),
            "artifact_used": bool(artifact_used),
            "artifact_source": artifact_source,
            "artifact_generated_at": artifact_generated_at,
            "artifact_path": artifact.get("artifact_path") if isinstance(artifact, dict) else None,
        }

    def _meta_drift_channels(
        self,
        pair: str,
        last_row: pd.Series,
        close: float,
        atr_pct_15m: Optional[float],
        rvol_15m: Optional[float],
        box_position: float,
    ) -> Dict[str, Optional[float]]:
        prev_box_pos = self._safe_float(self._meta_drift_prev_box_pos_by_pair.get(pair))
        box_pos_abs_delta = (
            float(abs(float(box_position) - float(prev_box_pos)))
            if prev_box_pos is not None
            else None
        )
        self._meta_drift_prev_box_pos_by_pair[pair] = float(box_position)

        spread_pct = self._safe_float(last_row.get("spread_pct"))
        if spread_pct is None and close > 0:
            hi = self._safe_float(last_row.get("high"))
            lo = self._safe_float(last_row.get("low"))
            if hi is not None and lo is not None and hi >= lo:
                spread_pct = float(
                    ((hi - lo) / close) * float(max(self.meta_drift_guard_spread_proxy_scale, 0.0))
                )

        return {
            "atr_pct_15m": self._safe_float(atr_pct_15m),
            "rvol_15m": self._safe_float(rvol_15m),
            "spread_pct": spread_pct,
            "box_pos_abs_delta": box_pos_abs_delta,
            "orderbook_imbalance": self._safe_float(last_row.get("orderbook_imbalance")),
            "depth_thinning_score": self._safe_float(last_row.get("depth_thinning_score")),
        }

    def _meta_drift_state(
        self,
        pair: str,
        *,
        last_row: pd.Series,
        close: float,
        atr_pct_15m: Optional[float],
        rvol_15m: Optional[float],
        box_position: float,
        running_active: bool,
    ) -> Dict[str, object]:
        channels = self._meta_drift_channels(
            pair,
            last_row,
            close,
            atr_pct_15m,
            rvol_15m,
            box_position,
        )
        out: Dict[str, object] = {
            "enabled": bool(self.meta_drift_guard_enabled),
            "drift_detected": False,
            "drift_channels": [],
            "severity": "none",
            "recommended_action": "NONE",
            "soft_block": False,
            "hard_stop": False,
            "channels": {},
            "soft_channels": [],
            "hard_channels": [],
            "channels_input": channels,
            "bars_seen": 0,
            "ready_channels": [],
            "min_samples": int(max(int(self.meta_drift_guard_min_samples), 1)),
        }
        if not self.meta_drift_guard_enabled:
            return out

        if (
            (not hasattr(self, "_meta_drift_guard"))
            or self._meta_drift_guard is None
            or int(getattr(self._meta_drift_guard, "_window", 0)) != max(int(self.meta_drift_guard_window), 8)
            or abs(float(getattr(self._meta_drift_guard, "_alpha", 0.0)) - float(np.clip(self.meta_drift_guard_smoothing_alpha, 0.01, 1.0))) > 1e-12
        ):
            self._meta_drift_guard = ExternalMetaDriftGuard(
                self.meta_drift_guard_window,
                self.meta_drift_guard_smoothing_alpha,
            )

        snapshot = self._meta_drift_guard.observe(
            pair,
            channels,
            min_samples=int(max(int(self.meta_drift_guard_min_samples), 1)),
            eps=float(max(float(self.meta_drift_guard_eps), 1e-12)),
            z_soft=float(max(float(self.meta_drift_guard_z_soft), 0.0)),
            z_hard=float(max(float(self.meta_drift_guard_z_hard), 0.0)),
            cusum_k_sigma=float(max(float(self.meta_drift_guard_cusum_k_sigma), 0.0)),
            cusum_soft=float(max(float(self.meta_drift_guard_cusum_soft), 0.0)),
            cusum_hard=float(max(float(self.meta_drift_guard_cusum_hard), 0.0)),
            ph_delta_sigma=float(max(float(self.meta_drift_guard_ph_delta_sigma), 0.0)),
            ph_soft=float(max(float(self.meta_drift_guard_ph_soft), 0.0)),
            ph_hard=float(max(float(self.meta_drift_guard_ph_hard), 0.0)),
            soft_min_channels=int(max(int(self.meta_drift_guard_soft_min_channels), 1)),
            hard_min_channels=int(max(int(self.meta_drift_guard_hard_min_channels), 1)),
        )
        severity = str(snapshot.get("severity", "none"))
        recommended_action = "NONE"
        if severity == "hard":
            recommended_action = "HARD_STOP" if bool(running_active) else "COOLDOWN_EXTEND"
        elif severity == "soft":
            recommended_action = "PAUSE_STARTS"

        out.update(
            {
                "drift_detected": bool(snapshot.get("drift_detected", False)),
                "drift_channels": [str(x) for x in snapshot.get("drift_channels", [])],
                "severity": severity,
                "recommended_action": str(recommended_action),
                "soft_block": bool(severity in {"soft", "hard"}),
                "hard_stop": bool(severity == "hard" and running_active),
                "channels": snapshot.get("channels", {}),
                "soft_channels": [str(x) for x in snapshot.get("soft_channels", [])],
                "hard_channels": [str(x) for x in snapshot.get("hard_channels", [])],
                "bars_seen": int(snapshot.get("bars_seen", 0)),
                "ready_channels": [str(x) for x in snapshot.get("ready_channels", [])],
                "min_samples": int(snapshot.get("min_samples", out["min_samples"])),
            }
        )
        return out

    def _effective_cost_floor(
        self,
        pair: str,
        last_row: pd.Series,
        close: float,
    ) -> Dict[str, object]:
        target_net = float(max(float(self.target_net_step_pct), 0.0040))
        static_floor = float(target_net + max(float(self.est_fee_pct), 0.0) + max(float(self.est_spread_pct), 0.0))
        static_floor = float(max(static_floor, float(self.majors_gross_step_floor_pct), float(self.empirical_cost_floor_min_pct)))
        empirical_conservative_mode = bool(getattr(self, "empirical_cost_conservative_mode", True))
        require_live_samples = bool(getattr(self, "empirical_cost_require_live_samples", True))
        min_live_samples_cfg = self._safe_float(getattr(self, "empirical_cost_min_live_samples", None))
        min_live_samples = int(max(min_live_samples_cfg or float(self.empirical_cost_min_samples), 1.0))

        warning_codes: List[str] = []
        empirical_snapshot: Dict[str, object] = {
            "enabled": bool(self.empirical_cost_enabled),
            "sample_count": 0,
            "stale": True,
            "effective_stale": True,
            "live_sample_count": 0,
            "live_sample_requirement_met": not require_live_samples,
            "requires_live_samples": bool(require_live_samples),
            "min_live_samples_required": int(min_live_samples),
            "conservative_mode": bool(empirical_conservative_mode),
            "spread_pct_percentile": None,
            "adverse_selection_pct_percentile": None,
            "retry_reject_rate_percentile": None,
            "missed_fill_rate_percentile": None,
            "retry_penalty_pct_percentile": None,
            "missed_fill_penalty_pct_percentile": None,
            "total_cost_pct_percentile": None,
            "recommended_floor_pct_percentile": None,
            "floor_candidates_pct": {},
            "selected_empirical_floor_pct": None,
            "empirical_floor_pct": None,
        }
        empirical_sample: Dict[str, Optional[float]] = {}
        selected_empirical_floor: Optional[float] = None

        if self.empirical_cost_enabled:
            if not hasattr(self, "_empirical_cost_calibrator") or self._empirical_cost_calibrator is None:
                self._empirical_cost_calibrator = ExternalEmpiricalCostCalibrator(
                    self.empirical_cost_window
                )
            empirical_sample = self._empirical_cost_sample(pair, last_row, close)
            observed = self._empirical_cost_calibrator.observe(
                pair,
                spread_pct=empirical_sample.get("spread_pct"),
                adverse_selection_pct=empirical_sample.get("adverse_selection_pct"),
                retry_reject_rate=empirical_sample.get("retry_reject_rate"),
                missed_fill_rate=empirical_sample.get("missed_fill_rate"),
                retry_penalty_pct=float(self.empirical_retry_penalty_pct),
                missed_fill_penalty_pct=float(self.empirical_missed_fill_penalty_pct),
                recommended_floor_pct=empirical_sample.get("recommended_floor_pct"),
                sample_source=empirical_sample.get("sample_source"),
                market_state_bucket=empirical_sample.get("market_state_bucket"),
            )
            empirical_snapshot.update(
                {
                    "last_sample_spread_pct": observed.get("spread_pct"),
                    "last_sample_adverse_selection_pct": observed.get("adverse_selection_pct"),
                    "last_sample_retry_reject_rate": observed.get("retry_reject_rate"),
                    "last_sample_missed_fill_rate": observed.get("missed_fill_rate"),
                    "last_sample_total_cost_pct": observed.get("total_pct"),
                    "last_sample_source": observed.get("sample_source"),
                    "last_market_state_bucket": observed.get("market_state_bucket"),
                    "artifact_used": bool(empirical_sample.get("artifact_used", False)),
                    "artifact_source": empirical_sample.get("artifact_source"),
                    "artifact_generated_at": empirical_sample.get("artifact_generated_at"),
                    "artifact_path": empirical_sample.get("artifact_path"),
                }
            )

            snapshot = self._empirical_cost_calibrator.snapshot(
                pair,
                percentile=float(self.empirical_cost_percentile),
                min_samples=int(self.empirical_cost_min_samples),
                stale_bars=int(self.empirical_cost_stale_bars),
            )
            snapshot_p75 = self._empirical_cost_calibrator.snapshot(
                pair,
                percentile=75.0,
                min_samples=int(self.empirical_cost_min_samples),
                stale_bars=int(self.empirical_cost_stale_bars),
            )
            snapshot_p90 = self._empirical_cost_calibrator.snapshot(
                pair,
                percentile=90.0,
                min_samples=int(self.empirical_cost_min_samples),
                stale_bars=int(self.empirical_cost_stale_bars),
            )
            empirical_snapshot.update(snapshot)
            floor_p75 = self._safe_float(snapshot_p75.get("empirical_floor_pct"))
            floor_p90 = self._safe_float(snapshot_p90.get("empirical_floor_pct"))
            recommended_floor = self._safe_float(
                max(
                    x
                    for x in [
                        self._safe_float(snapshot.get("recommended_floor_pct_percentile")),
                        self._safe_float(snapshot_p75.get("recommended_floor_pct_percentile")),
                        self._safe_float(snapshot_p90.get("recommended_floor_pct_percentile")),
                    ]
                    if x is not None
                )
            ) if any(
                x is not None
                for x in [
                    self._safe_float(snapshot.get("recommended_floor_pct_percentile")),
                    self._safe_float(snapshot_p75.get("recommended_floor_pct_percentile")),
                    self._safe_float(snapshot_p90.get("recommended_floor_pct_percentile")),
                ]
            ) else None
            configured_floor = self._safe_float(snapshot.get("empirical_floor_pct"))
            if empirical_conservative_mode:
                selected_empirical_floor = self._safe_float(
                    max(
                        x
                        for x in [configured_floor, floor_p75, floor_p90, recommended_floor]
                        if x is not None
                    )
                ) if any(x is not None for x in [configured_floor, floor_p75, floor_p90, recommended_floor]) else None
            else:
                selected_empirical_floor = self._safe_float(
                    max(x for x in [configured_floor, recommended_floor] if x is not None)
                ) if any(x is not None for x in [configured_floor, recommended_floor]) else None

            live_sample_count = int(self._safe_float(snapshot.get("live_sample_count")) or 0)
            live_sample_requirement_met = bool(
                (not require_live_samples) or (live_sample_count >= int(min_live_samples))
            )
            effective_stale = bool(snapshot.get("stale", True) or (not live_sample_requirement_met))

            empirical_snapshot.update(
                {
                    "effective_stale": bool(effective_stale),
                    "live_sample_count": int(live_sample_count),
                    "live_sample_requirement_met": bool(live_sample_requirement_met),
                    "requires_live_samples": bool(require_live_samples),
                    "min_live_samples_required": int(min_live_samples),
                    "conservative_mode": bool(empirical_conservative_mode),
                    "floor_candidates_pct": {
                        "configured_percentile": configured_floor,
                        "p75": floor_p75,
                        "p90": floor_p90,
                        "recommended": recommended_floor,
                    },
                    "selected_empirical_floor_pct": selected_empirical_floor,
                }
            )
            if bool(empirical_snapshot.get("effective_stale", True)):
                warning_codes.append(str(WarningCode.WARN_COST_MODEL_STALE))

        empirical_floor = self._safe_float(
            empirical_snapshot.get("selected_empirical_floor_pct")
            if self.empirical_cost_enabled
            else None
        )
        chosen_floor = float(static_floor)
        source = "static"
        selection_reason = "empirical_disabled"
        if self.empirical_cost_enabled:
            selection_reason = "empirical_unavailable"
            if bool(empirical_snapshot.get("stale", True)):
                selection_reason = "empirical_snapshot_stale"
            if not bool(empirical_snapshot.get("live_sample_requirement_met", True)):
                selection_reason = "empirical_live_samples_insufficient"
        if empirical_floor is not None and (not bool(empirical_snapshot.get("effective_stale", True))):
            chosen_floor = float(max(static_floor, empirical_floor))
            if empirical_floor > static_floor:
                source = "empirical"
                selection_reason = "empirical_floor_above_static"
            else:
                selection_reason = "static_floor_dominates"

        return {
            "target_net_step_pct": float(target_net),
            "static_floor_pct": float(static_floor),
            "chosen_floor_pct": float(chosen_floor),
            "source": str(source),
            "selection_reason": str(selection_reason),
            "empirical_snapshot": empirical_snapshot,
            "empirical_sample": empirical_sample,
            "warning_codes": warning_codes,
        }

    def _n_level_bounds(
        self,
        active_mode: str,
        atr_mode_pct: Optional[float],
        atr_mode_max: float,
    ) -> Tuple[int, int, Dict[str, object]]:
        return compute_n_level_bounds(
            n_min=int(self.n_min),
            n_max=int(self.n_max),
            active_mode=str(active_mode),
            adapter_enabled=bool(self.n_volatility_adapter_enabled),
            atr_mode_pct=atr_mode_pct,
            atr_mode_max=float(atr_mode_max),
            adapter_strength=float(self.n_volatility_adapter_strength),
        )

    def _grid_sizing(
        self,
        lo_p: float,
        hi_p: float,
        *,
        min_step_pct_required: float,
        n_low: int,
        n_high: int,
    ) -> Dict[str, object]:
        """
        Section 13.1 + 13.3 sizing:
        - derive candidate N from width and target step
        - clamp by mode bounds
        - reduce N until cost floor passes or bounds are exhausted
        """
        mid = (hi_p + lo_p) / 2.0
        width = max(float(hi_p - lo_p), 0.0)
        width_pct = (width / mid) if mid > 0 else 0.0

        required = float(max(min_step_pct_required, 0.0))
        candidate_n = int(np.floor(width_pct / required)) if required > 0 else int(n_high)
        candidate_n = max(candidate_n, 1)
        clamped_n = int(np.clip(candidate_n, int(max(n_low, 1)), int(max(n_high, n_low))))

        attempts: List[Dict[str, object]] = []
        selected_n = clamped_n
        step_pct_actual = 0.0
        step_price = 0.0
        cost_ok = False
        for n_try in range(clamped_n, int(max(n_low, 1)) - 1, -1):
            step_price_try = (width / float(n_try)) if n_try > 0 else 0.0
            step_pct_try = (step_price_try / mid) if mid > 0 else 0.0
            ok = bool(step_pct_try >= required)
            attempts.append(
                {
                    "n": int(n_try),
                    "step_price": float(step_price_try),
                    "step_pct_actual": float(step_pct_try),
                    "cost_ok": bool(ok),
                }
            )
            selected_n = int(n_try)
            step_pct_actual = float(step_pct_try)
            step_price = float(step_price_try)
            cost_ok = bool(ok)
            if ok:
                break

        return {
            "n_levels": int(selected_n),
            "step_price": float(step_price),
            "step_pct_actual": float(step_pct_actual),
            "width_pct": float(width_pct),
            "min_step_pct_required": float(required),
            "candidate_n": int(candidate_n),
            "clamped_n": int(clamped_n),
            "cost_ok": bool(cost_ok),
            "attempts": attempts,
        }

    @staticmethod
    def _nearest_above(close: float, values: Iterable[Optional[float]]) -> Optional[float]:
        candidates: List[float] = []
        for raw in values:
            if raw is None:
                continue
            value = float(raw)
            if not np.isfinite(value):
                continue
            if value > close:
                candidates.append(value)
        if not candidates:
            return None
        return float(min(candidates))

    def _select_tp_price(
        self,
        close: float,
        base_tp: float,
        candidates: Dict[str, Optional[float]],
    ) -> Tuple[float, Dict[str, object]]:
        nearest_value = self._nearest_above(close, candidates.values())
        selected = float(base_tp)
        selected_source = "base_tp"
        if nearest_value is not None and nearest_value < selected:
            selected = float(nearest_value)
            for key, value in candidates.items():
                if value is not None and float(value) == selected:
                    selected_source = str(key)
                    break
        return selected, {"source": selected_source, "nearest_conservative": selected}

    def _select_sl_price(
        self,
        *,
        sl_base: float,
        step_price: float,
        lvn_levels: List[float],
        fvg_state: Dict[str, object],
    ) -> Tuple[float, Dict[str, object]]:
        reasons: List[str] = ["base_sl"]
        candidates = [float(sl_base)]
        if step_price > 0 and lvn_levels:
            lvn_buf = float(max(self.sl_lvn_avoid_steps, 0.0) * step_price)
            near_lvn = any(abs(float(lvl) - float(sl_base)) <= lvn_buf for lvl in lvn_levels)
            if near_lvn:
                candidates.append(float(sl_base - lvn_buf))
                reasons.append("avoid_lvn_void")
        near_bull = fvg_state.get("nearest_bullish") if isinstance(fvg_state, dict) else None
        if isinstance(near_bull, dict):
            zl = self._safe_float(near_bull.get("low"))
            zh = self._safe_float(near_bull.get("high"))
            if zl is not None and zh is not None and zl < zh and zl < sl_base < zh:
                fvg_buf = float(max(self.sl_fvg_buffer_steps, 0.0) * step_price)
                candidates.append(float(zl - fvg_buf))
                reasons.append("avoid_fvg_gap")
        selected = float(min(candidates))
        return selected, {"source": ",".join(reasons), "constraints": reasons}

    def _infer_tick_size(self, step_price: float) -> float:
        inferred = float(max(step_price * float(self.tick_size_step_frac), float(self.tick_size_floor)))
        if inferred <= 0:
            return float(self.tick_size_floor)
        return inferred

    def _breakout_flags(self, close: float, lo_p: float, hi_p: float, step: float) -> Dict[str, bool]:
        close_outside_up = close > hi_p
        close_outside_dn = close < lo_p
        fast_up = (close - hi_p) > (self.fast_stop_step_multiple * step)
        fast_dn = (lo_p - close) > (self.fast_stop_step_multiple * step)
        return {
            "close_outside_up": close_outside_up,
            "close_outside_dn": close_outside_dn,
            "fast_outside_up": fast_up,
            "fast_outside_dn": fast_dn,
        }

    @staticmethod
    def _micro_buy_ratio_state(
        edges: List[float],
        density: List[float],
        *,
        box_low: float,
        box_high: float,
        close: float,
        midband_half_width: float,
        bullish_threshold: float,
        bearish_threshold: float,
    ) -> Dict[str, object]:
        out: Dict[str, object] = {
            "ready": False,
            "buy_ratio": 0.5,
            "sell_ratio": 0.5,
            "bias": 0,
            "in_midband": False,
            "bullish_threshold": float(bullish_threshold),
            "bearish_threshold": float(bearish_threshold),
        }
        try:
            edges_arr = np.array(edges, dtype=float)
            dens_arr = np.array(density, dtype=float)
        except Exception:
            return out
        if len(dens_arr) == 0 or len(edges_arr) != (len(dens_arr) + 1):
            return out
        width = float(box_high - box_low)
        if width <= 0:
            return out
        dens_total = float(np.sum(dens_arr))
        if dens_total <= 0:
            return out
        centers = (edges_arr[:-1] + edges_arr[1:]) / 2.0
        mid = float((box_low + box_high) / 2.0)
        buy_mass = float(np.sum(dens_arr[centers <= mid]))
        sell_mass = float(np.sum(dens_arr[centers > mid]))
        ratio = float(np.clip(buy_mass / max(buy_mass + sell_mass, 1e-12), 0.0, 1.0))
        box_pos = float(np.clip((close - box_low) / width, 0.0, 1.0))
        in_midband = bool(abs(box_pos - 0.5) <= max(float(midband_half_width), 0.0))
        bull_thr = float(np.clip(bullish_threshold, 0.5, 1.0))
        bear_thr = float(np.clip(bearish_threshold, 0.0, 0.5))
        bias = 0
        if in_midband:
            if ratio >= bull_thr:
                bias = 1
            elif ratio <= bear_thr:
                bias = -1
        out.update(
            {
                "ready": True,
                "buy_ratio": float(ratio),
                "sell_ratio": float(1.0 - ratio),
                "bias": int(bias),
                "in_midband": bool(in_midband),
            }
        )
        return out

    @staticmethod
    def _apply_buy_ratio_rung_bias(
        levels: np.ndarray,
        rung_weights: List[float],
        *,
        box_low: float,
        box_high: float,
        bias: int,
        strength: float,
        w_min: float,
        w_max: float,
    ) -> List[float]:
        if int(bias) == 0:
            return [float(x) for x in rung_weights]
        if len(levels) == 0 or len(rung_weights) != len(levels):
            return [float(x) for x in rung_weights]
        width = float(box_high - box_low)
        if width <= 0:
            return [float(x) for x in rung_weights]
        lev = np.array(levels, dtype=float)
        w = np.array(rung_weights, dtype=float)
        pos = np.clip((lev - float(box_low)) / width, 0.0, 1.0)
        s = float(np.clip(strength, 0.0, 1.0))
        if int(bias) > 0:
            mult = 1.0 + (s * (1.0 - pos))
        else:
            mult = 1.0 - (0.8 * s * (1.0 - pos))
            mult = np.clip(mult, 0.2, None)
        out = np.clip(w * mult, float(w_min), float(w_max))
        return [float(x) for x in out.tolist()]

    def _fvg_vp_state(
        self,
        df: DataFrame,
        *,
        fvg_state: Dict[str, object],
        close: float,
        step_price: float,
    ) -> Dict[str, object]:
        out: Dict[str, object] = {
            "enabled": bool(self.fvg_vp_enabled),
            "bins": int(self.fvg_vp_bins),
            "lookback_bars": int(self.fvg_vp_lookback_bars),
            "bull_poc": None,
            "bear_poc": None,
            "nearest_poc": None,
            "nearest_poc_side": None,
            "poc_tagged": False,
            "tag_side": None,
            "zones_used": 0,
        }
        if not self.fvg_vp_enabled:
            return out
        if len(df) < 2:
            return out
        work = df.iloc[-max(int(self.fvg_vp_lookback_bars), 8):]
        highs = pd.to_numeric(work.get("high"), errors="coerce").to_numpy(dtype=float)
        lows = pd.to_numeric(work.get("low"), errors="coerce").to_numpy(dtype=float)
        closes = pd.to_numeric(work.get("close"), errors="coerce").to_numpy(dtype=float)
        vols = pd.to_numeric(work.get("volume"), errors="coerce").to_numpy(dtype=float)
        typ = (highs + lows + closes) / 3.0

        def zone_poc(zone: Optional[Dict[str, object]]) -> Optional[float]:
            if not isinstance(zone, dict):
                return None
            zl = self._safe_float(zone.get("low"))
            zh = self._safe_float(zone.get("high"))
            if zl is None or zh is None or zh <= zl:
                return None
            mask = (
                np.isfinite(typ)
                & np.isfinite(vols)
                & (vols > 0)
                & (typ >= float(zl))
                & (typ <= float(zh))
            )
            if int(np.sum(mask)) < 2:
                return None
            p = typ[mask]
            w = vols[mask]
            bins = max(int(self.fvg_vp_bins), 4)
            edges = np.linspace(float(zl), float(zh), bins + 1, dtype=float)
            idx = np.searchsorted(edges, p, side="right") - 1
            idx = np.clip(idx, 0, bins - 1)
            hist = np.zeros(bins, dtype=float)
            for ii, ww in zip(idx, w):
                hist[int(ii)] += float(ww)
            if float(np.sum(hist)) <= 0:
                return None
            centers = (edges[:-1] + edges[1:]) / 2.0
            return float(centers[int(np.argmax(hist))])

        bull_zone = fvg_state.get("nearest_bullish") if isinstance(fvg_state, dict) else None
        bear_zone = fvg_state.get("nearest_bearish") if isinstance(fvg_state, dict) else None
        bull_poc = zone_poc(bull_zone)
        bear_poc = zone_poc(bear_zone)
        out["bull_poc"] = bull_poc
        out["bear_poc"] = bear_poc
        out["zones_used"] = int((1 if bull_poc is not None else 0) + (1 if bear_poc is not None else 0))
        pool: List[Tuple[str, float]] = []
        if bull_poc is not None:
            pool.append(("bull", float(bull_poc)))
        if bear_poc is not None:
            pool.append(("bear", float(bear_poc)))
        if pool:
            side, price = min(pool, key=lambda x: abs(float(x[1]) - float(close)))
            out["nearest_poc"] = float(price)
            out["nearest_poc_side"] = str(side)
            tag_dist = float(max(float(step_price) * float(self.fvg_vp_poc_tag_step_frac), 0.0))
            if abs(float(close) - float(price)) <= tag_dist:
                out["poc_tagged"] = True
                out["tag_side"] = str(side)
        return out

    def _smart_channel_state(
        self,
        dataframe: DataFrame,
        *,
        close: float,
        step_price: float,
        channel_midline: Optional[float],
        channel_upper: Optional[float],
        channel_lower: Optional[float],
        donchian_high: Optional[float],
        donchian_low: Optional[float],
        rvol_15m: Optional[float],
    ) -> Dict[str, object]:
        out: Dict[str, object] = {
            "enabled": bool(self.smart_channel_enabled),
            "volume_confirm_enabled": bool(self.smart_channel_volume_confirm_enabled),
            "volume_confirmed": True,
            "strong_break_up": False,
            "strong_break_dn": False,
            "donchian_break_up": False,
            "donchian_break_dn": False,
            "midline_touch": False,
            "stop_triggered": False,
            "tp_nudge": None,
        }
        if not self.smart_channel_enabled or len(dataframe) < 2:
            return out
        prev_close = self._safe_float(dataframe["close"].iloc[-2])
        if prev_close is None:
            return out
        buffer = float(max(self.smart_channel_breakout_step_buffer, 0.0) * max(step_price, 0.0))
        vol_confirm = True
        if self.smart_channel_volume_confirm_enabled:
            vol_confirm = bool(
                rvol_15m is not None and float(rvol_15m) >= float(self.smart_channel_volume_rvol_min)
            )
        out["volume_confirmed"] = bool(vol_confirm)
        if channel_upper is not None:
            up_thr = float(channel_upper) + buffer
            out["strong_break_up"] = bool((float(close) > up_thr) and (float(prev_close) <= up_thr))
        if channel_lower is not None:
            dn_thr = float(channel_lower) - buffer
            out["strong_break_dn"] = bool((float(close) < dn_thr) and (float(prev_close) >= dn_thr))
        if donchian_high is not None:
            up_thr_d = float(donchian_high) + buffer
            out["donchian_break_up"] = bool((float(close) > up_thr_d) and (float(prev_close) <= up_thr_d))
        if donchian_low is not None:
            dn_thr_d = float(donchian_low) - buffer
            out["donchian_break_dn"] = bool((float(close) < dn_thr_d) and (float(prev_close) >= dn_thr_d))
        if channel_midline is not None:
            mid = float(channel_midline)
            out["midline_touch"] = bool(
                (float(prev_close) <= mid <= float(close))
                or (float(prev_close) >= mid >= float(close))
            )
            if mid > float(close):
                out["tp_nudge"] = float(min(mid, float(close) + (float(self.smart_channel_tp_nudge_step_multiple) * max(step_price, 0.0))))
        stop_hit = bool(
            (out["strong_break_up"] or out["strong_break_dn"] or out["donchian_break_up"] or out["donchian_break_dn"])
            and vol_confirm
        )
        out["stop_triggered"] = bool(stop_hit)
        return out

    def _zigzag_contraction_state(self, dataframe: DataFrame) -> Dict[str, object]:
        out: Dict[str, object] = {
            "enabled": bool(self.zigzag_contraction_enabled),
            "lookback_bars": int(self.zigzag_contraction_lookback_bars),
            "ratio_max": float(self.zigzag_contraction_ratio_max),
            "ready": False,
            "ok": True,
            "recent_range": None,
            "prev_range": None,
            "ratio": None,
        }
        if not self.zigzag_contraction_enabled:
            return out
        lb = max(int(self.zigzag_contraction_lookback_bars), 2)
        if len(dataframe) < (2 * lb):
            return out
        highs = pd.to_numeric(dataframe["high"], errors="coerce")
        lows = pd.to_numeric(dataframe["low"], errors="coerce")
        recent_high = self._safe_float(highs.iloc[-lb:].max())
        recent_low = self._safe_float(lows.iloc[-lb:].min())
        prev_high = self._safe_float(highs.iloc[-(2 * lb):-lb].max())
        prev_low = self._safe_float(lows.iloc[-(2 * lb):-lb].min())
        if None in {recent_high, recent_low, prev_high, prev_low}:
            return out
        recent_range = float(max(float(recent_high) - float(recent_low), 0.0))
        prev_range = float(max(float(prev_high) - float(prev_low), 0.0))
        ratio = (recent_range / prev_range) if prev_range > 0 else None
        ok = bool(ratio is None or ratio <= float(self.zigzag_contraction_ratio_max))
        out.update(
            {
                "ready": True,
                "ok": bool(ok),
                "recent_range": float(recent_range),
                "prev_range": float(prev_range),
                "ratio": float(ratio) if ratio is not None else None,
            }
        )
        return out

    def _informative_ohlc_frame(self, dataframe: DataFrame, tf: str) -> DataFrame:
        suffix = f"_{str(tf).strip()}"
        required = {
            f"open{suffix}": "open",
            f"high{suffix}": "high",
            f"low{suffix}": "low",
            f"close{suffix}": "close",
        }
        if not all(col in dataframe.columns for col in required):
            return pd.DataFrame(columns=["date", "open", "high", "low", "close"])
        frame = pd.DataFrame(
            {
                "date": pd.to_datetime(
                    dataframe["date"] if "date" in dataframe.columns else dataframe.index,
                    utc=True,
                    errors="coerce",
                ),
                "open": pd.to_numeric(dataframe[f"open{suffix}"], errors="coerce"),
                "high": pd.to_numeric(dataframe[f"high{suffix}"], errors="coerce"),
                "low": pd.to_numeric(dataframe[f"low{suffix}"], errors="coerce"),
                "close": pd.to_numeric(dataframe[f"close{suffix}"], errors="coerce"),
            }
        )
        frame = frame.dropna(subset=["date", "open", "high", "low", "close"])
        if frame.empty:
            return frame
        frame = frame.drop_duplicates(subset=["date"], keep="last").sort_values("date").reset_index(drop=True)
        return frame

    def _order_block_state(
        self,
        *,
        pair: str,
        dataframe: DataFrame,
        close: float,
        step_price: float,
        box_low: float,
        box_high: float,
    ) -> Dict[str, object]:
        out: Dict[str, object] = {
            "enabled": bool(self.ob_enabled),
            "tf": str(self.ob_tf),
            "bull": None,
            "bear": None,
            "bull_fresh": False,
            "bear_fresh": False,
            "bull_valid": False,
            "bear_valid": False,
            "fresh_block": False,
            "fresh_block_sides": [],
            "straddle_veto": False,
            "straddle_side": None,
            "straddle_level": None,
            "tp_mid": None,
            "tp_edge": None,
            "event_new_bull": False,
            "event_new_bear": False,
            "event_tagged_bull": False,
            "event_tagged_bear": False,
        }
        if not bool(self.ob_enabled):
            return out

        cfg = OrderBlockConfig(
            enabled=bool(self.ob_enabled),
            tf=str(self.ob_tf or "1h"),
            use_wick_zone=bool(self.ob_use_wick_zone),
            impulse_lookahead=int(self.ob_impulse_lookahead),
            impulse_atr_len=int(self.ob_impulse_atr_len),
            impulse_atr_mult=float(self.ob_impulse_atr_mult),
            fresh_bars=int(self.ob_fresh_bars),
            max_age_bars=int(self.ob_max_age_bars),
            mitigation_mode=str(self.ob_mitigation_mode or "wick"),
        )
        ob_frame = self._informative_ohlc_frame(dataframe, cfg.tf)
        snapshot = build_order_block_snapshot(ob_frame, cfg)

        bull = snapshot.bull
        bear = snapshot.bear
        bull_dict = {
            "created_ts": int(bull.created_ts),
            "top": float(bull.top),
            "bottom": float(bull.bottom),
            "mid": float(bull.mid),
            "mitigated": bool(bull.mitigated),
            "last_mitigated_ts": int(bull.last_mitigated_ts) if bull.last_mitigated_ts is not None else None,
            "age_bars": int(snapshot.bull_age_bars or 0),
            "fresh": bool(snapshot.bull_fresh),
            "valid": bool(snapshot.bull_valid),
        } if bull is not None else None
        bear_dict = {
            "created_ts": int(bear.created_ts),
            "top": float(bear.top),
            "bottom": float(bear.bottom),
            "mid": float(bear.mid),
            "mitigated": bool(bear.mitigated),
            "last_mitigated_ts": int(bear.last_mitigated_ts) if bear.last_mitigated_ts is not None else None,
            "age_bars": int(snapshot.bear_age_bars or 0),
            "fresh": bool(snapshot.bear_fresh),
            "valid": bool(snapshot.bear_valid),
        } if bear is not None else None

        prev = self._ob_state_by_pair.get(pair)
        prev_exists = isinstance(prev, dict)
        prev_bull_created_ts = prev.get("bull_created_ts") if prev_exists else None
        prev_bear_created_ts = prev.get("bear_created_ts") if prev_exists else None
        prev_bull_mitigated_ts = prev.get("bull_last_mitigated_ts") if prev_exists else None
        prev_bear_mitigated_ts = prev.get("bear_last_mitigated_ts") if prev_exists else None

        bull_created_ts = int(bull.created_ts) if bull is not None else None
        bear_created_ts = int(bear.created_ts) if bear is not None else None
        bull_last_mitigated_ts = int(bull.last_mitigated_ts) if bull is not None and bull.last_mitigated_ts is not None else None
        bear_last_mitigated_ts = int(bear.last_mitigated_ts) if bear is not None and bear.last_mitigated_ts is not None else None

        event_new_bull = bool(prev_exists and bull_created_ts is not None and bull_created_ts != prev_bull_created_ts)
        event_new_bear = bool(prev_exists and bear_created_ts is not None and bear_created_ts != prev_bear_created_ts)
        event_tagged_bull = bool(
            prev_exists
            and bull_last_mitigated_ts is not None
            and bull_last_mitigated_ts != prev_bull_mitigated_ts
        )
        event_tagged_bear = bool(
            prev_exists
            and bear_last_mitigated_ts is not None
            and bear_last_mitigated_ts != prev_bear_mitigated_ts
        )

        self._ob_state_by_pair[pair] = {
            "bull_created_ts": bull_created_ts,
            "bear_created_ts": bear_created_ts,
            "bull_last_mitigated_ts": bull_last_mitigated_ts,
            "bear_last_mitigated_ts": bear_last_mitigated_ts,
        }

        fresh_block_sides: List[str] = []
        price_buf = max(float(step_price), 0.0)
        if bear_dict and bool(bear_dict.get("valid")) and bool(bear_dict.get("fresh")) and (not bool(bear_dict.get("mitigated"))):
            if close <= float(bear_dict["top"]) + price_buf:
                fresh_block_sides.append("bear")
        if bull_dict and bool(bull_dict.get("valid")) and bool(bull_dict.get("fresh")) and (not bool(bull_dict.get("mitigated"))):
            if close >= float(bull_dict["bottom"]) - price_buf:
                fresh_block_sides.append("bull")
        fresh_block = bool(fresh_block_sides)

        straddle_side = None
        straddle_level = None
        straddle_veto = False
        if bear_dict and bool(bear_dict.get("valid")):
            straddle_side = "bear"
            straddle_level = float(bear_dict["bottom"])
        elif bull_dict and bool(bull_dict.get("valid")):
            straddle_side = "bull"
            straddle_level = float(bull_dict["top"])
        if straddle_level is not None and step_price > 0 and box_high > box_low:
            straddle_mult = float(max(self.ob_straddle_min_step_mult, 0.0))
            straddle_veto = self._is_level_near_box(
                straddle_level,
                box_low,
                box_high,
                step_price,
                straddle_mult,
                min_dist_step_mult=straddle_mult if straddle_mult > 0 else 1.0,
            )

        tp_mid = None
        tp_edge = None
        opposite = bear_dict if bear_dict and bool(bear_dict.get("valid")) else None
        if opposite is not None and step_price > 0:
            max_dist = float(max(self.ob_tp_nudge_max_steps, 0.0) * step_price)
            for key, value in (
                ("tp_mid", float(opposite["mid"])),
                ("tp_edge", float(opposite["bottom"])),
            ):
                if value <= close:
                    continue
                if value <= box_high:
                    continue
                if max_dist > 0 and (value - close) > max_dist:
                    continue
                if key == "tp_mid":
                    tp_mid = float(value)
                else:
                    tp_edge = float(value)

        out.update(
            {
                "bull": bull_dict,
                "bear": bear_dict,
                "bull_fresh": bool(snapshot.bull_fresh),
                "bear_fresh": bool(snapshot.bear_fresh),
                "bull_valid": bool(snapshot.bull_valid),
                "bear_valid": bool(snapshot.bear_valid),
                "fresh_block": bool(fresh_block),
                "fresh_block_sides": fresh_block_sides,
                "straddle_veto": bool(straddle_veto),
                "straddle_side": straddle_side,
                "straddle_level": float(straddle_level) if straddle_level is not None else None,
                "tp_mid": float(tp_mid) if tp_mid is not None else None,
                "tp_edge": float(tp_edge) if tp_edge is not None else None,
                "event_new_bull": bool(event_new_bull),
                "event_new_bear": bool(event_new_bear),
                "event_tagged_bull": bool(event_tagged_bull),
                "event_tagged_bear": bool(event_tagged_bear),
            }
        )
        return out

    def _session_sweep_state(
        self,
        dataframe: DataFrame,
        *,
        step_price: float = 0.0,
        box_low: Optional[float] = None,
        box_high: Optional[float] = None,
    ) -> Dict[str, object]:
        out: Dict[str, object] = {
            "enabled": bool(self.session_sweep_enabled and self.sweeps_enabled),
            "session_high_prev": None,
            "session_low_prev": None,
            "sweep_high": False,
            "sweep_low": False,
            "break_retest_high": False,
            "break_retest_low": False,
            "break_retest_high_recent": False,
            "break_retest_low_recent": False,
            "tp_nudge": None,
            "stop_triggered": False,
            "block_start": False,
            "through_box_edge": False,
            "events_recent": [],
        }
        if (not self.session_sweep_enabled) or (not self.sweeps_enabled) or len(dataframe) < 3:
            return out

        cfg = LiquiditySweepConfig(
            enabled=bool(self.sweeps_enabled),
            pivot_len=int(self.sweep_pivot_len),
            max_age_bars=int(self.sweep_max_age_bars),
            break_buffer_mode=str(self.sweep_break_buffer_mode),
            break_buffer_value=float(self.sweep_break_buffer_value),
            retest_window_bars=int(self.sweep_retest_window_bars),
            retest_buffer_mode=str(self.sweep_retest_buffer_mode),
            retest_buffer_value=float(self.sweep_retest_buffer_value),
            stop_if_through_box_edge=bool(self.sweep_stop_if_through_box_edge),
            retest_validation_mode=str(self.sweep_retest_validation_mode),
            min_level_separation_steps=float(self.sweep_min_level_separation_steps),
        )
        state = analyze_liquidity_sweeps(
            dataframe,
            cfg=cfg,
            step_price=float(max(step_price, 0.0)),
            box_low=self._safe_float(box_low),
            box_high=self._safe_float(box_high),
            event_hold_bars=int(max(self.session_sweep_retest_lookback_bars, 1)),
        )
        out.update(
            {
                "enabled": bool(state.get("enabled", False)),
                "session_high_prev": self._safe_float(state.get("swing_high")),
                "session_low_prev": self._safe_float(state.get("swing_low")),
                "sweep_high": bool(state.get("sweep_high", False)),
                "sweep_low": bool(state.get("sweep_low", False)),
                "break_retest_high": bool(state.get("break_retest_high", False)),
                "break_retest_low": bool(state.get("break_retest_low", False)),
                "break_retest_high_recent": bool(state.get("break_retest_high_recent", False)),
                "break_retest_low_recent": bool(state.get("break_retest_low_recent", False)),
                "tp_nudge": self._safe_float(state.get("tp_nudge")),
                "stop_triggered": bool(state.get("stop_triggered", False)),
                "block_start": bool(state.get("block_start", False)),
                "through_box_edge": bool(state.get("through_box_edge", False)),
                "events_recent": list(state.get("events_recent") or []),
                "swing_high": self._safe_float(state.get("swing_high")),
                "swing_low": self._safe_float(state.get("swing_low")),
                "swing_high_index": state.get("swing_high_index"),
                "swing_low_index": state.get("swing_low_index"),
                "break_level_high": self._safe_float(state.get("break_level_high")),
                "break_level_low": self._safe_float(state.get("break_level_low")),
                "retest_validation_mode": str(state.get("retest_validation_mode", self.sweep_retest_validation_mode)),
            }
        )
        return out

    def _order_flow_state(
        self,
        *,
        last_row: pd.Series,
        close: float,
        prev_close: Optional[float],
    ) -> Dict[str, object]:
        out: Dict[str, object] = {
            "enabled": bool(self.order_flow_enabled),
            "spread_pct": None,
            "depth_thinning_score": None,
            "orderbook_imbalance": None,
            "jump_pct": None,
            "flags": [],
            "soft_veto": False,
            "hard_block": False,
            "confidence_modifier": 1.0,
        }
        if not self.order_flow_enabled:
            return out
        spread_pct = self._safe_float(last_row.get("spread_pct"))
        if spread_pct is None and close > 0:
            hi = self._safe_float(last_row.get("high"))
            lo = self._safe_float(last_row.get("low"))
            if hi is not None and lo is not None and hi >= lo:
                spread_pct = float(((hi - lo) / close) * 0.10)
        depth = self._safe_float(last_row.get("depth_thinning_score"))
        imbalance = self._safe_float(last_row.get("orderbook_imbalance"))
        jump_pct = None
        if prev_close is not None and prev_close > 0:
            jump_pct = float(abs(float(close) - float(prev_close)) / float(prev_close))
        flags: List[str] = []
        if spread_pct is not None and spread_pct >= float(self.order_flow_spread_soft_max_pct):
            flags.append(str(EventType.EVENT_SPREAD_SPIKE))
        if depth is not None and depth >= float(self.order_flow_depth_thin_soft_max):
            flags.append(str(EventType.EVENT_DEPTH_THIN))
        if imbalance is not None and abs(float(imbalance)) >= float(self.order_flow_imbalance_extreme):
            flags.append(str(EventType.EVENT_POST_ONLY_REJECT_BURST))
        if jump_pct is not None and jump_pct >= float(self.order_flow_jump_soft_max_pct):
            flags.append(str(EventType.EVENT_JUMP_DETECTED))
        flags = list(dict.fromkeys(flags))
        soft_veto = bool(len(flags) >= int(max(self.order_flow_soft_veto_min_flags, 1)))
        hard_block = bool(self.order_flow_hard_block and soft_veto)
        penalty = float(max(float(self.order_flow_confidence_penalty_per_flag), 0.0))
        confidence = float(np.clip(1.0 - (penalty * len(flags)), 0.05, 1.0))
        out.update(
            {
                "spread_pct": spread_pct,
                "depth_thinning_score": depth,
                "orderbook_imbalance": imbalance,
                "jump_pct": jump_pct,
                "flags": flags,
                "soft_veto": bool(soft_veto),
                "hard_block": bool(hard_block),
                "confidence_modifier": float(confidence),
            }
        )
        return out

    def _drawdown_guard_state(self, dataframe: DataFrame) -> Dict[str, object]:
        out: Dict[str, object] = {
            "enabled": bool(self.drawdown_guard_enabled),
            "lookback_bars": int(self.drawdown_guard_lookback_bars),
            "max_pct": float(self.drawdown_guard_max_pct),
            "peak_price": None,
            "drawdown_pct": 0.0,
            "triggered": False,
        }
        if not self.drawdown_guard_enabled:
            return out
        closes = pd.to_numeric(dataframe["close"], errors="coerce").dropna().astype(float)
        lb = max(int(self.drawdown_guard_lookback_bars), 2)
        if len(closes) < 2:
            return out
        window = closes.iloc[-lb:] if len(closes) > lb else closes
        peak = self._safe_float(window.max())
        if peak is None or peak <= 0:
            return out
        current = float(window.iloc[-1])
        dd = float(np.clip((float(peak) - float(current)) / float(peak), 0.0, 1.0))
        triggered = bool(dd >= float(self.drawdown_guard_max_pct))
        out.update(
            {
                "peak_price": float(peak),
                "drawdown_pct": float(dd),
                "triggered": bool(triggered),
            }
        )
        return out

    def _max_stops_window_state(self, pair: str, clock_ts: int) -> Dict[str, object]:
        dq = self._stop_timestamps_by_pair.get(pair)
        if dq is None:
            dq = deque()
            self._stop_timestamps_by_pair[pair] = dq
        window_secs = int(max(float(self.max_stops_window_minutes), 0.0) * 60.0)
        cutoff = int(clock_ts - max(window_secs, 0))
        while dq and int(dq[0]) < cutoff:
            dq.popleft()
        count = int(len(dq))
        blocked = bool(
            self.max_stops_window_enabled
            and int(self.max_stops_window_count) > 0
            and count >= int(self.max_stops_window_count)
        )
        return {
            "enabled": bool(self.max_stops_window_enabled),
            "window_minutes": float(self.max_stops_window_minutes),
            "max_count": int(self.max_stops_window_count),
            "count": int(count),
            "blocked": bool(blocked),
            "block_reason": str(BlockReason.BLOCK_MAX_STOPS_WINDOW) if blocked else None,
        }

    def _register_stop_timestamp(self, pair: str, clock_ts: int) -> None:
        dq = self._stop_timestamps_by_pair.get(pair)
        if dq is None:
            dq = deque()
            self._stop_timestamps_by_pair[pair] = dq
        dq.append(int(clock_ts))

    def _micro_reentry_state(
        self,
        *,
        pair: str,
        clock_ts: int,
        close: float,
        micro_poc: Optional[float],
        step_price: float,
    ) -> Dict[str, object]:
        until_ts = int(self._micro_reentry_pause_until_ts_by_pair.get(pair, 0) or 0)
        active = bool(until_ts > int(clock_ts))
        reclaim_ok = True
        if bool(self.micro_reentry_require_poc_reclaim) and micro_poc is not None and step_price > 0:
            reclaim_floor = float(micro_poc) - (float(self.micro_reentry_poc_buffer_steps) * float(step_price))
            reclaim_ok = bool(float(close) >= reclaim_floor)
        if active and reclaim_ok:
            self._micro_reentry_pause_until_ts_by_pair.pop(pair, None)
            until_ts = 0
            active = False
        block = bool(active and (not reclaim_ok))
        return {
            "enabled": True,
            "active": bool(active),
            "until_ts": int(until_ts) if until_ts > 0 else None,
            "until_utc": self._ts_to_iso(int(until_ts)) if until_ts > 0 else None,
            "reclaim_ok": bool(reclaim_ok),
            "block_reason": str(BlockReason.BLOCK_RECLAIM_NOT_CONFIRMED) if block else None,
            "pause_bars": int(max(int(self.micro_reentry_pause_bars), 0)),
        }

    # ========== Main indicators + plan write ==========
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        pair = metadata.get("pair", "UNKNOWN/UNKNOWN")

        # ---- 15m indicators ----
        dataframe["atr_15m"] = ta.ATR(dataframe, timeperiod=self.atr_period_15m)
        dataframe["rsi_15m"] = ta.RSI(dataframe, timeperiod=self.rsi_period_15m)
        tp_15m = qtpylib.typical_price(dataframe)
        bb_15m = qtpylib.bollinger_bands(tp_15m, window=self.bb_window, stds=self.bb_stds)
        dataframe["bb_mid_15m"] = bb_15m["mid"]
        dataframe["bb_upper_15m"] = bb_15m["upper"]
        dataframe["bb_lower_15m"] = bb_15m["lower"]
        dataframe["bb_width_15m"] = (dataframe["bb_upper_15m"] - dataframe["bb_lower_15m"]) / dataframe["bb_mid_15m"]
        dataframe["vol_sma20_15m"] = dataframe["volume"].rolling(self.rvol_window_15m).mean()
        dataframe["rvol_15m"] = dataframe["volume"] / dataframe["vol_sma20_15m"]
        sign_body = np.sign(pd.to_numeric(dataframe["close"], errors="coerce") - pd.to_numeric(dataframe["open"], errors="coerce"))
        sign_fallback = np.sign(pd.to_numeric(dataframe["close"], errors="coerce").diff().fillna(0.0))
        sign_eff = np.where(sign_body != 0.0, sign_body, sign_fallback)
        dataframe["cvd_delta_15m"] = pd.to_numeric(dataframe["volume"], errors="coerce").fillna(0.0) * sign_eff
        dataframe["cvd_15m"] = dataframe["cvd_delta_15m"].cumsum()

        # Use rolling VWAP to avoid lookahead bias in backtesting/runtime checks.
        dataframe["vwap_15m"] = qtpylib.rolling_vwap(
            dataframe,
            window=self.box_lookback_24h_bars,
            min_periods=1,
        )
        dataframe["donchian_high_15m"] = dataframe["high"].rolling(
            window=max(int(self.donchian_lookback_bars), 1),
            min_periods=1,
        ).max()
        dataframe["donchian_low_15m"] = dataframe["low"].rolling(
            window=max(int(self.donchian_lookback_bars), 1),
            min_periods=1,
        ).min()
        dataframe["donchian_mid_15m"] = (
            dataframe["donchian_high_15m"] + dataframe["donchian_low_15m"]
        ) / 2.0
        basis_raw = (
            (pd.to_numeric(dataframe["close"], errors="coerce") - pd.to_numeric(dataframe["vwap_15m"], errors="coerce"))
            / pd.to_numeric(dataframe["vwap_15m"], errors="coerce").replace(0.0, np.nan)
        )
        basis_window = max(int(self.basis_band_window), 2)
        dataframe["basis_15m"] = basis_raw
        dataframe["basis_mid_15m"] = basis_raw.rolling(window=basis_window, min_periods=1).mean()
        dataframe["basis_std_15m"] = basis_raw.rolling(window=basis_window, min_periods=1).std().fillna(0.0)
        dataframe["basis_upper_15m"] = dataframe["basis_mid_15m"] + (
            float(self.basis_band_stds) * dataframe["basis_std_15m"]
        )
        dataframe["basis_lower_15m"] = dataframe["basis_mid_15m"] - (
            float(self.basis_band_stds) * dataframe["basis_std_15m"]
        )

        # 7d extremes on 15m
        dataframe["hi_7d"] = dataframe["high"].rolling(self.extremes_7d_bars).max()
        dataframe["lo_7d"] = dataframe["low"].rolling(self.extremes_7d_bars).min()

        # Need enough data
        if len(dataframe) < self.startup_candle_count:
            return dataframe

        history_mode = bool(self._should_emit_per_candle_history())
        history_in_progress = bool(self._history_emit_in_progress_by_pair.get(pair, False))
        if history_mode and not history_in_progress:
            frame_end_ts = None
            try:
                dt_last = pd.Timestamp(dataframe["date"].iloc[-1])
                if dt_last.tzinfo is None:
                    dt_last = dt_last.tz_localize("UTC")
                else:
                    dt_last = dt_last.tz_convert("UTC")
                frame_end_ts = int(dt_last.timestamp())
            except Exception:
                frame_end_ts = None

            prev_emitted_end = self._history_emit_end_ts_by_pair.get(pair)
            if frame_end_ts is not None and prev_emitted_end == frame_end_ts:
                return dataframe

            self._history_emit_in_progress_by_pair[pair] = True
            try:
                self._reset_pair_runtime_state(pair)
                start_idx = max(int(self.startup_candle_count) - 1, 0)
                for i in range(start_idx, len(dataframe)):
                    frame = dataframe.iloc[: i + 1].copy()
                    self.populate_indicators(frame, metadata)
            finally:
                self._history_emit_in_progress_by_pair[pair] = False
            if frame_end_ts is not None:
                self._history_emit_end_ts_by_pair[pair] = int(frame_end_ts)
            return dataframe

        # Informative decorator output can include timeframe-suffixed aliases
        # (e.g. `bb_mid_1h_1h`). Normalize them to canonical keys.
        alias_columns = {
            "bb_mid_1h": ("bb_mid_1h_1h",),
            "bb_mid_4h": ("bb_mid_4h_4h",),
            "adx_4h": ("adx_4h_4h",),
        }
        for canonical, candidates in alias_columns.items():
            if canonical in dataframe.columns:
                continue
            for alt in candidates:
                if alt in dataframe.columns:
                    dataframe[canonical] = dataframe[alt]
                    break

        if not self._validate_feature_contract(dataframe, pair):
            return dataframe

        last = dataframe.iloc[-1]
        close = float(last["close"])
        data_quality = self._run_data_quality_checks(dataframe, pair)
        data_quality_ok = bool(data_quality.get("ok", True))
        data_quality_reasons = data_quality.get("reasons", [])
        planner_health_state = self._planner_health_state(data_quality_ok, data_quality_reasons)
        planner_health_ok = bool(planner_health_state == "ok")
        rsi = self._safe_float(last.get("rsi_15m"))
        vwap = self._safe_float(last.get("vwap_15m"))
        gate_cfg = self._gate_profile_values()
        gate_profile = str(gate_cfg.get("profile", "strict"))
        gate_adx_4h_max = float(gate_cfg.get("adx_4h_max", self.adx_4h_max))
        gate_adx_4h_exit_min = float(gate_adx_4h_max)
        gate_adx_4h_exit_max = float(gate_adx_4h_exit_min)
        gate_adx_rising_bars = 1
        gate_bbw_1h_pct_max = float(gate_cfg.get("bbw_1h_pct_max", self.bbw_1h_pct_max))
        gate_bbw_nonexp_lookback_bars = int(gate_cfg.get("bbw_nonexp_lookback_bars", self.bbw_nonexp_lookback_bars))
        gate_bbw_nonexp_tolerance_frac = float(
            gate_cfg.get("bbw_nonexp_tolerance_frac", self.bbw_nonexp_tolerance_frac)
        )
        gate_ema_dist_max_frac = float(gate_cfg.get("ema_dist_max_frac", self.ema_dist_max_frac))
        gate_vol_spike_mult = float(gate_cfg.get("vol_spike_mult", self.vol_spike_mult))
        gate_rvol_15m_max = float(gate_cfg.get("rvol_15m_max", self.rvol_15m_max))
        gate_context_7d_hard_veto = bool(gate_cfg.get("context_7d_hard_veto", self.context_7d_hard_veto))
        gate_bbwp_s_enter_low = 0.0
        gate_bbwp_s_enter_high = float(gate_cfg.get("bbwp_s_max", self.bbwp_s_max))
        gate_bbwp_m_enter_low = 0.0
        gate_bbwp_m_enter_high = float(gate_cfg.get("bbwp_m_max", self.bbwp_m_max))
        gate_bbwp_l_enter_low = 0.0
        gate_bbwp_l_enter_high = float(gate_cfg.get("bbwp_l_max", self.bbwp_l_max))
        gate_bbwp_s_max = float(gate_bbwp_s_enter_high)
        gate_bbwp_m_max = float(gate_bbwp_m_enter_high)
        gate_bbwp_l_max = float(gate_bbwp_l_enter_high)
        gate_bbwp_stop_high = float(gate_cfg.get("bbwp_veto_pct", self.bbwp_veto_pct))
        gate_bbwp_veto_pct = float(gate_cfg.get("bbwp_veto_pct", self.bbwp_veto_pct))
        gate_bbwp_cooloff_trigger_pct = float(gate_cfg.get("bbwp_cooloff_trigger_pct", self.bbwp_cooloff_trigger_pct))
        gate_bbwp_cooloff_release_s = float(gate_cfg.get("bbwp_cooloff_release_s", self.bbwp_cooloff_release_s))
        gate_bbwp_cooloff_release_m = float(gate_cfg.get("bbwp_cooloff_release_m", self.bbwp_cooloff_release_m))
        gate_atr_source = "1h"
        gate_atr_pct_max = float(self.intraday_atr_pct_max)
        gate_os_dev_persist_bars = int(gate_cfg.get("os_dev_persist_bars", self.os_dev_persist_bars))
        gate_os_dev_rvol_max = float(gate_cfg.get("os_dev_rvol_max", self.os_dev_rvol_max))
        gate_start_min_pass_ratio = float(gate_cfg.get("start_min_gate_pass_ratio", 1.0))
        active_mode = self._normalize_mode_name(getattr(self, "regime_router_default_mode", "intraday"))
        mode_cfg: Dict[str, float] = self._mode_threshold_block(active_mode)
        router_state: Dict[str, object] = {}
        router_clock_ts = int(datetime.now(timezone.utc).timestamp())
        try:
            if "date" in dataframe.columns:
                router_dt = pd.Timestamp(last["date"])
                if router_dt.tzinfo is None:
                    router_dt = router_dt.tz_localize("UTC")
                else:
                    router_dt = router_dt.tz_convert("UTC")
                router_clock_ts = int(router_dt.timestamp())
            elif isinstance(dataframe.index, pd.DatetimeIndex):
                router_dt = pd.Timestamp(dataframe.index[-1])
                if router_dt.tzinfo is None:
                    router_dt = router_dt.tz_localize("UTC")
                else:
                    router_dt = router_dt.tz_convert("UTC")
                router_clock_ts = int(router_dt.timestamp())
        except Exception:
            pass

        # ---- pull informative columns (1h / 4h) ----
        adx4h = None
        if "adx_4h_4h" in dataframe.columns:
            adx4h = self._safe_float(last.get("adx_4h_4h"))
        elif "adx_4h" in dataframe.columns:
            adx4h = self._safe_float(last.get("adx_4h"))

        bbw15m = self._safe_float(last.get("bb_width_15m"))
        rvol_15m = self._safe_float(last.get("rvol_15m"))
        bbw1h = None
        bbw4h = None
        ema50 = None
        ema100 = None
        atr_1h = None
        atr_4h = None
        plus_di_4h = None
        minus_di_4h = None
        vol_1h = None
        vol_sma20 = None
        squeeze_on_1h = None
        squeeze_released_1h = False
        squeeze_val_1h = None
        squeeze_val_prev_1h = None

        bbw1h_col = None
        bbw4h_col = None
        squeeze_col = None
        squeeze_val_col = None
        for c in dataframe.columns:
            if bbw1h_col is None and (c.endswith("bb_width_1h_1h") or c == "bb_width_1h"):
                bbw1h_col = c
            if bbw4h_col is None and (c.endswith("bb_width_4h_4h") or c == "bb_width_4h"):
                bbw4h_col = c
            if c.endswith("ema50_1h_1h"):
                ema50 = self._safe_float(last.get(c))
            if c.endswith("ema100_1h_1h"):
                ema100 = self._safe_float(last.get(c))
            if c.endswith("atr_1h_1h"):
                atr_1h = self._safe_float(last.get(c))
            if c.endswith("atr_4h_4h"):
                atr_4h = self._safe_float(last.get(c))
            if c.endswith("plus_di_4h_4h") or c == "plus_di_4h":
                plus_di_4h = self._safe_float(last.get(c))
            if c.endswith("minus_di_4h_4h") or c == "minus_di_4h":
                minus_di_4h = self._safe_float(last.get(c))
            if c.endswith("vol_sma20_1h_1h"):
                vol_sma20 = self._safe_float(last.get(c))
            if squeeze_col is None and (c.endswith("squeeze_on_1h_1h") or c == "squeeze_on_1h"):
                squeeze_col = c
            if squeeze_val_col is None and (c.endswith("squeeze_val_1h_1h") or c == "squeeze_val_1h"):
                squeeze_val_col = c

        if bbw1h_col:
            bbw1h = self._safe_float(last.get(bbw1h_col))
        if bbw4h_col:
            bbw4h = self._safe_float(last.get(bbw4h_col))
        if squeeze_col:
            sq = self._safe_float(last.get(squeeze_col))
            if sq is not None:
                squeeze_on_1h = bool(sq >= 0.5)
                if len(dataframe) > 1:
                    sq_prev = self._safe_float(dataframe[squeeze_col].iloc[-2])
                    if sq_prev is not None:
                        squeeze_released_1h = bool(sq_prev >= 0.5 and sq < 0.5)
        if squeeze_val_col:
            squeeze_val_1h = self._safe_float(last.get(squeeze_val_col))
            if len(dataframe) > 1:
                squeeze_val_prev_1h = self._safe_float(dataframe[squeeze_val_col].iloc[-2])

        if "volume_1h_1h" in dataframe.columns:
            vol_1h = self._safe_float(last.get("volume_1h_1h"))
        elif "volume_1h" in dataframe.columns:
            vol_1h = self._safe_float(last.get("volume_1h"))

        hi_7d = self._safe_float(last.get("hi_7d"))
        lo_7d = self._safe_float(last.get("lo_7d"))
        plus_di_col = next((c for c in dataframe.columns if c in {"plus_di_4h", "plus_di_4h_4h"}), None)
        minus_di_col = next((c for c in dataframe.columns if c in {"minus_di_4h", "minus_di_4h_4h"}), None)
        plus_di_series = dataframe[plus_di_col] if plus_di_col in dataframe.columns else None
        minus_di_series = dataframe[minus_di_col] if minus_di_col in dataframe.columns else None
        er_15m = self._efficiency_ratio(dataframe["close"], self.instrumentation_er_lookback)
        chop_15m = self._choppiness_index(
            dataframe["high"], dataframe["low"], dataframe["close"], self.instrumentation_chop_lookback
        )
        di_flip_rate_4h = self._di_flip_rate(plus_di_series, minus_di_series, self.instrumentation_di_flip_lookback)
        wickiness_15m = self._wickiness(
            dataframe["high"],
            dataframe["low"],
            dataframe["open"],
            dataframe["close"],
            self.instrumentation_wickiness_lookback,
        )
        containment_pct = self._containment_pct(
            dataframe["close"],
            lo_7d if lo_7d is not None else float("nan"),
            hi_7d if hi_7d is not None else float("nan"),
            self.instrumentation_containment_lookback,
        )
        atr_pct_series = dataframe["atr_15m"] / dataframe["close"].replace({0.0: np.nan})
        atr_pct_current = self._safe_float(last.get("atr_15m"))
        atr_pct_current = (atr_pct_current / close) if (atr_pct_current is not None and close > 0) else None
        atr_pct_percentile = self._percentile(
            atr_pct_series, self.instrumentation_atr_pct_percentile, self.instrumentation_atr_pct_lookback
        )
        atr_pct_non_dead = False
        if atr_pct_current is not None and atr_pct_percentile is not None:
            atr_pct_non_dead = float(atr_pct_current) >= float(atr_pct_percentile)

        plus_di_col = next((c for c in dataframe.columns if c in {"plus_di_4h", "plus_di_4h_4h"}), None)
        minus_di_col = next((c for c in dataframe.columns if c in {"minus_di_4h", "minus_di_4h_4h"}), None)
        plus_di_series = dataframe[plus_di_col] if plus_di_col in dataframe.columns else None
        minus_di_series = dataframe[minus_di_col] if minus_di_col in dataframe.columns else None

        er_15m = self._efficiency_ratio(dataframe["close"], self.atr_period_15m)
        chop_15m = self._choppiness_index(
            dataframe["high"], dataframe["low"], dataframe["atr_15m"], self.bb_window
        )
        di_flip_rate_4h = self._di_flip_rate(plus_di_series, minus_di_series, self.adx_period)
        wickiness_15m = self._wickiness(
            dataframe["high"],
            dataframe["low"],
            dataframe["open"],
            dataframe["close"],
            self.box_lookback_12h_bars,
        )
        containment_pct = self._containment_pct(
            dataframe["high"],
            dataframe["low"],
            dataframe["close"],
            self.box_lookback_24h_bars,
        )
        atr_15m_value = self._safe_float(last.get("atr_15m"))
        atr_pct_15m = (
            (atr_15m_value / close) if (atr_15m_value is not None and close > 0) else None
        )
        instrumentation_features = {
            "er_15m": er_15m,
            "chop_15m": chop_15m,
            "di_flip_rate_4h": di_flip_rate_4h,
            "wickiness_15m": wickiness_15m,
            "containment_pct": containment_pct,
            "atr_pct_15m": atr_pct_15m,
            "atr_pct_15m_non_dead": bool(atr_pct_15m is not None and atr_pct_15m > 0),
            "atr_pct_dead_percentile": atr_pct_percentile,
        }

        atr_1h_pct = (atr_1h / close) if (atr_1h is not None and close > 0.0) else None
        atr_4h_pct = (atr_4h / close) if (atr_4h is not None and close > 0.0) else None

        # BBW gate on 1h (rolling percentile on pair's own history).
        bbw1h_series = dataframe[bbw1h_col] if bbw1h_col else None
        bbw4h_series = dataframe[bbw4h_col] if bbw4h_col else None
        bbw1h_pct = self._bbwp_percentile_last(bbw1h_series, self.bbw_pct_lookback_1h) if bbw1h_series is not None else None

        # EMA distance gate (1h)
        ema_dist_ok = False
        ema_dist_frac = None
        if ema50 is not None and ema100 is not None and close > 0:
            ema_dist_frac = abs(ema50 - ema100) / close
            ema_dist_ok = ema_dist_frac <= gate_ema_dist_max_frac

        # 1h volume gate
        vol_ok = False
        vol_ratio = None
        if vol_1h is not None and vol_sma20 is not None and vol_sma20 > 0:
            vol_ratio = vol_1h / vol_sma20
            vol_ok = vol_ratio <= gate_vol_spike_mult

        adx_rising_count = int(self._adx_rising_count_by_pair.get(pair, 0) or 0)
        prev_adx = self._safe_float(self._last_adx_by_pair.get(pair))
        if adx4h is not None:
            if prev_adx is None:
                adx_rising_count = 0
            elif adx4h > (prev_adx + 1e-9):
                adx_rising_count = int(adx_rising_count + 1)
            elif adx4h < (prev_adx - 1e-9):
                adx_rising_count = 0
            self._last_adx_by_pair[pair] = float(adx4h)
            self._adx_rising_count_by_pair[pair] = int(adx_rising_count)

        # BBWP raw percentiles (S=15m, M=1h, L=4h).
        bbwp_s = self._bbwp_percentile_last(dataframe["bb_width_15m"], self.bbwp_lookback_s)
        bbwp_m = self._bbwp_percentile_last(bbw1h_series, self.bbwp_lookback_m) if bbw1h_series is not None else None
        bbwp_l = self._bbwp_percentile_last(bbw4h_series, self.bbwp_lookback_l) if bbw4h_series is not None else None
        bbwp_cooloff = bool(self._bbwp_cooloff_by_pair.get(pair, False))

        # Regime router picks intraday/swing mode from raw features, then activates mode thresholds.
        running_active_hint = bool(self._running_by_pair.get(pair, False))
        running_mode_hint = None
        if running_active_hint:
            running_mode_hint = self._normalize_mode_name(self._running_mode_by_pair.get(pair))
        router_features = {
            "adx_4h": adx4h,
            "bb_width_1h_pct": bbw1h_pct,
            "ema_dist_frac_1h": ema_dist_frac,
            "vol_ratio_1h": vol_ratio,
            "bbwp_15m_pct": bbwp_s,
            "bbwp_1h_pct": bbwp_m,
            "bbwp_4h_pct": bbwp_l,
            "atr_1h_pct": atr_1h_pct,
            "atr_4h_pct": atr_4h_pct,
            "rvol_15m": rvol_15m,
            "running_active": running_active_hint,
            "running_mode": running_mode_hint,
            "er_15m": instrumentation_features["er_15m"],
            "chop_15m": instrumentation_features["chop_15m"],
            "di_flip_rate_4h": instrumentation_features["di_flip_rate_4h"],
            "wickiness_15m": instrumentation_features["wickiness_15m"],
            "containment_pct": instrumentation_features["containment_pct"],
            "atr_pct_15m": instrumentation_features["atr_pct_15m"],
            "atr_pct_15m_non_dead": instrumentation_features["atr_pct_15m_non_dead"],
            "atr_pct_dead_percentile": instrumentation_features["atr_pct_dead_percentile"],
            "close": float(close),
        }
        router_state = self._regime_router_state(pair, router_clock_ts, router_features)
        active_mode = str(router_state.get("active_mode", active_mode))
        desired_mode = str(router_state.get("desired_mode", active_mode))
        mode_cfg_raw = router_state.get("active_cfg")
        if isinstance(mode_cfg_raw, dict):
            mode_cfg = dict(mode_cfg_raw)
        gate_adx_4h_max = float(mode_cfg.get("adx_enter_max", gate_adx_4h_max))
        gate_adx_4h_exit_min = float(mode_cfg.get("adx_exit_min", gate_adx_4h_exit_min))
        gate_adx_4h_exit_max = float(mode_cfg.get("adx_exit_max", gate_adx_4h_exit_min))
        gate_adx_rising_bars = int(mode_cfg.get("adx_rising_bars", gate_adx_rising_bars))
        gate_bbw_1h_pct_max = float(mode_cfg.get("bbw_1h_pct_max", gate_bbw_1h_pct_max))
        gate_bbw_nonexp_lookback_bars = int(
            mode_cfg.get("bbw_nonexp_lookback_bars", gate_bbw_nonexp_lookback_bars)
        )
        gate_bbw_nonexp_tolerance_frac = float(
            mode_cfg.get("bbw_nonexp_tolerance_frac", gate_bbw_nonexp_tolerance_frac)
        )
        gate_ema_dist_max_frac = float(mode_cfg.get("ema_dist_max_frac", gate_ema_dist_max_frac))
        gate_vol_spike_mult = float(mode_cfg.get("vol_spike_mult", gate_vol_spike_mult))
        gate_rvol_15m_max = float(mode_cfg.get("rvol_15m_max", gate_rvol_15m_max))
        gate_bbwp_s_enter_low = float(mode_cfg.get("bbwp_s_enter_low", gate_bbwp_s_enter_low))
        gate_bbwp_s_enter_high = float(mode_cfg.get("bbwp_s_enter_high", gate_bbwp_s_enter_high))
        gate_bbwp_m_enter_low = float(mode_cfg.get("bbwp_m_enter_low", gate_bbwp_m_enter_low))
        gate_bbwp_m_enter_high = float(mode_cfg.get("bbwp_m_enter_high", gate_bbwp_m_enter_high))
        gate_bbwp_l_enter_low = float(mode_cfg.get("bbwp_l_enter_low", gate_bbwp_l_enter_low))
        gate_bbwp_l_enter_high = float(mode_cfg.get("bbwp_l_enter_high", gate_bbwp_l_enter_high))
        gate_bbwp_s_max = float(mode_cfg.get("bbwp_s_max", gate_bbwp_s_enter_high))
        gate_bbwp_m_max = float(mode_cfg.get("bbwp_m_max", gate_bbwp_m_enter_high))
        gate_bbwp_l_max = float(mode_cfg.get("bbwp_l_max", gate_bbwp_l_enter_high))
        gate_bbwp_stop_high = float(mode_cfg.get("bbwp_stop_high", gate_bbwp_stop_high))
        gate_atr_source = str(mode_cfg.get("atr_source", gate_atr_source)).strip().lower()
        gate_atr_pct_max = float(mode_cfg.get("atr_pct_max", gate_atr_pct_max))
        gate_os_dev_persist_bars = int(mode_cfg.get("os_dev_persist_bars", gate_os_dev_persist_bars))
        gate_os_dev_rvol_max = float(mode_cfg.get("os_dev_rvol_max", gate_os_dev_rvol_max))
        neutral_mode_active = bool(
            router_state.get("scores", {}).get("chop_score_state", False)
        )
        neutral_persistence_entry = self._neutral_persistence_state_by_pair.get(pair, {})
        neutral_enter_persist = int(
            neutral_persistence_entry.get("enter", self.neutral_persistence_default_enter)
        )
        neutral_exit_default = max(1, int(round(float(neutral_enter_persist) * float(self.neutral_exit_persist_ratio))))
        neutral_exit_persist = int(neutral_persistence_entry.get("exit", neutral_exit_default))

        # Apply active mode thresholds.
        mode_pause = bool(active_mode == "pause")
        bbw_percentile_ok = self._bbw_percentile_ok(bbw1h_pct, gate_bbw_1h_pct_max)
        bbw_trend_nonexp_ok = self._bbw_nonexpanding(
            bbw1h_series, gate_bbw_nonexp_lookback_bars, gate_bbw_nonexp_tolerance_frac
        )
        bbw_nonexp = bool(bbw_percentile_ok and bbw_trend_nonexp_ok)
        ema_dist_ok = False
        if ema_dist_frac is not None:
            ema_dist_ok = bool(ema_dist_frac <= gate_ema_dist_max_frac)
        vol_1h_ok = bool(vol_ratio is not None and vol_ratio <= gate_vol_spike_mult)
        rvol_15m_ok = bool(rvol_15m is not None and rvol_15m <= gate_rvol_15m_max)
        if vol_ratio is None:
            vol_ok = bool(rvol_15m_ok)
        elif rvol_15m is None:
            vol_ok = bool(vol_1h_ok)
        else:
            vol_ok = bool(vol_1h_ok and rvol_15m_ok)
        atr_mode_pct = atr_4h_pct if gate_atr_source == "4h" else atr_1h_pct
        atr_ok = bool(atr_mode_pct is not None and atr_mode_pct <= gate_atr_pct_max)

        # 4h ADX gate / hysteresis signal.
        adx_rising_confirmed = bool(adx_rising_count >= int(max(gate_adx_rising_bars, 1)))
        adx_ok = (adx4h is not None) and (adx4h <= gate_adx_4h_max)
        adx_exit_overheat = self._adx_exit_hysteresis_trigger(
            adx4h,
            adx_rising_count,
            gate_adx_4h_exit_min,
            gate_adx_rising_bars,
        )
        adx_di_up = bool(
            plus_di_4h is not None and minus_di_4h is not None and plus_di_4h > minus_di_4h
        )
        adx_di_down = bool(
            plus_di_4h is not None and minus_di_4h is not None and minus_di_4h > plus_di_4h
        )
        adx_di_down_risk_stop = self._adx_di_down_risk_trigger(
            adx4h,
            plus_di_4h,
            minus_di_4h,
            adx_rising_count,
            gate_adx_4h_exit_min,
            gate_adx_rising_bars,
            early_margin=2.0,
        )

        # BBWP gate (active mode thresholds + global veto/cooloff).
        if self.bbwp_enabled:
            bbwp_vals = [x for x in [bbwp_s, bbwp_m, bbwp_l] if x is not None]
            bbwp_nonexp_15m = self._bbw_nonexpanding(dataframe["bb_width_15m"], self.bbwp_nonexp_bars, 0.0)
            bbwp_nonexp_1h = self._bbw_nonexpanding(bbw1h_series, self.bbwp_nonexp_bars, 0.0)
            bbwp_nonexp_4h = self._bbw_nonexpanding(bbw4h_series, self.bbwp_nonexp_bars, 0.0)
            bbwp_nonexp_ok = bool(bbwp_nonexp_15m and bbwp_nonexp_1h and bbwp_nonexp_4h)
            bbwp_expansion_stop = any(x >= gate_bbwp_stop_high for x in bbwp_vals)
            bbwp_veto = any(x >= min(gate_bbwp_veto_pct, gate_bbwp_stop_high) for x in bbwp_vals)
            if any(x >= gate_bbwp_cooloff_trigger_pct for x in bbwp_vals):
                bbwp_cooloff = True
            if (
                bbwp_cooloff
                and bbwp_s is not None
                and bbwp_m is not None
                and bbwp_s < gate_bbwp_cooloff_release_s
                and bbwp_m < gate_bbwp_cooloff_release_m
            ):
                bbwp_cooloff = False
            self._bbwp_cooloff_by_pair[pair] = bbwp_cooloff

            bbwp_allow = bool(
                bbwp_s is not None
                and bbwp_m is not None
                and bbwp_l is not None
                and gate_bbwp_s_enter_low <= bbwp_s <= gate_bbwp_s_enter_high
                and gate_bbwp_m_enter_low <= bbwp_m <= gate_bbwp_m_enter_high
                and gate_bbwp_l_enter_low <= bbwp_l <= gate_bbwp_l_enter_high
                and bbwp_nonexp_ok
            )
            bbwp_gate_ok = bool(bbwp_allow and not bbwp_veto and not bbwp_cooloff)
        else:
            bbwp_allow = True
            bbwp_nonexp_ok = True
            bbwp_veto = False
            bbwp_cooloff = False
            bbwp_expansion_stop = False
            bbwp_gate_ok = True

        # 7d containment (15m)
        hi7d = self._safe_float(last.get("hi_7d"))
        lo7d = self._safe_float(last.get("lo_7d"))
        inside_7d = True
        if hi7d is not None and lo7d is not None:
            inside_7d = (close <= hi7d) and (close >= lo7d)
        inside_7d_gate_ok = bool(inside_7d or (not gate_context_7d_hard_veto))
        fr_8h_pct = None
        if "fr_8h_pct" in dataframe.columns:
            fr_8h_pct = self._safe_float(last.get("fr_8h_pct"))
        funding_gate_ok = self._funding_gate_ok(fr_8h_pct)
        funding_bias = 0
        if fr_8h_pct is not None:
            if fr_8h_pct > 0:
                funding_bias = 1
            elif fr_8h_pct < 0:
                funding_bias = -1

        volatility_policy = compute_volatility_policy_view(
            active_mode=str(active_mode),
            adapter_enabled=bool(self.n_volatility_adapter_enabled),
            adapter_strength=float(self.n_volatility_adapter_strength),
            atr_pct_15m=atr_pct_15m,
            atr_pct_1h=atr_1h_pct,
            atr_mode_pct=atr_mode_pct,
            atr_mode_max=float(gate_atr_pct_max),
            bbwp_s=bbwp_s,
            bbwp_m=bbwp_m,
            bbwp_l=bbwp_l,
            squeeze_on_1h=squeeze_on_1h,
            hvp_state=None,
            base_n_min=int(self.n_min),
            base_n_max=int(self.n_max),
            base_box_width_min_pct=float(self.min_width_pct),
            base_box_width_max_pct=float(self.max_width_pct),
            base_min_step_buffer_bps=float(self.volatility_min_step_buffer_bps),
            base_cooldown_minutes=float(self.cooldown_minutes),
            base_min_runtime_minutes=float(self.min_runtime_hours) * 60.0,
        )
        volatility_policy_base = dict(volatility_policy.get("base", {}))
        volatility_policy_adapted = dict(volatility_policy.get("adapted", {}))
        volatility_policy_n_diag = dict(volatility_policy.get("n_level_diag", {}))
        vol_bucket = str(volatility_policy.get("vol_bucket", "normal"))
        box_width_min_effective = float(
            volatility_policy_adapted.get("box_width_min_pct", self.min_width_pct)
        )
        box_width_max_effective = float(
            volatility_policy_adapted.get("box_width_max_pct", self.max_width_pct)
        )
        n_low = int(volatility_policy_adapted.get("n_min", self.n_min))
        n_high = int(volatility_policy_adapted.get("n_max", self.n_max))
        min_step_buffer_bps_effective = float(
            volatility_policy_adapted.get("min_step_buffer_bps", self.volatility_min_step_buffer_bps)
        )
        cooldown_minutes_effective = float(
            volatility_policy_adapted.get("cooldown_minutes", self.cooldown_minutes)
        )
        min_runtime_minutes_effective = float(
            volatility_policy_adapted.get("min_runtime_minutes", float(self.min_runtime_hours) * 60.0)
        )
        volatility_strictness = dict(volatility_policy_adapted.get("build_strictness", {}))
        volatility_enforce_squeeze_gate = bool(volatility_strictness.get("enforce_squeeze_gate", False))
        volatility_bucket_block_start = bool(volatility_strictness.get("vol_bucket_block_start", False))
        volatility_gate_ratio_delta = float(volatility_policy_adapted.get("start_gate_ratio_delta", 0.0))
        gate_start_min_pass_ratio_effective = float(
            np.clip(float(gate_start_min_pass_ratio) + float(volatility_gate_ratio_delta), 0.0, 1.0)
        )
        volatility_strictness_ok = bool(
            (not volatility_enforce_squeeze_gate or bool(squeeze_on_1h))
            and (not volatility_bucket_block_start)
        )
        volatility_strictness_blocked = bool(not volatility_strictness_ok)
        box_block_reasons: List[BlockReason] = []

        # ---- Build box on 15m ----
        lo_p, hi_p, width_pct, used_lb, pad = self._build_box_15m(
            dataframe,
            min_width_pct=box_width_min_effective,
            max_width_pct=box_width_max_effective,
        )
        width_avg_state = self._box_width_avg_veto_state(pair, float(width_pct))
        overlap_pruned = self._box_overlap_prune(pair, lo_p, hi_p)

        # VRVP POC/VAH/VAL + deterministic box shift toward POC.
        vrvp = self._vrvp_profile(dataframe, self.vrvp_lookback_bars, self.vrvp_bins, self.vrvp_value_area_pct)
        vrvp_poc = self._safe_float(vrvp.get("poc"))
        vrvp_vah = self._safe_float(vrvp.get("vah"))
        vrvp_val = self._safe_float(vrvp.get("val"))
        vrvp_source = "vrvp"
        fallback_poc_used = False
        fallback_poc_value = None
        if vrvp_poc is None and bool(self.fallback_poc_estimator_enabled):
            fallback_poc_value = self._fallback_poc_estimate(dataframe, int(self.fallback_poc_lookback_bars))
            if fallback_poc_value is not None:
                vrvp_poc = float(fallback_poc_value)
                vrvp_source = "fallback"
                fallback_poc_used = True
        vrvp_box_shift = 0.0
        vrvp_dist_frac = None
        vrvp_poc_inside_box = False

        if vrvp_poc is not None:
            pre_mid = (hi_p + lo_p) / 2.0
            max_shift = self.vrvp_max_box_shift_frac * pre_mid if pre_mid > 0 else 0.0
            if vrvp_poc > hi_p and max_shift > 0:
                shift = min(vrvp_poc - hi_p, max_shift)
                lo_p += shift
                hi_p += shift
                vrvp_box_shift = float(shift)
            elif vrvp_poc < lo_p and max_shift > 0:
                shift = min(lo_p - vrvp_poc, max_shift)
                lo_p -= shift
                hi_p -= shift
                vrvp_box_shift = float(-shift)

            post_mid = (hi_p + lo_p) / 2.0
            if lo_p <= vrvp_poc <= hi_p:
                vrvp_poc_inside_box = True
                vrvp_dist_frac = 0.0
            else:
                dist = (vrvp_poc - hi_p) if vrvp_poc > hi_p else (lo_p - vrvp_poc)
                vrvp_dist_frac = (dist / post_mid) if post_mid > 0 else None

        vrvp_box_ok = True
        if self.vrvp_reject_if_still_outside and vrvp_poc is not None and vrvp_dist_frac is not None:
            vrvp_box_ok = bool(vrvp_dist_frac <= self.vrvp_poc_outside_box_max_frac)

        current_bar_index = max(int(len(dataframe)) - 1, 0)
        candidate_mid = float((hi_p + lo_p) / 2.0) if (hi_p + lo_p) else 0.0
        candidate_signature = self._box_signature(lo_p, hi_p, used_lb, pad)
        candidate_box = {
            "lo": float(lo_p),
            "hi": float(hi_p),
            "used_lookback": int(used_lb),
            "pad": float(pad),
            "mid": candidate_mid,
        }
        candidate_vrvp = {
            "poc": vrvp_poc,
            "vah": vrvp_vah,
            "val": vrvp_val,
            "source": str(vrvp_source),
            "fallback_used": bool(fallback_poc_used),
            "fallback_poc": float(fallback_poc_value) if fallback_poc_value is not None else None,
            "poc_inside_box": bool(vrvp_poc_inside_box),
            "poc_dist_frac_after_shift": float(vrvp_dist_frac) if vrvp_dist_frac is not None else None,
            "box_shift_applied": float(vrvp_box_shift),
            "box_ok": bool(vrvp_box_ok),
        }
        stored_box = self._box_state_by_pair.get(pair)
        stored_signature = self._box_signature_by_pair.get(pair)
        if stored_signature is None and stored_box is not None:
            stored_signature = self._box_signature(
                float(stored_box.get("lo", lo_p)),
                float(stored_box.get("hi", hi_p)),
                int(stored_box.get("used_lookback", used_lb)),
                float(stored_box.get("pad", pad)),
            )
            self._box_signature_by_pair[pair] = stored_signature
        signature_changed = stored_signature != candidate_signature
        bars_since = int(self._box_rebuild_bars_since_by_pair.get(pair, 0) or 0)
        shift_frac = None
        if stored_box is not None:
            prev_mid = float(stored_box.get("mid", 0.0))
            if prev_mid > 0.0:
                shift_frac = abs(candidate_mid - prev_mid) / prev_mid
        rebuild_for_shift = stored_box is None or (shift_frac is None) or (
            shift_frac >= float(self.neutral_rebuild_shift_pct)
        )
        rebuild_for_time = bars_since >= int(self.neutral_rebuild_max_bars)
        zigzag_contraction_state = self._zigzag_contraction_state(dataframe)
        zigzag_contraction_gate_ok = bool(
            (not self.zigzag_contraction_enabled)
            or (not neutral_mode_active)
            or (not rebuild_for_time)
            or bool(zigzag_contraction_state.get("ok", True))
        )
        use_candidate = True
        if neutral_mode_active and stored_box is not None:
            use_candidate = bool(rebuild_for_shift or rebuild_for_time)
        if use_candidate and (not zigzag_contraction_gate_ok):
            use_candidate = False
        if bool(width_avg_state.get("veto", False)):
            use_candidate = False
            box_block_reasons.append(BlockReason.BLOCK_BOX_WIDTH_TOO_WIDE)
        if overlap_pruned:
            use_candidate = False
            box_block_reasons.append(BlockReason.BLOCK_BOX_OVERLAP_HIGH)
        box_rebuild_skipped = bool(neutral_mode_active and stored_box is not None and not use_candidate)
        box_rebuild_wait_bars = 0
        if use_candidate:
            stored_gen_id = str(stored_box.get("box_gen_id")) if isinstance(stored_box, dict) and stored_box.get("box_gen_id") else None
            stored_built_idx = (
                int(self._safe_float(stored_box.get("built_at_bar_index")) or current_bar_index)
                if isinstance(stored_box, dict)
                else int(current_bar_index)
            )
            if signature_changed or stored_box is None:
                box_gen_id = str(candidate_signature)
                box_built_at_index = int(current_bar_index)
            else:
                box_gen_id = str(stored_gen_id or candidate_signature)
                box_built_at_index = int(stored_built_idx)
            active_box = {
                **candidate_box,
                "width_pct": float(width_pct),
                "vrvp": dict(candidate_vrvp),
                "box_gen_id": str(box_gen_id),
                "built_at_bar_index": int(box_built_at_index),
            }
            active_vrvp = candidate_vrvp
            self._box_state_by_pair[pair] = dict(active_box)
            used_lb_int = int(active_box.get("used_lookback", used_lb))
            candidate_signature = self._box_signature(
                lo_p,
                hi_p,
                used_lb_int,
                float(active_box.get("pad", pad)),
            )
            self._box_signature_by_pair[pair] = candidate_signature
            if signature_changed:
                self._poc_acceptance_crossed_by_pair.pop(pair, None)
                self._poc_alignment_crossed_by_pair.pop(pair, None)
            if signature_changed or stored_box is None or len(self._box_width_history(pair)) == 0:
                self._record_accepted_box_width(pair, float(width_pct))
            self._box_rebuild_bars_since_by_pair[pair] = 0
            self._record_box_history(pair, lo_p, hi_p)
            box_rebuild_wait_bars = 0
        else:
            active_box = dict(stored_box or candidate_box)
            if "box_gen_id" not in active_box or not str(active_box.get("box_gen_id")).strip():
                active_box["box_gen_id"] = str(stored_signature or candidate_signature)
            if "built_at_bar_index" not in active_box:
                active_box["built_at_bar_index"] = int(current_bar_index)
            active_vrvp = stored_box.get("vrvp") if stored_box else candidate_vrvp
            self._box_state_by_pair[pair] = dict(active_box)
            self._box_rebuild_bars_since_by_pair[pair] = bars_since + 1
            box_rebuild_wait_bars = bars_since + 1
        active_vrvp_source = str((active_vrvp or {}).get("source") or vrvp_source)
        active_fallback_used = bool((active_vrvp or {}).get("fallback_used", fallback_poc_used))
        active_fallback_poc = self._safe_float((active_vrvp or {}).get("fallback_poc"))
        if active_fallback_poc is None:
            active_fallback_poc = self._safe_float(fallback_poc_value)
        lo_p = float(active_box["lo"])
        hi_p = float(active_box["hi"])
        pad_effective = float(active_box.get("pad", pad))
        box_gen_id = str(active_box.get("box_gen_id") or candidate_signature)
        box_built_at_bar_index = int(
            self._safe_float(active_box.get("built_at_bar_index")) or current_bar_index
        )
        range_len_state = self._range_len_gate_state(
            current_bar_index=int(current_bar_index),
            box_built_at_bar_index=int(box_built_at_bar_index),
            min_range_len_bars=int(self.min_range_len_bars),
            box_gen_id=str(box_gen_id),
        )
        range_len_bars_current = int(range_len_state.get("range_len_bars_current", 1))
        min_range_len_required = int(range_len_state.get("min_range_len_bars", self.min_range_len_bars))
        min_range_len_ok = bool(range_len_state.get("ok", True))
        session_new_print = False
        session_gate_ok = True
        if session_new_print and session_gate_ok and pad_effective > 0.0:
            shrink_pct = float(np.clip(self.session_box_pad_shrink_pct, 0.0, 1.0))
            target_pad = float(pad_effective * (1.0 - shrink_pct))
            shrink = float(max(pad_effective - target_pad, 0.0))
            if shrink * 2 < (hi_p - lo_p):
                lo_p += shrink
                hi_p -= shrink
                pad_effective = float(target_pad)
                active_box["lo"] = lo_p
                active_box["hi"] = hi_p
                active_box["pad"] = pad_effective
        bb_lower_15m = self._safe_float(last.get("bb_lower_15m"))
        bb_upper_15m = self._safe_float(last.get("bb_upper_15m"))
        band_overlap_ratio = 0.0
        band_overlap_ok = True
        if bb_lower_15m is not None and bb_upper_15m is not None:
            band_overlap_ratio = self._box_overlap_fraction(
                lo_p, hi_p, float(bb_lower_15m), float(bb_upper_15m)
            )
            band_overlap_ok = bool(
                band_overlap_ratio >= float(self.box_band_overlap_required)
                or (
                    adx4h is not None
                    and adx4h <= float(self.box_band_adx_allow)
                    and rvol_15m is not None
                    and rvol_15m <= float(self.box_band_rvol_allow)
                )
            )
            if not band_overlap_ok:
                box_block_reasons.append(BlockReason.BLOCK_BOX_CHANNEL_OVERLAP_LOW)
        envelope_block = False
        if bb_lower_15m is not None and bb_upper_15m is not None:
            envelope_width = float(bb_upper_15m) - float(bb_lower_15m)
            if envelope_width > 0:
                envelope_ratio = float((hi_p - lo_p) / envelope_width)
                if envelope_ratio > float(self.box_envelope_ratio_max):
                    if (
                        adx4h is None
                        or adx4h >= float(self.box_envelope_adx_threshold)
                        or rvol_15m is None
                        or rvol_15m >= float(self.box_envelope_rvol_threshold)
                    ):
                        envelope_block = True
                        box_block_reasons.append(BlockReason.BLOCK_BOX_ENVELOPE_RATIO_HIGH)
        breakout, breakout_direction, breakout_hi, breakout_lo = self._detect_structural_breakout(
            dataframe, int(self.breakout_lookback_bars)
        )
        breakout_fresh_block_active, breakout_up_level, breakout_dn_level = self._update_breakout_fresh_state(
            pair,
            breakout,
            breakout_hi,
            breakout_lo,
            close,
        )
        box_diag = self._update_box_quality(pair, lo_p, hi_p, pad_effective, used_lb, dataframe)
        breakout_bars_since = self._breakout_bars_since_by_pair.get(pair)
        if breakout:
            self._neutral_box_break_bars_by_pair[pair] = int(self.breakout_block_bars)
        else:
            prev_break = int(self._neutral_box_break_bars_by_pair.get(pair, 0) or 0)
            self._neutral_box_break_bars_by_pair[pair] = max(prev_break - 1, 0)
        used_lb = int(active_box["used_lookback"])
        pad = float(active_box["pad"])
        mid = float(active_box.get("mid") or ((hi_p + lo_p) / 2.0 if (hi_p + lo_p) else 0.0))
        vrvp_poc = active_vrvp.get("poc")
        vrvp_vah = active_vrvp.get("vah")
        vrvp_val = active_vrvp.get("val")
        vrvp_poc_inside_box = bool(active_vrvp.get("poc_inside_box", False))
        vrvp_dist_frac = active_vrvp.get("poc_dist_frac_after_shift")
        vrvp_box_shift = float(active_vrvp.get("box_shift_applied", 0.0) or 0.0)
        vrvp_box_ok = bool(active_vrvp.get("box_ok", True))
        box_rebuild_shift_frac = shift_frac

        final_vrvp_poc = self._safe_float(active_vrvp.get("poc"))
        band_slope_pct = self._compute_band_slope_pct(pair, mid)
        band_slope_gate_ok = bool(
            (not self.band_slope_veto_enabled)
            or (band_slope_pct is None)
            or (band_slope_pct < float(self.band_slope_veto_pct))
        )
        excursion_asymmetry_ratio = self._excursion_asymmetry_ratio(lo_p, hi_p, mid)
        excursion_asymmetry_gate_ok = bool(
            (not self.excursion_asymmetry_veto_enabled)
            or (excursion_asymmetry_ratio is None)
            or (
                float(self.excursion_asymmetry_min_ratio)
                <= excursion_asymmetry_ratio
                <= float(self.excursion_asymmetry_max_ratio)
            )
        )
        poc_candidates = [x for x in (final_vrvp_poc,) if x is not None]
        poc_acceptance_satisfied = self._poc_acceptance_status(pair, dataframe, poc_candidates)

        # Box quality levels (M209): log-space quartiles + 1.386 extensions.
        width_pct = (hi_p - lo_p) / mid if mid > 0 else 0.0
        box_quality_levels = self._box_quality_levels(lo_p, hi_p)
        q1 = float(box_quality_levels["q1"])
        q2 = float(box_quality_levels["q2"])
        q3 = float(box_quality_levels["q3"])
        ext_lo = float(box_quality_levels["extension_lo"])
        ext_hi = float(box_quality_levels["extension_hi"])
        quartile_space = str(box_quality_levels["space"])
        extension_factor = float(box_quality_levels["extension_factor"])

        # ---- Grid sizing (cost-aware + empirical floor) ----
        cost_floor = self._effective_cost_floor(pair, last, close)
        min_step_pct_required_base = float(cost_floor.get("chosen_floor_pct", 0.0) or 0.0)
        min_step_pct_required = float(min_step_pct_required_base)
        static_gross_min = float(cost_floor.get("static_floor_pct", 0.0) or 0.0)
        min_step_pct_required += float(min_step_buffer_bps_effective) / 10_000.0
        n_bounds_diag = {
            "mode": str(active_mode),
            "adapter_enabled": bool(self.n_volatility_adapter_enabled),
            "vol_bucket": str(vol_bucket),
            "base_n_min": int(volatility_policy_base.get("n_min", self.n_min)),
            "base_n_max": int(volatility_policy_base.get("n_max", self.n_max)),
            "adapted_n_min": int(n_low),
            "adapted_n_max": int(n_high),
            "chosen_floor_base_pct": float(min_step_pct_required_base),
            "min_step_buffer_bps": float(min_step_buffer_bps_effective),
            "min_step_pct_required": float(min_step_pct_required),
            "box_width_min_pct": float(box_width_min_effective),
            "box_width_max_pct": float(box_width_max_effective),
        }
        n_bounds_diag.update(volatility_policy_n_diag)
        sizing = self._grid_sizing(
            lo_p,
            hi_p,
            min_step_pct_required=min_step_pct_required,
            n_low=n_low,
            n_high=n_high,
        )
        n_levels = int(sizing.get("n_levels", n_low))
        step_price = float(sizing.get("step_price", 0.0) or 0.0)
        step_pct_actual = float(sizing.get("step_pct_actual", 0.0) or 0.0)
        tp_price = hi_p + (self.tp_step_multiple * step_price)
        sl_price = lo_p - (self.sl_step_multiple * step_price)
        empirical_floor_pct = self._safe_float((cost_floor.get("empirical_snapshot") or {}).get("empirical_floor_pct"))
        step_below_cost = bool(step_pct_actual < min_step_pct_required)
        step_below_empirical = bool(
            step_below_cost
            and empirical_floor_pct is not None
            and empirical_floor_pct > static_gross_min
            and min_step_pct_required >= empirical_floor_pct
        )
        step_cost_block_reason: Optional[BlockReason] = None
        if step_below_cost:
            step_cost_block_reason = (
                BlockReason.BLOCK_STEP_BELOW_EMPIRICAL_COST
                if step_below_empirical
                else BlockReason.BLOCK_STEP_BELOW_COST
            )

        grid_budget_pct_effective = float(self.grid_budget_pct)
        if neutral_mode_active:
            adjusted_levels = int(round(float(n_levels) * float(self.neutral_grid_levels_ratio)))
            adjusted_levels = int(np.clip(adjusted_levels, n_low, n_high))
            if adjusted_levels < n_levels:
                n_levels = adjusted_levels
                step_price = (hi_p - lo_p) / float(n_levels) if n_levels > 0 else 0.0
                step_pct_actual = (step_price / mid) if mid > 0 else 0.0
            grid_budget_pct_effective *= float(self.neutral_grid_budget_ratio)
            # Re-check cost floor after mode-specific level adjustment.
            step_below_cost = bool(step_pct_actual < min_step_pct_required)
            step_below_empirical = bool(
                step_below_cost
                and empirical_floor_pct is not None
                and empirical_floor_pct > static_gross_min
                and min_step_pct_required >= empirical_floor_pct
            )
            step_cost_block_reason = None
            if step_below_cost:
                step_cost_block_reason = (
                    BlockReason.BLOCK_STEP_BELOW_EMPIRICAL_COST
                    if step_below_empirical
                    else BlockReason.BLOCK_STEP_BELOW_COST
                )

        breakout_confirm_buffer = self._breakout_confirm_buffer(
            step_price=float(step_price),
            atr_15m=atr_15m_value,
            close=float(close),
        )
        breakout_confirm_state = self._breakout_confirm_state(
            dataframe,
            box_low=float(lo_p),
            box_high=float(hi_p),
            buffer=float(breakout_confirm_buffer),
            confirm_bars=int(self.breakout_confirm_bars),
        )
        breakout_confirmed_up = bool(breakout_confirm_state.get("confirmed_up", False))
        breakout_confirmed_dn = bool(breakout_confirm_state.get("confirmed_dn", False))
        breakout_confirm_reason_state = self._breakout_confirm_reason_state(
            confirmed_up=bool(breakout_confirmed_up),
            confirmed_dn=bool(breakout_confirmed_dn),
            running_active=bool(running_active_hint),
        )
        breakout_confirm_stop_up = bool(breakout_confirm_reason_state.get("stop_up", False))
        breakout_confirm_stop_dn = bool(breakout_confirm_reason_state.get("stop_dn", False))
        breakout_confirm_block_up = bool(breakout_confirm_reason_state.get("block_up", False))
        breakout_confirm_block_dn = bool(breakout_confirm_reason_state.get("block_dn", False))
        breakout_confirm_gate_ok = bool(breakout_confirm_reason_state.get("gate_ok", True))
        min_range_len_block_reason: Optional[BlockReason] = (
            None if min_range_len_ok else BlockReason.BLOCK_MIN_RANGE_LEN_NOT_MET
        )
        breakout_confirm_block_reason: Optional[BlockReason] = None
        if breakout_confirm_reason_state.get("block_reason") == str(BlockReason.BLOCK_BREAKOUT_CONFIRM_UP):
            breakout_confirm_block_reason = BlockReason.BLOCK_BREAKOUT_CONFIRM_UP
        elif breakout_confirm_reason_state.get("block_reason") == str(BlockReason.BLOCK_BREAKOUT_CONFIRM_DN):
            breakout_confirm_block_reason = BlockReason.BLOCK_BREAKOUT_CONFIRM_DN

        # MRVD (day/week/month) profile gates + drift pause.
        mrvd_day = self._mrvd_profile(
            dataframe, self.mrvd_day_lookback_bars, self.mrvd_bins, self.mrvd_value_area_pct
        ) if self.mrvd_enabled else {}
        mrvd_week = self._mrvd_profile(
            dataframe, self.mrvd_week_lookback_bars, self.mrvd_bins, self.mrvd_value_area_pct
        ) if self.mrvd_enabled else {}
        mrvd_month = self._mrvd_profile(
            dataframe, self.mrvd_month_lookback_bars, self.mrvd_bins, self.mrvd_value_area_pct
        ) if self.mrvd_enabled else {}

        def mrvd_period_state(profile: Dict) -> Dict:
            poc = self._safe_float(profile.get("poc"))
            vah = self._safe_float(profile.get("vah"))
            val = self._safe_float(profile.get("val"))
            va_overlap_frac = 0.0
            if vah is not None and val is not None:
                va_overlap_frac = self._interval_overlap_frac(val, vah, lo_p, hi_p)
            poc_dist_steps = None
            near_poc = False
            if poc is not None and step_price > 0:
                poc_dist_steps = abs(close - poc) / step_price
                near_poc = bool(poc_dist_steps <= float(self.mrvd_near_poc_steps))
            return {
                "lookback_bars": int(profile.get("lookback_bars", 0) or 0),
                "bars_used": int(profile.get("bars_used", 0) or 0),
                "poc": poc,
                "vah": vah,
                "val": val,
                "buy_volume": float(profile.get("buy_volume", 0.0) or 0.0),
                "sell_volume": float(profile.get("sell_volume", 0.0) or 0.0),
                "buy_sell_ratio": self._safe_float(profile.get("buy_sell_ratio")),
                "buy_sell_imbalance": self._safe_float(profile.get("buy_sell_imbalance")),
                "va_overlap_frac": float(va_overlap_frac),
                "poc_dist_steps": poc_dist_steps,
                "near_poc": bool(near_poc),
            }

        mrvd_day_state = mrvd_period_state(mrvd_day) if self.mrvd_enabled else {
            "lookback_bars": 0,
            "bars_used": 0,
            "poc": None,
            "vah": None,
            "val": None,
            "buy_volume": 0.0,
            "sell_volume": 0.0,
            "buy_sell_ratio": None,
            "buy_sell_imbalance": None,
            "va_overlap_frac": 0.0,
            "poc_dist_steps": None,
            "near_poc": False,
        }
        mrvd_week_state = mrvd_period_state(mrvd_week) if self.mrvd_enabled else dict(mrvd_day_state)
        mrvd_month_state = mrvd_period_state(mrvd_month) if self.mrvd_enabled else dict(mrvd_day_state)

        mrvd_period_states = [mrvd_day_state, mrvd_week_state, mrvd_month_state]
        mrvd_overlap_count = int(
            sum(float(x.get("va_overlap_frac", 0.0) or 0.0) >= float(self.mrvd_va_overlap_min_frac) for x in mrvd_period_states)
        ) if self.mrvd_enabled else int(self.mrvd_required_overlap_count)
        mrvd_overlap_ok = bool(mrvd_overlap_count >= int(self.mrvd_required_overlap_count))
        mrvd_near_any_poc = bool(any(bool(x.get("near_poc", False)) for x in mrvd_period_states)) if self.mrvd_enabled else True

        mrvd_day_poc_prev = self._mrvd_day_poc_prev_by_pair.get(pair)
        mrvd_day_poc = self._safe_float(mrvd_day_state.get("poc"))
        mrvd_week_poc = self._safe_float(mrvd_week_state.get("poc"))
        mrvd_month_poc = self._safe_float(mrvd_month_state.get("poc"))

        mrvd_day_poc_step_move = None
        if mrvd_day_poc_prev is not None and mrvd_day_poc is not None and step_price > 0:
            mrvd_day_poc_step_move = abs(float(mrvd_day_poc) - float(mrvd_day_poc_prev)) / step_price

        mrvd_drift_anchor_prev = None
        mrvd_drift_anchor_cur = None
        mrvd_drift_delta_steps = None
        mrvd_drift_guard_triggered = False
        if self.mrvd_enabled and self.mrvd_drift_guard_enabled and mrvd_day_poc_prev is not None and mrvd_day_poc is not None:
            anchors = [x for x in [mrvd_week_poc, mrvd_month_poc] if x is not None]
            if len(anchors) > 0:
                prev_dist = float(np.mean([abs(float(mrvd_day_poc_prev) - float(a)) for a in anchors]))
                cur_dist = float(np.mean([abs(float(mrvd_day_poc) - float(a)) for a in anchors]))
                mrvd_drift_anchor_prev = prev_dist
                mrvd_drift_anchor_cur = cur_dist
                if step_price > 0:
                    mrvd_drift_delta_steps = (cur_dist - prev_dist) / step_price
                    mrvd_drift_guard_triggered = bool(mrvd_drift_delta_steps >= float(self.mrvd_drift_guard_steps))

        if mrvd_day_poc is not None:
            self._mrvd_day_poc_prev_by_pair[pair] = float(mrvd_day_poc)

        mrvd_pause_entries = bool(self.mrvd_enabled and mrvd_drift_guard_triggered)
        mrvd_gate_ok = bool(
            (not self.mrvd_enabled) or ((mrvd_overlap_ok or mrvd_near_any_poc) and not mrvd_pause_entries)
        )
        meta_drift_soft_block_mrvd = bool(
            self.meta_drift_soft_block_enabled
            and mrvd_drift_delta_steps is not None
            and mrvd_drift_delta_steps >= float(self.meta_drift_soft_block_steps)
        )
        drift_slope_gate_ok = True
        if self.drift_slope_veto_enabled:
            drift_slope_gate_ok = not bool(mrvd_drift_guard_triggered)

        hvp_current = None
        hvp_sma = None
        hvp_gate_ok = True
        hvp_quiet_exit_bias = False
        if self.hvp_enabled and "close" in dataframe.columns:
            hvp_current, hvp_sma = self._hvp_stats(pd.to_numeric(dataframe["close"], errors="coerce"))
            hvp_cooloff = bool(self._hvp_cooloff_by_pair.get(pair, False))
            if hvp_current is not None and hvp_sma is not None:
                hvp_expanding = (not bool(bbw_nonexp)) and (hvp_current >= hvp_sma)
                if hvp_expanding:
                    hvp_cooloff = True
                elif hvp_cooloff and (hvp_current < hvp_sma):
                    hvp_cooloff = False
                hvp_quiet_exit_bias = bool(hvp_current < hvp_sma)
            hvp_gate_ok = not hvp_cooloff
            self._hvp_cooloff_by_pair[pair] = hvp_cooloff

        # FreqAI confidence overlay (soft nudges only).
        ml_overlay = self._freqai_overlay_state(
            last,
            close,
            step_price,
            q1,
            q2,
            q3,
            vrvp_poc,
        )
        p_range = self._safe_float(ml_overlay.get("p_range"))
        p_breakout = self._safe_float(ml_overlay.get("p_breakout"))
        ml_confidence = self._safe_float(ml_overlay.get("ml_confidence"))
        ml_gate_ok = bool(ml_overlay.get("gate_ok", True))
        ml_quick_tp_candidate = self._safe_float(ml_overlay.get("quick_tp_candidate"))
        ml_breakout_risk_high = bool(ml_overlay.get("breakout_risk_high", False))
        ml_do_predict = ml_overlay.get("do_predict")
        ml_source = str(ml_overlay.get("source", "none"))
        ml_gate_mode = str(getattr(self, "freqai_overlay_gate_mode", "advisory") or "advisory").strip().lower()
        if ml_gate_mode not in {"advisory", "strict"}:
            ml_gate_mode = "advisory"
        ml_gate_hard = bool(ml_gate_mode == "strict")
        ml_gate_effective_ok = bool(ml_gate_ok) if ml_gate_hard else True
        ml_applied_adjustments: List[Dict] = []

        # CVD divergence/BOS module.
        cvd_state = self._cvd_state(
            dataframe,
            self.cvd_lookback_bars,
            step_price,
            lo_p,
            hi_p,
            close,
            vrvp_val,
            vrvp_vah,
        )
        cvd_bos_against_range = bool(
            (bool(cvd_state.get("bos_up", False)) and bool(cvd_state.get("near_top", False)))
            or (bool(cvd_state.get("bos_down", False)) and bool(cvd_state.get("near_bottom", False)))
        )
        cvd_freeze_prev = int(self._cvd_freeze_bars_left_by_pair.get(pair, 0) or 0)
        cvd_freeze_left = max(cvd_freeze_prev - 1, 0)
        if cvd_bos_against_range:
            cvd_freeze_left = int(max(self.cvd_bos_freeze_bars, 1))
        self._cvd_freeze_bars_left_by_pair[pair] = int(cvd_freeze_left)
        cvd_freeze_active = bool(cvd_freeze_left > 0)
        cvd_state["freeze_bars_left"] = int(cvd_freeze_left)
        cvd_state["freeze_active"] = bool(cvd_freeze_active)
        cvd_gate_ok = bool((not self.cvd_enabled) or (not cvd_freeze_active))

        cvd_quick_tp_trigger = bool(
            bool(cvd_state.get("bos_up_near_bottom", False)) or bool(cvd_state.get("bos_down_near_top", False))
        )
        cvd_quick_tp_candidate = None
        if cvd_quick_tp_trigger:
            quick_tp_pool: List[float] = []
            for px in [vrvp_poc, q2, q1, q3]:
                pxf = self._safe_float(px)
                if pxf is not None and pxf > close:
                    quick_tp_pool.append(float(pxf))
            if len(quick_tp_pool):
                cvd_quick_tp_candidate = float(min(quick_tp_pool))

        # Micro-VAP inside current box.
        micro_vap = self._micro_vap_inside_box(
            dataframe,
            self.micro_vap_lookback_bars,
            self.micro_vap_bins,
            lo_p,
            hi_p,
            self.micro_hvn_quantile,
            self.micro_lvn_quantile,
            self.micro_extrema_count,
        ) if self.micro_vap_enabled else {
            "poc": None,
            "hvn_levels": [],
            "lvn_levels": [],
            "density": [],
            "edges": [],
            "lvn_density_threshold": None,
            "top_void": 0.0,
            "bottom_void": 0.0,
            "void_slope": 0.0,
        }
        micro_poc = self._safe_float(micro_vap.get("poc"))
        micro_hvn_levels = [float(x) for x in (micro_vap.get("hvn_levels") or [])]
        micro_lvn_levels = [float(x) for x in (micro_vap.get("lvn_levels") or [])]
        micro_top_void = float(self._safe_float(micro_vap.get("top_void")) or 0.0)
        micro_bottom_void = float(self._safe_float(micro_vap.get("bottom_void")) or 0.0)
        micro_void_slope = float(self._safe_float(micro_vap.get("void_slope")) or 0.0)
        buy_ratio_state = self._micro_buy_ratio_state(
            micro_vap.get("edges") or [],
            micro_vap.get("density") or [],
            box_low=lo_p,
            box_high=hi_p,
            close=close,
            midband_half_width=float(self.buy_ratio_midband_half_width),
            bullish_threshold=float(self.buy_ratio_bullish_threshold),
            bearish_threshold=float(self.buy_ratio_bearish_threshold),
        )
        poc_candidates = [x for x in (final_vrvp_poc, micro_poc) if x is not None]
        poc_acceptance_satisfied = self._poc_acceptance_status(pair, dataframe, poc_candidates)
        poc_alignment = self._poc_alignment_state(
            pair=pair,
            df=dataframe,
            vrvp_poc=final_vrvp_poc,
            micro_poc=micro_poc,
            step_price=step_price,
            box_low=lo_p,
            box_high=hi_p,
        )
        poc_alignment_ok = bool(poc_alignment.get("ok", True))

        # FVG stack (Defensive + IMFVG + Session FVG).
        fvg_state = self._fvg_stack_state(
            dataframe,
            self.fvg_lookback_bars,
            step_price,
            lo_p,
            hi_p,
            close,
        )
        session_vwap = self._safe_float(fvg_state.get("session_vwap"))
        session_high = self._safe_float(fvg_state.get("session_high"))
        session_low = self._safe_float(fvg_state.get("session_low"))
        daily_vwap = self._latest_daily_vwap(dataframe)
        fvg_gate_ok = bool((not self.fvg_enabled) or bool(fvg_state.get("gate_ok", False)))
        fvg_straddle_veto = bool(fvg_state.get("straddle_veto", False))
        fvg_defensive_conflict = bool(fvg_state.get("defensive_conflict", False))
        fvg_fresh_pause = bool(fvg_state.get("fresh_defensive_pause", False))
        session_fvg_pause_active = bool(fvg_state.get("session_pause_active", False))
        session_fvg_inside_block = bool(fvg_state.get("session_inside_block", False))
        fvg_vp_state = self._fvg_vp_state(
            dataframe,
            fvg_state=fvg_state,
            close=close,
            step_price=step_price,
        )
        order_block_state = self._order_block_state(
            pair=pair,
            dataframe=dataframe,
            close=close,
            step_price=step_price,
            box_low=lo_p,
            box_high=hi_p,
        )
        box_block_reasons.extend(self._derive_box_block_reasons(fvg_state))
        if bool(order_block_state.get("straddle_veto", False)):
            box_block_reasons.append(BlockReason.BLOCK_BOX_STRADDLE_OB_EDGE)
        if self._box_straddles_cached_breakout(pair, lo_p, hi_p, step_price):
            box_block_reasons.append(BlockReason.BLOCK_BOX_STRADDLE_BREAKOUT_LEVEL)
        session_zone_high = session_high
        session_zone_low = session_low
        extra_level_reasons = [
            (vrvp_poc, BlockReason.BLOCK_BOX_VP_POC_MISPLACED),
            (micro_poc, BlockReason.BLOCK_BOX_STRADDLE_FVG_AVG),
            (self._safe_float(fvg_state.get("positioning_up_avg")), BlockReason.BLOCK_BOX_STRADDLE_FVG_EDGE),
            (self._safe_float(fvg_state.get("positioning_down_avg")), BlockReason.BLOCK_BOX_STRADDLE_FVG_EDGE),
            (self._safe_float(fvg_state.get("session_fvg_avg")), BlockReason.BLOCK_BOX_STRADDLE_SESSION_FVG_AVG),
            (session_zone_high, BlockReason.BLOCK_BOX_STRADDLE_SESSION_FVG_AVG),
            (session_zone_low, BlockReason.BLOCK_BOX_STRADDLE_SESSION_FVG_AVG),
            (session_vwap, BlockReason.BLOCK_BOX_STRADDLE_VWAP_DONCHIAN_MID),
            (daily_vwap, BlockReason.BLOCK_BOX_STRADDLE_VWAP_DONCHIAN_MID),
        ]
        box_block_reasons.extend(
            self._box_level_straddle_reasons(pair, lo_p, hi_p, step_price, extra_level_reasons)
        )

        donchian_mid = self._safe_float(last.get("donchian_mid_15m"))
        basis_mid = self._safe_float(last.get("basis_mid_15m"))
        basis_upper = self._safe_float(last.get("basis_upper_15m"))
        basis_lower = self._safe_float(last.get("basis_lower_15m"))
        basis_raw_now = self._safe_float(last.get("basis_15m"))
        basis_raw_prev = None
        if len(dataframe) >= 2 and "basis_15m" in dataframe.columns:
            basis_raw_prev = self._safe_float(dataframe["basis_15m"].iloc[-2])
        basis_cross_confirm = bool(
            basis_raw_prev is not None
            and basis_raw_now is not None
            and ((basis_raw_prev <= 0.0 <= basis_raw_now) or (basis_raw_prev >= 0.0 >= basis_raw_now))
        )
        hvn_nearest_above = self._nearest_above(close, micro_hvn_levels)
        fvg_poc = self._safe_float(fvg_vp_state.get("nearest_poc")) if self.fvg_vp_enabled else None
        if fvg_poc is None and self.fvg_vp_enabled:
            fvg_poc = micro_poc
        channel_midline = self._safe_float(last.get("bb_mid_15m"))
        channel_upper = bb_upper_15m
        channel_lower = bb_lower_15m
        donchian_high = self._safe_float(last.get("donchian_high_15m"))
        donchian_low = self._safe_float(last.get("donchian_low_15m"))
        smart_channel_state = self._smart_channel_state(
            dataframe,
            close=close,
            step_price=step_price,
            channel_midline=channel_midline,
            channel_upper=channel_upper,
            channel_lower=channel_lower,
            donchian_high=donchian_high,
            donchian_low=donchian_low,
            rvol_15m=rvol_15m,
        )
        session_sweep_state = self._session_sweep_state(
            dataframe,
            step_price=step_price,
            box_low=lo_p,
            box_high=hi_p,
        )
        prev_close_for_flow = self._safe_float(dataframe["close"].iloc[-2]) if len(dataframe) >= 2 else None
        order_flow_state = self._order_flow_state(
            last_row=last,
            close=close,
            prev_close=prev_close_for_flow,
        )
        midline_bias = self._midline_bias_fallback_state(
            close=close,
            box_low=lo_p,
            box_high=hi_p,
            step_price=step_price,
            vrvp_poc=vrvp_poc,
            channel_midline=channel_midline,
            basis_mid=basis_mid,
            donchian_mid=donchian_mid,
            session_vwap=session_vwap,
            daily_vwap=daily_vwap,
        )
        midline_bias_tp_candidate = self._safe_float(midline_bias.get("tp_candidate"))

        tp_candidate_prices = {
            "box_default_tp": float(tp_price),
            "quartile_q1": float(q1),
            "quartile_q3": float(q3),
            "extension_1386_hi": float(ext_hi),
            "midline_bias_tp": midline_bias_tp_candidate,
            "vrvp_poc": self._safe_float(vrvp_poc),
            "mrvd_day_poc": mrvd_day_poc,
            "mrvd_week_poc": mrvd_week_poc,
            "mrvd_month_poc": mrvd_month_poc,
            "donchian_mid": donchian_mid,
            "session_vwap": session_vwap,
            "daily_vwap": daily_vwap,
            "basis_upper": basis_upper,
            "basis_mid": basis_mid,
            "imfvg_avg_bull": self._safe_float(fvg_state.get("imfvg_avg_bull")),
            "session_fvg_avg": self._safe_float(fvg_state.get("session_fvg_avg")),
            "fvg_position_up_avg": self._safe_float(fvg_state.get("positioning_up_avg")),
            "fvg_position_down_avg": self._safe_float(fvg_state.get("positioning_down_avg")),
            "hvn_nearest": hvn_nearest_above,
            "fvg_poc": fvg_poc,
            "fvg_vp_poc_bull": self._safe_float(fvg_vp_state.get("bull_poc")),
            "fvg_vp_poc_bear": self._safe_float(fvg_vp_state.get("bear_poc")),
            "channel_midline": channel_midline,
            "channel_upper": channel_upper,
            "channel_lower": channel_lower,
            "smart_channel_tp_nudge": self._safe_float(smart_channel_state.get("tp_nudge")),
            "session_sweep_tp_nudge": self._safe_float(session_sweep_state.get("tp_nudge")),
            "ob_tp_mid": self._safe_float(order_block_state.get("tp_mid")),
            "ob_tp_edge": self._safe_float(order_block_state.get("tp_edge")),
            "cvd_quick_tp_candidate": cvd_quick_tp_candidate,
            "ml_quick_tp_candidate": ml_quick_tp_candidate,
        }
        tp_price_plan, tp_selection = self._select_tp_price(close, float(tp_price), tp_candidate_prices)
        tp_source_alias = {
            "ob_tp_mid": "OB_MID",
            "ob_tp_edge": "OB_EDGE",
            "session_sweep_tp_nudge": "SWEEP_NUDGE",
        }
        tp_selection["source"] = tp_source_alias.get(str(tp_selection.get("source")), tp_selection.get("source"))

        # Preserve existing fast-exit nudges while keeping "nearest conservative wins".
        if cvd_quick_tp_candidate is not None and cvd_quick_tp_candidate > close:
            tp_price_plan = float(min(tp_price_plan, cvd_quick_tp_candidate))
            tp_selection["source"] = "cvd_quick_tp_candidate"
            tp_selection["nearest_conservative"] = float(tp_price_plan)
        if ml_quick_tp_candidate is not None and ml_quick_tp_candidate > close:
            tp_price_plan = float(min(tp_price_plan, ml_quick_tp_candidate))
            tp_selection["source"] = "ml_quick_tp_candidate"
            tp_selection["nearest_conservative"] = float(tp_price_plan)
            ml_applied_adjustments.append(
                {
                    "type": "tp_cap",
                    "source": "ml_quick_tp_candidate",
                    "value": float(tp_price_plan),
                }
            )

        tp_candidates = {
            "base_tp": float(tp_price),
            "box_default_tp": float(tp_price),
            "quartile_q1": float(q1),
            "quartile_q3": float(q3),
            "extension_1386_hi": float(ext_hi),
            "midline_bias_tp": midline_bias_tp_candidate,
            "vrvp_poc": self._safe_float(vrvp_poc),
            "imfvg_avg_bull": self._safe_float(fvg_state.get("imfvg_avg_bull")),
            "imfvg_avg_bear": self._safe_float(fvg_state.get("imfvg_avg_bear")),
            "session_fvg_avg": self._safe_float(fvg_state.get("session_fvg_avg")),
            "fvg_position_up_avg": self._safe_float(fvg_state.get("positioning_up_avg")),
            "fvg_position_down_avg": self._safe_float(fvg_state.get("positioning_down_avg")),
            "midline_bias_state": dict(midline_bias),
            "mrvd_day_poc": mrvd_day_poc,
            "mrvd_week_poc": mrvd_week_poc,
            "mrvd_month_poc": mrvd_month_poc,
            "donchian_mid": donchian_mid,
            "session_vwap": session_vwap,
            "daily_vwap": daily_vwap,
            "basis_upper": basis_upper,
            "basis_lower": basis_lower,
            "basis_mid": basis_mid,
            "hvn_nearest": hvn_nearest_above,
            "fvg_poc": fvg_poc,
            "fvg_vp_poc_bull": self._safe_float(fvg_vp_state.get("bull_poc")),
            "fvg_vp_poc_bear": self._safe_float(fvg_vp_state.get("bear_poc")),
            "channel_midline": channel_midline,
            "channel_upper": channel_upper,
            "channel_lower": channel_lower,
            "session_high": session_high,
            "session_low": session_low,
            "session_sweep_tp_nudge": self._safe_float(session_sweep_state.get("tp_nudge")),
            "smart_channel_tp_nudge": self._safe_float(smart_channel_state.get("tp_nudge")),
            "ob_tp_mid": self._safe_float(order_block_state.get("tp_mid")),
            "ob_tp_edge": self._safe_float(order_block_state.get("tp_edge")),
            "cvd_quick_tp_candidate": cvd_quick_tp_candidate,
            "cvd_quick_tp_trigger": bool(cvd_quick_tp_trigger),
            "ml_quick_tp_candidate": ml_quick_tp_candidate,
            "ml_breakout_risk_high": bool(ml_breakout_risk_high),
            "ml_p_range": p_range,
            "ml_p_breakout": p_breakout,
            "selection": dict(tp_selection),
        }
        box_span = max(float(hi_p - lo_p), 0.0)
        box_position = 0.5
        if box_span > 0:
            box_position = float(np.clip((close - lo_p) / box_span, 0.0, 1.0))
        meta_drift_state = self._meta_drift_state(
            pair,
            last_row=last,
            close=close,
            atr_pct_15m=atr_pct_15m,
            rvol_15m=rvol_15m,
            box_position=box_position,
            running_active=running_active_hint,
        )
        meta_drift_soft_block = bool(
            meta_drift_soft_block_mrvd or bool(meta_drift_state.get("soft_block", False))
        )
        meta_drift_hard_stop = bool(meta_drift_state.get("hard_stop", False))
        meta_drift_recommended_action = str(meta_drift_state.get("recommended_action", "NONE"))
        start_box_position_ok = bool(
            (not self.start_box_position_guard_enabled)
            or (
                float(self.start_box_position_min_frac)
                <= box_position
                <= float(self.start_box_position_max_frac)
            )
        )
        basis_cross_ok = bool((not self.basis_cross_confirm_enabled) or basis_cross_confirm)
        capacity_hint = self._capacity_hint_state(pair)
        capacity_hint_allow = bool(capacity_hint.get("allow_start", True))
        capacity_hint_advisory_only = bool(capacity_hint.get("advisory_only", not self.capacity_hint_hard_block))
        capacity_hint_ok = bool(capacity_hint_allow or capacity_hint_advisory_only)
        squeeze_momentum_flip_against_edge = False
        squeeze_momentum_decelerating = False
        if squeeze_val_1h is not None and squeeze_val_prev_1h is not None:
            near_lower = bool(box_position <= 0.5)
            near_upper = bool(box_position > 0.5)
            flip_to_negative = bool(squeeze_val_prev_1h >= 0 and squeeze_val_1h < 0)
            flip_to_positive = bool(squeeze_val_prev_1h <= 0 and squeeze_val_1h > 0)
            squeeze_momentum_flip_against_edge = bool(
                (near_lower and flip_to_negative) or (near_upper and flip_to_positive)
            )
            squeeze_momentum_decelerating = bool(abs(float(squeeze_val_1h)) < abs(float(squeeze_val_prev_1h)))
        squeeze_tp_nudged = False
        if (
            self.squeeze_tp_nudge_enabled
            and squeeze_momentum_decelerating
            and step_price > 0
            and tp_price_plan > close
        ):
            nudge_tp = close + (float(self.squeeze_tp_nudge_step_multiple) * step_price)
            tp_price_plan = float(min(tp_price_plan, nudge_tp))
            squeeze_tp_nudged = True
        hvp_quiet_exit_tp_nudged = False
        if (
            self.hvp_quiet_exit_bias_enabled
            and hvp_quiet_exit_bias
            and step_price > 0
            and tp_price_plan > close
        ):
            nudge_tp = close + (float(self.hvp_quiet_exit_step_multiple) * step_price)
            tp_price_plan = float(min(tp_price_plan, nudge_tp))
            hvp_quiet_exit_tp_nudged = True
        smart_channel_tp_nudged = False
        smart_channel_tp = self._safe_float(smart_channel_state.get("tp_nudge"))
        if smart_channel_tp is not None and smart_channel_tp > close and tp_price_plan > close:
            tp_price_plan = float(min(tp_price_plan, smart_channel_tp))
            smart_channel_tp_nudged = True
        session_sweep_tp_nudged = False
        session_sweep_tp = self._safe_float(session_sweep_state.get("tp_nudge"))
        if session_sweep_tp is not None and session_sweep_tp > close and tp_price_plan > close:
            tp_price_plan = float(min(tp_price_plan, session_sweep_tp))
            session_sweep_tp_nudged = True
        buy_ratio_tp_nudged = False
        if (
            bool(self.buy_ratio_bias_enabled)
            and int(buy_ratio_state.get("bias", 0)) < 0
            and step_price > 0
            and tp_price_plan > close
        ):
            nudge_tp = close + (float(self.buy_ratio_bearish_tp_step_multiple) * step_price)
            tp_price_plan = float(min(tp_price_plan, nudge_tp))
            buy_ratio_tp_nudged = True
        sl_price, sl_selection = self._select_sl_price(
            sl_base=sl_price,
            step_price=step_price,
            lvn_levels=micro_lvn_levels,
            fvg_state=fvg_state,
        )

        levels_arr = np.linspace(lo_p, hi_p, n_levels + 1, dtype=float)
        rung_weights = self._rung_weights_from_micro_vap(
            levels_arr,
            micro_vap.get("edges") or [],
            micro_vap.get("density") or [],
            self._safe_float(micro_vap.get("lvn_density_threshold")),
            self.rung_weight_hvn_boost,
            self.rung_weight_lvn_penalty,
            self.rung_weight_min,
            self.rung_weight_max,
        )
        rung_weights = self._apply_cvd_rung_bias(
            levels_arr,
            rung_weights,
            lo_p,
            hi_p,
            bool(cvd_state.get("bull_divergence_near_bottom", False)),
            bool(cvd_state.get("bear_divergence_near_top", False)),
            self.cvd_rung_bias_strength,
            self.rung_weight_min,
            self.rung_weight_max,
        )
        rung_weights = self._apply_buy_ratio_rung_bias(
            levels_arr,
            rung_weights,
            box_low=lo_p,
            box_high=hi_p,
            bias=int(buy_ratio_state.get("bias", 0)) if self.buy_ratio_bias_enabled else 0,
            strength=float(self.buy_ratio_rung_bias_strength),
            w_min=float(self.rung_weight_min),
            w_max=float(self.rung_weight_max),
        )
        order_flow_confidence = float(order_flow_state.get("confidence_modifier", 1.0) or 1.0)
        if order_flow_confidence < 0.999:
            rung_weights = [
                float(np.clip(float(w) * order_flow_confidence, float(self.rung_weight_min), float(self.rung_weight_max)))
                for w in rung_weights
            ]
        rung_weights_before_ml = [float(x) for x in rung_weights]
        rung_weights = self._apply_ml_rung_safety(
            levels_arr,
            rung_weights,
            lo_p,
            hi_p,
            p_breakout,
            self.freqai_overlay_rung_edge_cut_max,
            self.rung_weight_min,
            self.rung_weight_max,
        )
        ml_rung_adjusted = bool(
            any(abs(float(a) - float(b)) > 1e-12 for a, b in zip(rung_weights_before_ml, rung_weights))
        )
        if ml_rung_adjusted:
            ml_applied_adjustments.append(
                {
                    "type": "rung_edge_safety",
                    "source": "ml_p_breakout",
                    "p_breakout": p_breakout,
                    "edge_cut_max": float(self.freqai_overlay_rung_edge_cut_max),
                }
            )
        micro_poc_vrvp_steps = None
        if micro_poc is not None and vrvp_poc is not None and step_price > 0:
            micro_poc_vrvp_steps = abs(micro_poc - vrvp_poc) / step_price

        # os_dev regime state with strike confirmation.
        os_dev_raw = 0
        os_dev_norm = None
        half_span = (hi_p - lo_p) / 2.0
        if half_span > 0:
            os_dev_norm = (close - mid) / half_span
            if os_dev_norm > self.os_dev_range_band:
                os_dev_raw = 1
            elif os_dev_norm < -self.os_dev_range_band:
                os_dev_raw = -1

        os_dev_state = int(self._os_dev_state_by_pair.get(pair, 0))
        os_dev_candidate = int(self._os_dev_candidate_by_pair.get(pair, os_dev_state))
        os_dev_candidate_count = int(self._os_dev_candidate_count_by_pair.get(pair, 0))
        os_dev_zero_persist = int(self._os_dev_zero_persist_by_pair.get(pair, 0))

        if self.os_dev_enabled:
            close_hist = pd.to_numeric(dataframe["close"], errors="coerce").to_numpy(dtype=float)
            hist_bars = max(int(self.os_dev_history_bars), int(self.os_dev_persist_bars), 1)
            if len(close_hist) > hist_bars:
                close_hist = close_hist[-hist_bars:]

            os_dev_state, os_dev_candidate, os_dev_candidate_count, os_dev_zero_persist = self._os_dev_from_history(
                close_hist,
                mid,
                half_span,
                self.os_dev_range_band,
                self.os_dev_n_strike,
            )

            self._os_dev_state_by_pair[pair] = int(os_dev_state)
            self._os_dev_candidate_by_pair[pair] = int(os_dev_candidate)
            self._os_dev_candidate_count_by_pair[pair] = int(os_dev_candidate_count)
            self._os_dev_zero_persist_by_pair[pair] = int(os_dev_zero_persist)

            os_dev_rvol_ok = bool(rvol_15m is not None and rvol_15m <= gate_os_dev_rvol_max)
            os_dev_build_ok = bool(
                os_dev_state == 0 and os_dev_zero_persist >= gate_os_dev_persist_bars and os_dev_rvol_ok
            )
            os_dev_trend_stop = bool(os_dev_state != 0)
        else:
            os_dev_rvol_ok = True
            os_dev_build_ok = True
            os_dev_trend_stop = False

        drawdown_state = self._drawdown_guard_state(dataframe)
        drawdown_guard_triggered = bool(drawdown_state.get("triggered", False))
        smart_channel_stop = bool(smart_channel_state.get("stop_triggered", False))
        session_break_retest_stop = bool(session_sweep_state.get("stop_triggered", False))

        neutral_adx_overheat_stop = bool(
            neutral_mode_active
            and adx_exit_overheat
            and (adx_rising_count >= int(self.neutral_stop_adx_bars))
        )
        neutral_bbwp_expansion_stop = bool(neutral_mode_active and bbwp_expansion_stop)
        prev_box_break = int(self._neutral_box_break_bars_by_pair.get(pair, 0) or 0)
        # ---- Stop logic (15m) ----
        flags = self._breakout_flags(close, lo_p, hi_p, step_price)
        overshoot_up = flags["close_outside_up"] and ((close - hi_p) > (self.neutral_box_break_step_multiple * step_price))
        overshoot_dn = flags["close_outside_dn"] and ((lo_p - close) > (self.neutral_box_break_step_multiple * step_price))
        if overshoot_up or overshoot_dn:
            box_break_bars = prev_box_break + 1
        else:
            box_break_bars = 0
        self._neutral_box_break_bars_by_pair[pair] = max(box_break_bars, 0)
        neutral_box_break_stop = bool(neutral_mode_active and box_break_bars >= int(self.neutral_box_break_bars))

        # Squeeze gate and release stop trigger.
        squeeze_gate_ok = True
        if self.squeeze_enabled and self.squeeze_require_on_1h:
            squeeze_gate_ok = bool(squeeze_on_1h)
        squeeze_release_against_bias = bool(
            squeeze_released_1h
            and (
                (box_position <= 0.5 and close < (lo_p - step_price))
                or (box_position > 0.5 and close > (hi_p + step_price))
            )
        )
        squeeze_release_break_stop = bool(
            self.squeeze_enabled
            and squeeze_release_against_bias
        )

        c1 = float(dataframe["close"].iloc[-1])
        c2 = float(dataframe["close"].iloc[-2])
        two_up = (c1 > hi_p) and (c2 > hi_p)
        two_dn = (c1 < lo_p) and (c2 < lo_p)

        prev_mid = self._last_mid_by_pair.get(pair)
        shift_stop = False
        shift_frac = None
        if prev_mid is not None and prev_mid > 0:
            shift_frac = abs(mid - prev_mid) / prev_mid
            shift_stop = shift_frac >= self.range_shift_stop_pct
        running_mode_prev = None
        if running_active_hint:
            running_mode_prev = self._normalize_mode_name(self._running_mode_by_pair.get(pair))
        mode_handoff_required_stop = bool(
            running_active_hint
            and (running_mode_prev in self.MODE_TRADING)
            and (desired_mode in self.MODE_TRADING)
            and (desired_mode != running_mode_prev)
        )
        router_pause_stop = bool(running_active_hint and mode_pause)

        lvn_corridor_width = max(self.micro_lvn_corridor_steps * step_price, 0.0)
        upper_edge_lvn = any(abs(float(x) - hi_p) <= lvn_corridor_width for x in micro_lvn_levels)
        lower_edge_lvn = any(abs(float(x) - lo_p) <= lvn_corridor_width for x in micro_lvn_levels)
        lvn_corridor_stop_up = bool(
            flags["close_outside_up"]
            and upper_edge_lvn
            and micro_void_slope >= self.micro_void_slope_threshold
        )
        lvn_corridor_stop_dn = bool(
            flags["close_outside_dn"]
            and lower_edge_lvn
            and micro_void_slope >= self.micro_void_slope_threshold
        )
        lvn_corridor_stop_override = bool(lvn_corridor_stop_up or lvn_corridor_stop_dn)
        fvg_conflict_stop_up = bool(flags["close_outside_up"] and bool(fvg_state.get("defensive_bear_conflict", False)))
        fvg_conflict_stop_dn = bool(flags["close_outside_dn"] and bool(fvg_state.get("defensive_bull_conflict", False)))
        fvg_conflict_stop_override = bool(fvg_conflict_stop_up or fvg_conflict_stop_dn)
        fvg_vp_tagged = bool(fvg_vp_state.get("poc_tagged", False))
        fvg_vp_stop_override = bool(
            fvg_vp_tagged
            and (flags["close_outside_up"] or flags["close_outside_dn"])
        )
        fresh_breakout_idle_reclaim_stop = bool(
            self.breakout_idle_reclaim_on_fresh
            and breakout_fresh_block_active
            and running_active_hint
        )
        stop_reason_flags_raw = {
            "two_consecutive_outside_up": bool(two_up),
            "two_consecutive_outside_dn": bool(two_dn),
            str(StopReason.STOP_BREAKOUT_CONFIRM_UP): bool(breakout_confirm_stop_up),
            str(StopReason.STOP_BREAKOUT_CONFIRM_DN): bool(breakout_confirm_stop_dn),
            "fast_outside_up": bool(flags["fast_outside_up"]),
            "fast_outside_dn": bool(flags["fast_outside_dn"]),
            "adx_hysteresis_stop": bool(adx_exit_overheat),
            "adx_di_down_risk_stop": bool(adx_di_down_risk_stop),
            "bbwp_expansion_stop": bool(bbwp_expansion_stop),
            "squeeze_release_break_stop": bool(squeeze_release_break_stop),
            "os_dev_trend_stop": bool(os_dev_trend_stop),
            "lvn_corridor_stop_override": bool(lvn_corridor_stop_override),
            "lvn_corridor_stop_up": bool(lvn_corridor_stop_up),
            "lvn_corridor_stop_dn": bool(lvn_corridor_stop_dn),
            "fvg_conflict_stop_override": bool(fvg_conflict_stop_override),
            "fvg_conflict_stop_up": bool(fvg_conflict_stop_up),
            "fvg_conflict_stop_dn": bool(fvg_conflict_stop_dn),
            "fvg_vp_stop_override": bool(fvg_vp_stop_override),
            "smart_channel_stop": bool(smart_channel_stop),
            "session_break_retest_stop": bool(session_break_retest_stop),
            "drawdown_guard_triggered": bool(drawdown_guard_triggered),
            "neutral_adx_overheat_stop": bool(neutral_adx_overheat_stop),
            "neutral_bbwp_expansion_stop": bool(neutral_bbwp_expansion_stop),
            "neutral_box_break_stop": bool(neutral_box_break_stop),
            "mode_handoff_required_stop": bool(mode_handoff_required_stop),
            "router_pause_stop": bool(router_pause_stop),
            "fresh_breakout_idle_reclaim_stop": bool(fresh_breakout_idle_reclaim_stop),
            "meta_drift_hard_stop": bool(meta_drift_hard_stop),
            "range_shift_stop": bool(shift_stop),
        }
        stop_reason_enum_active: List[str] = []
        if neutral_adx_overheat_stop:
            stop_reason_enum_active.append(self.STOP_REASON_TREND_ADX)
        if neutral_bbwp_expansion_stop:
            stop_reason_enum_active.append(self.STOP_REASON_VOL_EXPANSION)
        if neutral_box_break_stop:
            stop_reason_enum_active.append(self.STOP_REASON_BOX_BREAK)
        if breakout_confirm_stop_up:
            stop_reason_enum_active.append(str(StopReason.STOP_BREAKOUT_CONFIRM_UP))
        if breakout_confirm_stop_dn:
            stop_reason_enum_active.append(str(StopReason.STOP_BREAKOUT_CONFIRM_DN))
        if smart_channel_stop:
            stop_reason_enum_active.append(str(StopReason.STOP_CHANNEL_STRONG_BREAK))
        if session_break_retest_stop:
            stop_reason_enum_active.append(str(StopReason.STOP_LIQUIDITY_SWEEP_BREAK_RETEST))
        if drawdown_guard_triggered:
            stop_reason_enum_active.append(str(StopReason.STOP_DRAWDOWN_GUARD))
        if fvg_vp_stop_override:
            stop_reason_enum_active.append(str(StopReason.STOP_FVG_VOID_CONFLUENCE))
        if meta_drift_hard_stop:
            stop_reason_enum_active.append(self.STOP_REASON_META_DRIFT_HARD)
        stop_reason_primary = str(stop_reason_enum_active[0]) if stop_reason_enum_active else None

        hard_stop = bool(
            flags["fast_outside_up"]
            or flags["fast_outside_dn"]
            or adx_exit_overheat
            or adx_di_down_risk_stop
            or bbwp_expansion_stop
            or squeeze_release_break_stop
            or os_dev_trend_stop
            or lvn_corridor_stop_override
            or fvg_conflict_stop_override
            or fvg_vp_stop_override
            or smart_channel_stop
            or session_break_retest_stop
            or drawdown_guard_triggered
            or mode_handoff_required_stop
            or router_pause_stop
            or fresh_breakout_idle_reclaim_stop
            or meta_drift_hard_stop
        )
        raw_stop_rule = bool(breakout_confirm_stop_up or breakout_confirm_stop_dn or hard_stop or shift_stop)

        # ---- Entry sanity (15m) ----
        price_in_box = (close >= lo_p) and (close <= hi_p)
        rsi_ok = (rsi is not None) and (self.rsi_min <= rsi <= self.rsi_max)
        mrvd_proximity_ok = bool((not self.mrvd_enabled) or mrvd_near_any_poc or mrvd_overlap_ok)
        micro_vap_ok = bool((not self.micro_vap_enabled) or (len(rung_weights) == (n_levels + 1)))

        # ---- Regime allow ----
        phase2_gate_failures = self._phase2_gate_failures_from_flags(
            bool(adx_ok),
            bool(bbw_nonexp),
            bool(ema_dist_ok),
            bool(vol_ok),
            bool(inside_7d_gate_ok),
        )
        if not inside_7d and (not gate_context_7d_hard_veto):
            phase2_gate_failures = [x for x in phase2_gate_failures if x != BlockReason.BLOCK_7D_EXTREME_CONTEXT]
        if not band_slope_gate_ok:
            phase2_gate_failures.append(BlockReason.BLOCK_BAND_SLOPE_HIGH)
        if not excursion_asymmetry_gate_ok:
            phase2_gate_failures.append(BlockReason.BLOCK_EXCURSION_ASYMMETRY)
        if not drift_slope_gate_ok:
            phase2_gate_failures.append(BlockReason.BLOCK_DRIFT_SLOPE_HIGH)
        if not zigzag_contraction_gate_ok:
            phase2_gate_failures.append(BlockReason.BLOCK_START_PERSISTENCE_FAIL)
        if self.bbwp_enabled:
            if not bbwp_allow:
                phase2_gate_failures.append(BlockReason.BLOCK_BBWP_HIGH)
            if bbwp_veto:
                phase2_gate_failures.append(BlockReason.BLOCK_BBWP_HIGH)
            if bbwp_cooloff:
                phase2_gate_failures.append(BlockReason.COOLOFF_BBWP_EXTREME)
        if breakout_fresh_block_active:
            phase2_gate_failures.append(BlockReason.BLOCK_FRESH_BREAKOUT)
        if bool(order_block_state.get("fresh_block", False)):
            phase2_gate_failures.append(BlockReason.BLOCK_FRESH_OB_COOLOFF)
        if min_range_len_block_reason is not None:
            phase2_gate_failures.append(min_range_len_block_reason)
        if breakout_confirm_block_reason is not None:
            phase2_gate_failures.append(breakout_confirm_block_reason)
        if not funding_gate_ok:
            phase2_gate_failures.append(BlockReason.BLOCK_FUNDING_FILTER)
        if not hvp_gate_ok:
            phase2_gate_failures.append(BlockReason.BLOCK_HVP_EXPANDING)
        if drawdown_guard_triggered:
            phase2_gate_failures.append(BlockReason.BLOCK_DRAWDOWN_GUARD)
        if bool(session_sweep_state.get("block_start", False)):
            phase2_gate_failures.append(BlockReason.BLOCK_LIQ_SWEEP_OPPOSITE_STRUCTURE)
        if bool(order_flow_state.get("hard_block", False)):
            phase2_gate_failures.append(BlockReason.BLOCK_CAPACITY_THIN)
        if meta_drift_soft_block:
            phase2_gate_failures.append(BlockReason.BLOCK_META_DRIFT_SOFT)
        if not planner_health_ok:
            phase2_gate_failures.append(BlockReason.BLOCK_STALE_FEATURES)
        if self.os_dev_enabled and (not os_dev_build_ok):
            if os_dev_state != 0:
                phase2_gate_failures.append(BlockReason.BLOCK_OS_DEV_DIRECTIONAL)
            else:
                phase2_gate_failures.append(BlockReason.BLOCK_OS_DEV_NEUTRAL_PERSISTENCE)
        if self.squeeze_enabled and (not squeeze_gate_ok):
            phase2_gate_failures.append(BlockReason.BLOCK_SQUEEZE_RELEASE_AGAINST_BIAS)
        if self.squeeze_momentum_block_enabled and squeeze_momentum_flip_against_edge:
            phase2_gate_failures.append(BlockReason.BLOCK_SQUEEZE_RELEASE_AGAINST_BIAS)
        squeeze_release_reason = self._squeeze_release_block_reason(squeeze_release_break_stop)
        if squeeze_release_reason:
            phase2_gate_failures.append(squeeze_release_reason)
        if step_cost_block_reason is not None:
            phase2_gate_failures.append(step_cost_block_reason)
        if not start_box_position_ok:
            phase2_gate_failures.append(BlockReason.BLOCK_START_BOX_POSITION)
        if not rsi_ok:
            phase2_gate_failures.append(BlockReason.BLOCK_START_RSI_BAND)
        if self.poc_acceptance_enabled and (not poc_acceptance_satisfied):
            phase2_gate_failures.append(BlockReason.BLOCK_NO_POC_ACCEPTANCE)
        if not poc_alignment_ok:
            phase2_gate_failures.append(BlockReason.BLOCK_POC_ALIGNMENT_FAIL)
        if not mrvd_proximity_ok:
            phase2_gate_failures.append(BlockReason.BLOCK_VAH_VAL_POC_PROXIMITY)
        if not basis_cross_ok:
            phase2_gate_failures.append(BlockReason.BLOCK_BASIS_CROSS_PENDING)
        if (not capacity_hint_ok) and (not capacity_hint_advisory_only):
            phase2_gate_failures.append(BlockReason.BLOCK_CAPACITY_THIN)
        phase2_gate_failures = list(dict.fromkeys(phase2_gate_failures))

        gate_checks = [
            ("planner_health_ok", bool(planner_health_ok)),
            ("mode_active_ok", bool(not mode_pause)),
            ("adx_ok", bool(adx_ok)),
            ("bbw_nonexp", bool(bbw_nonexp)),
            ("ema_dist_ok", bool(ema_dist_ok)),
            ("vol_ok", bool(vol_ok)),
            ("atr_ok", bool(atr_ok)),
            ("inside_7d", bool(inside_7d_gate_ok)),
            ("breakout_fresh_gate_ok", bool(not breakout_fresh_block_active)),
            ("fresh_ob_gate_ok", bool(not order_block_state.get("fresh_block", False))),
            ("min_range_len_ok", bool(min_range_len_ok)),
            ("breakout_confirm_gate_ok", bool(breakout_confirm_gate_ok)),
            ("vrvp_box_ok", bool(vrvp_box_ok)),
            ("bbwp_gate_ok", bool(bbwp_gate_ok)),
            ("squeeze_gate_ok", bool(squeeze_gate_ok)),
            ("os_dev_build_ok", bool(os_dev_build_ok)),
            ("micro_vap_ok", bool(micro_vap_ok)),
            ("fvg_gate_ok", bool(fvg_gate_ok)),
            ("mrvd_gate_ok", bool(mrvd_gate_ok)),
            ("cvd_gate_ok", bool(cvd_gate_ok)),
            ("ml_gate_ok", bool(ml_gate_effective_ok)),
            ("band_slope_gate_ok", bool(band_slope_gate_ok)),
            ("excursion_asymmetry_gate_ok", bool(excursion_asymmetry_gate_ok)),
            ("drift_slope_gate_ok", bool(drift_slope_gate_ok)),
            ("zigzag_contraction_gate_ok", bool(zigzag_contraction_gate_ok)),
            ("step_cost_ok", bool(step_cost_block_reason is None)),
            ("width_avg_veto_ok", bool(not width_avg_state.get("veto", False))),
            ("start_box_position_ok", bool(start_box_position_ok)),
            ("rsi_guard_ok", bool(rsi_ok)),
            ("poc_acceptance_ok", bool(poc_acceptance_satisfied)),
            ("poc_alignment_ok", bool(poc_alignment_ok)),
            ("mrvd_proximity_ok", bool(mrvd_proximity_ok)),
            ("basis_cross_ok", bool(basis_cross_ok)),
            ("capacity_hint_ok", bool(capacity_hint_ok)),
            ("order_flow_hard_block_ok", bool(not order_flow_state.get("hard_block", False))),
            ("drawdown_guard_ok", bool(not drawdown_guard_triggered)),
            ("meta_drift_soft_block_ok", bool(not meta_drift_soft_block)),
            ("funding_gate_ok", bool(funding_gate_ok)),
            ("hvp_gate_ok", bool(hvp_gate_ok)),
            ("volatility_policy_ok", bool(volatility_strictness_ok)),
        ]
        rule_range_ok = bool(all(ok for _, ok in gate_checks))
        gate_pass_count = int(sum(1 for _, ok in gate_checks if ok))
        gate_total_count = int(len(gate_checks))
        gate_pass_ratio = float(gate_pass_count / gate_total_count) if gate_total_count > 0 else 0.0
        core_gate_names = {
            "planner_health_ok",
            "mode_active_ok",
            "adx_ok",
            "bbw_nonexp",
            "ema_dist_ok",
            "vol_ok",
            "atr_ok",
            "inside_7d",
            "min_range_len_ok",
            "breakout_confirm_gate_ok",
            "fresh_ob_gate_ok",
            "vrvp_box_ok",
            "step_cost_ok",
            "width_avg_veto_ok",
            "start_box_position_ok",
            "rsi_guard_ok",
            "poc_acceptance_ok",
            "poc_alignment_ok",
        }
        core_gates_ok = bool(all(ok for name, ok in gate_checks if name in core_gate_names))
        gate_ratio_ok = bool(gate_pass_ratio >= gate_start_min_pass_ratio_effective)
        start_stability = self._start_stability_state(
            gate_checks,
            self.start_stability_min_score,
            self.start_stability_k_fraction,
        )
        start_stability_ok = bool(start_stability.get("ok", False))
        phase2_gate_ok = not phase2_gate_failures

        rule_range_fail_reasons = []
        for gate_name, gate_ok in gate_checks:
            if not gate_ok:
                rule_range_fail_reasons.append(gate_name)

        ex_name = (self.config.get("exchange", {}) or {}).get("name", "unknown")
        ts = datetime.now(timezone.utc).isoformat()

        # Candle timestamp (THIS is what simulator/executor can align to)
        candle_ts = None
        candle_time_utc = None
        try:
            if "date" in dataframe.columns:
                candle_dt = pd.Timestamp(last["date"])
                if candle_dt.tzinfo is None:
                    candle_dt = candle_dt.tz_localize("UTC")
                else:
                    candle_dt = candle_dt.tz_convert("UTC")
                candle_time_utc = candle_dt.isoformat()
                candle_ts = int(candle_dt.timestamp())
            elif isinstance(dataframe.index, pd.DatetimeIndex):
                candle_dt = pd.Timestamp(dataframe.index[-1])
                if candle_dt.tzinfo is None:
                    candle_dt = candle_dt.tz_localize("UTC")
                else:
                    candle_dt = candle_dt.tz_convert("UTC")
                candle_time_utc = candle_dt.isoformat()
                candle_ts = int(candle_dt.timestamp())
        except Exception:
            candle_ts = None
            candle_time_utc = None

        # ---- Reclaim / cooldown / min-runtime handling ----
        clock_ts = candle_ts if candle_ts is not None else int(router_clock_ts)
        min_runtime_base_secs_raw = int(max(float(self.min_runtime_hours), 0.0) * 3600.0)
        reclaim_secs = int(max(float(self.reclaim_hours), 0.0) * 3600.0)
        cooldown_base_secs_raw = int(max(float(self.cooldown_minutes), 0.0) * 60.0)
        min_runtime_base_secs = int(max(float(min_runtime_minutes_effective), 0.0) * 60.0)
        cooldown_base_secs = int(max(float(cooldown_minutes_effective), 0.0) * 60.0)
        neutral_min_runtime_offset_secs = int(round(float(self.neutral_min_runtime_hours_offset) * 3600.0))
        neutral_cooldown_multiplier = max(float(self.neutral_cooldown_multiplier), 1.0)
        min_runtime_secs = min_runtime_base_secs
        cooldown_secs = cooldown_base_secs
        if neutral_mode_active:
            min_runtime_secs = max(min_runtime_base_secs + neutral_min_runtime_offset_secs, 0)
            cooldown_secs = int(round(cooldown_base_secs * neutral_cooldown_multiplier))

        running_prev = bool(self._running_by_pair.get(pair, False))
        active_since_ts = self._active_since_ts_by_pair.get(pair)
        runtime_secs = None
        if running_prev and active_since_ts is not None:
            runtime_secs = max(int(clock_ts) - int(active_since_ts), 0)

        reclaim_until_ts = int(self._reclaim_until_ts_by_pair.get(pair, 0) or 0)
        cooldown_until_ts = int(self._cooldown_until_ts_by_pair.get(pair, 0) or 0)
        fresh_ob_event = bool(
            bool(order_block_state.get("event_new_bull", False))
            or bool(order_block_state.get("event_new_bear", False))
        )
        if (
            fresh_ob_event
            and bool(order_block_state.get("fresh_block", False))
            and (not running_prev)
            and reclaim_secs > 0
        ):
            reclaim_until_ts = max(int(reclaim_until_ts), int(clock_ts) + int(reclaim_secs))
            self._reclaim_until_ts_by_pair[pair] = int(reclaim_until_ts)
        reclaim_active = bool(reclaim_until_ts and int(clock_ts) < reclaim_until_ts)
        cooldown_active = bool(cooldown_until_ts and int(clock_ts) < cooldown_until_ts)
        meta_drift_cooldown_extended = False
        meta_drift_cooldown_extend_secs = int(
            max(float(self.meta_drift_guard_cooldown_extend_minutes), 0.0) * 60.0
        )
        if (
            meta_drift_recommended_action == "COOLDOWN_EXTEND"
            and meta_drift_cooldown_extend_secs > 0
        ):
            target_cooldown_ts = int(clock_ts) + int(meta_drift_cooldown_extend_secs)
            if target_cooldown_ts > cooldown_until_ts:
                cooldown_until_ts = int(target_cooldown_ts)
                self._cooldown_until_ts_by_pair[pair] = int(cooldown_until_ts)
                meta_drift_cooldown_extended = True
            cooldown_active = bool(cooldown_until_ts and int(clock_ts) < cooldown_until_ts)

        max_stops_window_state = self._max_stops_window_state(pair, int(clock_ts))
        max_stops_window_blocked = bool(max_stops_window_state.get("blocked", False))
        micro_reentry_state = self._micro_reentry_state(
            pair=pair,
            clock_ts=int(clock_ts),
            close=float(close),
            micro_poc=micro_poc,
            step_price=float(step_price),
        )
        micro_reentry_blocked = bool(micro_reentry_state.get("block_reason"))

        stop_rule = bool(raw_stop_rule)
        min_runtime_blocked_stop = False
        if (
            stop_rule
            and running_prev
            and not hard_stop
            and runtime_secs is not None
            and runtime_secs < min_runtime_secs
        ):
            stop_rule = False
            min_runtime_blocked_stop = True

        if gate_start_min_pass_ratio_effective >= 0.999:
            start_gate_ok = bool(rule_range_ok)
        else:
            start_gate_ok = bool(core_gates_ok and gate_ratio_ok and phase2_gate_ok)
        if not planner_health_ok:
            start_gate_ok = False
        if not start_stability_ok:
            start_gate_ok = False
        if max_stops_window_blocked:
            start_gate_ok = False
        if micro_reentry_blocked:
            start_gate_ok = False
        box_block_active = bool(len(box_block_reasons) > 0)
        start_signal = bool(
            start_gate_ok
            and price_in_box
            and rsi_ok
            and start_box_position_ok
            and basis_cross_ok
            and mrvd_proximity_ok
            and bool(step_cost_block_reason is None)
            and bool(min_range_len_ok)
            and bool(breakout_confirm_gate_ok)
            and bool(capacity_hint_ok)
            and bool(volatility_strictness_ok)
            and (not box_block_active)
            and bool(poc_acceptance_satisfied)
            and bool(poc_alignment_ok)
        )
        start_blocked = bool(start_signal and (reclaim_active or cooldown_active))
        failed_core_gates = [name for name, ok in gate_checks if (name in core_gate_names) and (not ok)]
        failed_all_gates = [name for name, ok in gate_checks if not ok]
        start_block_reasons: List[str] = []
        breakout_block_active = bool(breakout_fresh_block_active)
        if breakout_block_active:
            start_block_reasons.append(str(BlockReason.BLOCK_FRESH_BREAKOUT))
        if bool(order_block_state.get("fresh_block", False)):
            start_block_reasons.append(str(BlockReason.BLOCK_FRESH_OB_COOLOFF))
        if not start_gate_ok:
            if gate_start_min_pass_ratio_effective >= 0.999:
                start_block_reasons.extend([f"gate_fail:{name}" for name in failed_all_gates])
            else:
                if not core_gates_ok:
                    start_block_reasons.extend([f"core_gate_fail:{name}" for name in failed_core_gates])
                if not gate_ratio_ok:
                    start_block_reasons.append("gate_ratio_below_required")
        if volatility_strictness_blocked:
            start_block_reasons.append(str(BlockReason.BLOCK_VOL_BUCKET_UNSTABLE))
        if not start_stability_ok:
            start_block_reasons.append(str(BlockReason.BLOCK_START_STABILITY_LOW))
        if step_cost_block_reason is not None:
            start_block_reasons.append(str(step_cost_block_reason))
        if min_range_len_block_reason is not None:
            start_block_reasons.append(str(min_range_len_block_reason))
        if breakout_confirm_block_reason is not None:
            start_block_reasons.append(str(breakout_confirm_block_reason))
        if not start_box_position_ok:
            start_block_reasons.append(str(BlockReason.BLOCK_START_BOX_POSITION))
        if not basis_cross_ok:
            start_block_reasons.append(str(BlockReason.BLOCK_BASIS_CROSS_PENDING))
        if not mrvd_proximity_ok:
            start_block_reasons.append(str(BlockReason.BLOCK_VAH_VAL_POC_PROXIMITY))
        if (not capacity_hint_ok) and (not capacity_hint_advisory_only):
            start_block_reasons.append(str(BlockReason.BLOCK_CAPACITY_THIN))
        if (not capacity_hint_allow) and capacity_hint_advisory_only:
            hint_reason = str(capacity_hint.get("reason") or "capacity_hint")
            start_block_reasons.append(f"capacity_hint_advisory:{hint_reason}")
        if not price_in_box:
            start_block_reasons.append("price_outside_box")
        if not rsi_ok:
            start_block_reasons.append(str(BlockReason.BLOCK_START_RSI_BAND))
        if mode_pause:
            start_block_reasons.append("router_pause_mode")
        if reclaim_active:
            start_block_reasons.append(str(BlockReason.BLOCK_RECLAIM_PENDING))
        if cooldown_active:
            start_block_reasons.append(str(BlockReason.BLOCK_COOLDOWN_ACTIVE))
        if max_stops_window_blocked:
            start_block_reasons.append(str(BlockReason.BLOCK_MAX_STOPS_WINDOW))
        if micro_reentry_blocked:
            start_block_reasons.append(str(BlockReason.BLOCK_RECLAIM_NOT_CONFIRMED))
        if mode_handoff_required_stop:
            start_block_reasons.append("mode_handoff_required_stop")
        if stop_rule:
            start_block_reasons.append("stop_rule_active")
        if raw_stop_rule and (not stop_rule):
            start_block_reasons.append("stop_rule_suppressed_by_min_runtime")
        if box_block_reasons:
            start_block_reasons.extend([str(x) for x in box_block_reasons])
        if self.poc_acceptance_enabled and not poc_acceptance_satisfied:
            start_block_reasons.append(str(BlockReason.BLOCK_NO_POC_ACCEPTANCE))
        if not poc_alignment_ok:
            start_block_reasons.append(str(BlockReason.BLOCK_POC_ALIGNMENT_FAIL))
        if phase2_gate_failures:
            start_block_reasons.extend([str(x) for x in phase2_gate_failures])
        if not planner_health_ok:
            start_block_reasons.append(f"planner_health:{planner_health_state}")
        if not data_quality_ok:
            start_block_reasons.extend([str(x) for x in data_quality_reasons])
        start_block_reasons = list(dict.fromkeys(start_block_reasons))
        warning_codes = [str(x) for x in (cost_floor.get("warning_codes") or [])]
        if active_fallback_used:
            warning_codes.append(str(WarningCode.WARN_VRVP_UNAVAILABLE_FALLBACK_POC))
        warning_codes = list(dict.fromkeys(warning_codes))

        # ---- Action (final) ----
        if stop_rule:
            action = "STOP"
        elif start_signal and not start_blocked:
            action = "START"
        else:
            action = "HOLD"

        if action == "STOP":
            reclaim_until_ts = int(clock_ts) + reclaim_secs
            cooldown_until_ts = int(clock_ts) + cooldown_secs
            self._register_stop_timestamp(pair, int(clock_ts))
            if (
                bool(self.micro_reentry_pause_bars > 0)
                and (
                    lvn_corridor_stop_override
                    or fvg_conflict_stop_override
                    or fvg_vp_stop_override
                    or session_break_retest_stop
                )
            ):
                pause_secs = int(max(int(self.micro_reentry_pause_bars), 0) * int(self.data_quality_expected_candle_seconds))
                if pause_secs > 0:
                    self._micro_reentry_pause_until_ts_by_pair[pair] = int(clock_ts) + pause_secs
            self._reclaim_until_ts_by_pair[pair] = reclaim_until_ts
            self._cooldown_until_ts_by_pair[pair] = cooldown_until_ts
            self._running_by_pair[pair] = False
            self._running_mode_by_pair.pop(pair, None)
            self._active_since_ts_by_pair.pop(pair, None)
            active_since_ts = None
            runtime_secs = None
            self._mode_at_exit_by_pair[pair] = str(active_mode)
        elif action == "START":
            if (not running_prev) or (active_since_ts is None):
                self._active_since_ts_by_pair[pair] = int(clock_ts)
                active_since_ts = int(clock_ts)
            self._micro_reentry_pause_until_ts_by_pair.pop(pair, None)
            self._running_by_pair[pair] = True
            self._running_mode_by_pair[pair] = self._normalize_mode_name(active_mode)
            runtime_secs = max(int(clock_ts) - int(active_since_ts), 0)
            self._mode_at_entry_by_pair[pair] = str(active_mode)
        else:
            # HOLD preserves previous running state.
            self._running_by_pair[pair] = running_prev
            if running_prev and active_since_ts is not None:
                runtime_secs = max(int(clock_ts) - int(active_since_ts), 0)
            else:
                self._running_mode_by_pair.pop(pair, None)
                active_since_ts = None
                runtime_secs = None

        max_stops_window_state = self._max_stops_window_state(pair, int(clock_ts))
        running_now = bool(self._running_by_pair.get(pair, False))
        reclaim_active_now = bool(reclaim_until_ts and int(clock_ts) < reclaim_until_ts)
        cooldown_active_now = bool(cooldown_until_ts and int(clock_ts) < cooldown_until_ts)
        stop_reason_flags_raw_active = [k for k, v in stop_reason_flags_raw.items() if bool(v)]
        stop_reason_flags_applied_active = (
            list(
                dict.fromkeys(
                    stop_reason_flags_raw_active
                    + [str(x) for x in stop_reason_enum_active]
                )
            )
            if bool(stop_rule)
            else []
        )
        materiality_info = self._evaluate_materiality(
            pair,
            mid,
            width_pct,
            step_price,
            tp_price_plan,
            sl_price,
            hard_stop,
            action,
        )
        start_filter_states = {
            "box_position_ok": bool(start_box_position_ok),
            "rsi_guard_ok": bool(rsi_ok),
            "poc_acceptance_ok": bool(poc_acceptance_satisfied),
            "poc_alignment_ok": bool(poc_alignment_ok),
            "mrvd_proximity_ok": bool(mrvd_proximity_ok),
            "basis_cross_ok": bool(basis_cross_ok),
            "start_stability_ok": bool(start_stability_ok),
            "meta_drift_ok": bool(not meta_drift_soft_block),
            "planner_health_ok": bool(planner_health_ok),
            "fresh_ob_ok": bool(not order_block_state.get("fresh_block", False)),
            "cooldown_ok": bool(not cooldown_active),
            "reclaim_ok": bool(not reclaim_active),
            "capacity_hint_ok": bool(capacity_hint_ok),
            "order_flow_hard_block_ok": bool(not order_flow_state.get("hard_block", False)),
            "drawdown_guard_ok": bool(not drawdown_guard_triggered),
            "max_stops_window_ok": bool(not max_stops_window_blocked),
            "micro_reentry_ok": bool(not micro_reentry_blocked),
            "cost_step_ok": bool(step_cost_block_reason is None),
            "min_range_len_ok": bool(min_range_len_ok),
            "breakout_confirm_gate_ok": bool(breakout_confirm_gate_ok),
            "width_avg_veto_ok": bool(not width_avg_state.get("veto", False)),
            "volatility_policy_ok": bool(volatility_strictness_ok),
        }

        structured_event_types: List[str] = []
        structured_event_metadata: Dict[str, Dict[str, object]] = {}

        def _append_structured_event(code: object, **meta: object) -> None:
            code_s = str(code or "").strip()
            if not code_s or not code_s.startswith("EVENT_"):
                return
            structured_event_types.append(code_s)
            if meta:
                structured_event_metadata[code_s] = {
                    k: _normalize_runtime_value(v)
                    for k, v in meta.items()
                    if v is not None
                }

        if breakout and str(breakout_direction) == "bull":
            _append_structured_event(EventType.EVENT_BREAKOUT_BULL, direction="bull")
        elif breakout and str(breakout_direction) == "bear":
            _append_structured_event(EventType.EVENT_BREAKOUT_BEAR, direction="bear")
        if bool(smart_channel_state.get("strong_break_up")):
            _append_structured_event(EventType.EVENT_CHANNEL_STRONG_BREAK_UP)
        if bool(smart_channel_state.get("strong_break_dn")):
            _append_structured_event(EventType.EVENT_CHANNEL_STRONG_BREAK_DN)
        if bool(smart_channel_state.get("donchian_break_up")):
            _append_structured_event(EventType.EVENT_DONCHIAN_STRONG_BREAK_UP)
        if bool(smart_channel_state.get("donchian_break_dn")):
            _append_structured_event(EventType.EVENT_DONCHIAN_STRONG_BREAK_DN)
        if bool(smart_channel_state.get("midline_touch")):
            _append_structured_event(EventType.EVENT_CHANNEL_MIDLINE_TOUCH, channel_midline=channel_midline)
        if bool(session_sweep_state.get("sweep_high")):
            _append_structured_event(EventType.EVENT_SESSION_HIGH_SWEEP, level=session_sweep_state.get("session_high_prev"))
            _append_structured_event(EventType.EVENT_SWEEP_WICK_HIGH, level=session_sweep_state.get("session_high_prev"))
        if bool(session_sweep_state.get("sweep_low")):
            _append_structured_event(EventType.EVENT_SESSION_LOW_SWEEP, level=session_sweep_state.get("session_low_prev"))
            _append_structured_event(EventType.EVENT_SWEEP_WICK_LOW, level=session_sweep_state.get("session_low_prev"))
        if bool(session_sweep_state.get("break_retest_high_recent", session_sweep_state.get("break_retest_high", False))):
            _append_structured_event(EventType.EVENT_SWEEP_BREAK_RETEST_HIGH)
        if bool(session_sweep_state.get("break_retest_low_recent", session_sweep_state.get("break_retest_low", False))):
            _append_structured_event(EventType.EVENT_SWEEP_BREAK_RETEST_LOW)
        if bool(order_block_state.get("event_new_bull", False)):
            _append_structured_event(EventType.EVENT_OB_NEW_BULL, level=(order_block_state.get("bull") or {}).get("mid"))
        if bool(order_block_state.get("event_new_bear", False)):
            _append_structured_event(EventType.EVENT_OB_NEW_BEAR, level=(order_block_state.get("bear") or {}).get("mid"))
        if bool(order_block_state.get("event_tagged_bull", False)):
            _append_structured_event(EventType.EVENT_OB_TAGGED_BULL, level=(order_block_state.get("bull") or {}).get("mid"))
        if bool(order_block_state.get("event_tagged_bear", False)):
            _append_structured_event(EventType.EVENT_OB_TAGGED_BEAR, level=(order_block_state.get("bear") or {}).get("mid"))
        if bool(fvg_vp_state.get("poc_tagged")):
            _append_structured_event(
                EventType.EVENT_FVG_POC_TAG,
                side=fvg_vp_state.get("tag_side"),
                poc=fvg_vp_state.get("nearest_poc"),
            )
        if bool(lvn_corridor_stop_override):
            _append_structured_event(EventType.EVENT_LVN_VOID_EXIT)
        if bool(cvd_state.get("bull_divergence_near_bottom", False)):
            _append_structured_event(EventType.EVENT_CVD_BULL_DIV)
        if bool(cvd_state.get("bear_divergence_near_top", False)):
            _append_structured_event(EventType.EVENT_CVD_BEAR_DIV)
        if bool(cvd_state.get("bos_up", False)):
            _append_structured_event(EventType.EVENT_CVD_BOS_UP)
        if bool(cvd_state.get("bos_down", False)):
            _append_structured_event(EventType.EVENT_CVD_BOS_DN)
        if bool(meta_drift_soft_block):
            _append_structured_event(EventType.EVENT_META_DRIFT_SOFT)
        if bool(meta_drift_hard_stop):
            _append_structured_event(EventType.EVENT_META_DRIFT_HARD)
        reason_set = {str(x) for x in (data_quality_reasons or [])}
        if str(BlockReason.BLOCK_DATA_GAP) in reason_set:
            _append_structured_event(EventType.EVENT_DATA_GAP_DETECTED)
        if str(BlockReason.BLOCK_DATA_MISALIGN) in reason_set:
            _append_structured_event(EventType.EVENT_DATA_MISALIGN_DETECTED)
        for code in order_flow_state.get("flags") or []:
            _append_structured_event(code)
        structured_event_types = list(dict.fromkeys(structured_event_types))

        plan = {
            "ts": ts,
            "exchange": ex_name,
            "symbol": pair,
            "action": action,
            "mode": str(active_mode),
            "warnings": warning_codes,
            "regime_router": {
                "enabled": bool(router_state.get("enabled", False)),
                "forced_mode": router_state.get("forced_mode"),
                "active_mode": str(active_mode),
                "desired_mode": router_state.get("desired_mode"),
                "desired_reason": router_state.get("desired_reason"),
                "target_mode": router_state.get("target_mode"),
                "target_reason": router_state.get("target_reason"),
                "candidate_mode": router_state.get("candidate_mode"),
                "candidate_count": int(router_state.get("candidate_count", 0) or 0),
                "switch_persist_bars": int(router_state.get("switch_persist_bars", 0) or 0),
                "switch_cooldown_bars": int(router_state.get("switch_cooldown_bars", 0) or 0),
                "switch_margin": float(router_state.get("switch_margin", 0.0) or 0.0),
                "switch_cooldown_active": bool(router_state.get("switch_cooldown_active", False)),
                "switch_cooldown_until_ts": router_state.get("switch_cooldown_until_ts"),
                "switch_cooldown_until_utc": self._ts_to_iso(
                    int(router_state["switch_cooldown_until_ts"])
                ) if router_state.get("switch_cooldown_until_ts") is not None else None,
                "switched": bool(router_state.get("switched", False)),
                "running_active": bool(router_state.get("running_active", False)),
                "running_mode": router_state.get("running_mode"),
                "handoff_blocked_running_inventory": bool(
                    router_state.get("handoff_blocked_running_inventory", False)
                ),
                "handoff_blocked_unsafe_inventory": bool(
                    router_state.get("handoff_blocked_unsafe_inventory", False)
                ),
                "inventory_safe_band": bool(router_state.get("inventory_safe_band", True)),
                "inventory_safe_band_half": float(router_state.get("inventory_safe_band_half", 0.0)),
                "scores": router_state.get("scores", {}),
            },

            # NEW: align sims/executor to the candle that produced this plan
            "candle_time_utc": candle_time_utc,
            "candle_ts": candle_ts,

            "timeframes": {"exec": "15m", "signal": "1h", "regime": "4h"},

            # NEW: reference price for initial ladder decisions
            "price_ref": {"close": float(close), "vwap_15m": vwap},

            "data_quality": {
                "ok": bool(data_quality_ok),
                "reasons": [str(x) for x in data_quality_reasons],
                "details": data_quality.get("details", {}),
            },

            "range": {
                "low": float(lo_p),
                "high": float(hi_p),
                "pad": float(pad),
                "lookback_bars_used": int(used_lb),
                "width_pct": float(width_pct),
                "quartiles": {"q1": float(q1), "q2": float(q2), "q3": float(q3)},
                "extensions": {
                    "x1386_lo": float(ext_lo),
                    "x1386_hi": float(ext_hi),
                    "space": str(quartile_space),
                    "factor": float(extension_factor),
                },
                "volume_profile": {
                    "lookback_bars": int(self.vrvp_lookback_bars),
                    "bins": int(self.vrvp_bins),
                    "value_area_pct": float(self.vrvp_value_area_pct),
                    "source": str(active_vrvp_source),
                    "fallback_used": bool(active_fallback_used),
                    "fallback_poc": float(active_fallback_poc) if active_fallback_poc is not None else None,
                    "poc": vrvp_poc,
                    "vah": vrvp_vah,
                    "val": vrvp_val,
                    "poc_inside_box": bool(vrvp_poc_inside_box),
                    "poc_dist_frac_after_shift": vrvp_dist_frac,
                    "box_shift_applied": float(vrvp_box_shift),
                    "box_ok": bool(vrvp_box_ok),
                    "neutral_rebuild": {
                        "active": bool(neutral_mode_active),
                        "skipped": bool(box_rebuild_skipped),
                        "wait_bars": int(box_rebuild_wait_bars),
                        "shift_frac": float(box_rebuild_shift_frac) if box_rebuild_shift_frac is not None else None,
                    },
                },
                "validation": {
                    "blockers": [str(x) for x in box_block_reasons],
                    "width_avg_veto": dict(width_avg_state),
                    "poc_acceptance": {
                        "required": bool(self.poc_acceptance_enabled),
                        "satisfied": bool(poc_acceptance_satisfied),
                        "lookback_bars": int(self.poc_acceptance_lookback_bars),
                    },
                    "poc_alignment": dict(poc_alignment),
                    "min_range_len": {
                        "required_bars": int(min_range_len_required),
                        "range_len_bars_current": int(range_len_bars_current),
                        "ok": bool(min_range_len_ok),
                        "box_gen_id": str(box_gen_id),
                    },
                    "breakout_confirm": {
                        "enabled": bool(breakout_confirm_state.get("enabled", False)),
                        "confirm_bars": int(breakout_confirm_state.get("confirm_bars", 0)),
                        "buffer": float(breakout_confirm_state.get("buffer", 0.0)),
                        "up_threshold": float(breakout_confirm_state.get("up_threshold", hi_p)),
                        "dn_threshold": float(breakout_confirm_state.get("dn_threshold", lo_p)),
                        "confirmed_up": bool(breakout_confirmed_up),
                        "confirmed_dn": bool(breakout_confirmed_dn),
                        "gate_ok": bool(breakout_confirm_gate_ok),
                        "block_reason": breakout_confirm_reason_state.get("block_reason"),
                        "stop_reason": breakout_confirm_reason_state.get("stop_reason"),
                    },
                    "midline_bias_fallback": dict(midline_bias),
                    "zigzag_contraction": dict(zigzag_contraction_state),
                },
                "micro_vap": {
                    "enabled": bool(self.micro_vap_enabled),
                    "lookback_bars": int(self.micro_vap_lookback_bars),
                    "bins": int(self.micro_vap_bins),
                    "poc": micro_poc,
                    "hvn_levels": [float(x) for x in micro_hvn_levels],
                    "lvn_levels": [float(x) for x in micro_lvn_levels],
                    "top_void": float(micro_top_void),
                    "bottom_void": float(micro_bottom_void),
                    "void_slope": float(micro_void_slope),
                    "poc_vrvp_dist_steps": micro_poc_vrvp_steps,
                    "buy_ratio_bias": dict(buy_ratio_state),
                },
                "fvg": {
                    "enabled": bool(self.fvg_enabled),
                    "lookback_bars": int(self.fvg_lookback_bars),
                    "straddle_veto_steps": float(self.fvg_straddle_veto_steps),
                    "count_total": int(fvg_state.get("count_total", 0)),
                    "count_bull": int(fvg_state.get("count_bull", 0)),
                    "count_bear": int(fvg_state.get("count_bear", 0)),
                    "count_defensive_bull": int(fvg_state.get("count_defensive_bull", 0)),
                    "count_defensive_bear": int(fvg_state.get("count_defensive_bear", 0)),
                    "count_session": int(fvg_state.get("count_session", 0)),
                    "nearest_bullish": fvg_state.get("nearest_bullish"),
                    "nearest_bearish": fvg_state.get("nearest_bearish"),
                    "nearest_defensive_bullish": fvg_state.get("nearest_defensive_bullish"),
                    "nearest_defensive_bearish": fvg_state.get("nearest_defensive_bearish"),
                    "straddle_veto": bool(fvg_state.get("straddle_veto", False)),
                    "defensive_conflict": bool(fvg_state.get("defensive_conflict", False)),
                    "fresh_defensive_pause": bool(fvg_state.get("fresh_defensive_pause", False)),
                "session_new_print": bool(fvg_state.get("session_new_print", False)),
                "session_pause_active": bool(fvg_state.get("session_pause_active", False)),
                "session_inside_block": bool(fvg_state.get("session_inside_block", False)),
                "session_gate_ok": bool(fvg_state.get("session_gate_ok", True)),
                "session_high": session_high,
                "session_low": session_low,
                "session_vwap": session_vwap,
                "daily_vwap": daily_vwap,
                "gate_ok": bool(fvg_state.get("gate_ok", True)),
                    "imfvg_avg_bull": self._safe_float(fvg_state.get("imfvg_avg_bull")),
                    "imfvg_avg_bear": self._safe_float(fvg_state.get("imfvg_avg_bear")),
                    "session_fvg_avg": self._safe_float(fvg_state.get("session_fvg_avg")),
                    "positioning_up_avg": self._safe_float(fvg_state.get("positioning_up_avg")),
                    "positioning_down_avg": self._safe_float(fvg_state.get("positioning_down_avg")),
                    "fvg_vp": dict(fvg_vp_state),
                },
                "multi_range_volume": {
                    "enabled": bool(self.mrvd_enabled),
                    "bins": int(self.mrvd_bins),
                    "value_area_pct": float(self.mrvd_value_area_pct),
                    "required_overlap_count": int(self.mrvd_required_overlap_count),
                    "va_overlap_min_frac": float(self.mrvd_va_overlap_min_frac),
                    "near_poc_steps": float(self.mrvd_near_poc_steps),
                    "overlap_count": int(mrvd_overlap_count),
                    "overlap_ok": bool(mrvd_overlap_ok),
                    "near_any_poc": bool(mrvd_near_any_poc),
                    "pause_entries": bool(mrvd_pause_entries),
                    "drift_guard_triggered": bool(mrvd_drift_guard_triggered),
                    "drift_delta_steps": mrvd_drift_delta_steps,
                    "drift_anchor_prev": mrvd_drift_anchor_prev,
                    "drift_anchor_cur": mrvd_drift_anchor_cur,
                    "day_poc_step_move": mrvd_day_poc_step_move,
                    "day": mrvd_day_state,
                    "week": mrvd_week_state,
                    "month": mrvd_month_state,
                },
                "cvd": {
                    "enabled": bool(self.cvd_enabled),
                    "lookback_bars": int(self.cvd_lookback_bars),
                    "state": cvd_state,
                },
                "ml_overlay": {
                    "enabled": bool(self.freqai_overlay_enabled),
                    "gate_mode": str(ml_gate_mode),
                    "gate_hard_blocking": bool(ml_gate_hard),
                    "strict_predict": bool(self.freqai_overlay_strict_predict),
                    "source": ml_source,
                    "do_predict": ml_do_predict,
                    "p_range": p_range,
                    "p_breakout": p_breakout,
                    "ml_confidence": ml_confidence,
                    "gate_raw_ok": bool(ml_gate_ok),
                    "gate_ok": bool(ml_gate_effective_ok),
                    "breakout_risk_high": bool(ml_breakout_risk_high),
                    "quick_tp_candidate": ml_quick_tp_candidate,
                    "applied_adjustments": list(ml_applied_adjustments),
                },
            },
            "materiality": {
                "class": str(materiality_info.get("class", MaterialityClass.NOOP)),
                "publish": bool(materiality_info.get("publish", False)),
                "reasons": [str(x) for x in materiality_info.get("reasons", [])],
                "epoch_counter": int(materiality_info.get("epoch_counter", 0)),
                "delta_mid_steps": float(materiality_info.get("delta_mid_steps", 0.0)),
                "delta_width_pct": float(materiality_info.get("delta_width_pct", 0.0)),
                "delta_tp_steps": float(materiality_info.get("delta_tp_steps", 0.0)),
                "delta_sl_steps": float(materiality_info.get("delta_sl_steps", 0.0)),
            },
            "grid": {
                "n_levels": int(n_levels),
                "target_net_step_pct": float(cost_floor.get("target_net_step_pct", self.target_net_step_pct)),
                "est_fee_pct": float(self.est_fee_pct),
                "est_spread_pct": float(self.est_spread_pct),
                "gross_step_min_pct": float(static_gross_min),
                "majors_gross_step_floor_pct": float(self.majors_gross_step_floor_pct),
                "min_step_pct_required": float(min_step_pct_required),
                "step_pct_actual": float(step_pct_actual),
                "step_price": float(step_price),
                "step_cost_ok": bool(step_cost_block_reason is None),
                "step_cost_block_reason": str(step_cost_block_reason) if step_cost_block_reason is not None else None,
                "cost_model_source": str(cost_floor.get("source", "static")),
                "cost_model_selection_reason": str(cost_floor.get("selection_reason", "unknown")),
                "cost_floor": {
                    "source": str(cost_floor.get("source", "static")),
                    "selection_reason": str(cost_floor.get("selection_reason", "unknown")),
                    "static_floor_pct": float(static_gross_min),
                    "chosen_floor_base_pct": float(min_step_pct_required_base),
                    "chosen_floor_pct": float(min_step_pct_required),
                    "min_step_buffer_bps": float(min_step_buffer_bps_effective),
                    "empirical": cost_floor.get("empirical_snapshot", {}),
                    "empirical_sample": cost_floor.get("empirical_sample", {}),
                },
                "n_selection": {
                    "candidate_n": int(sizing.get("candidate_n", n_levels)),
                    "clamped_n": int(sizing.get("clamped_n", n_levels)),
                    "bounds": {"min": int(n_low), "max": int(n_high)},
                    "volatility_adapter": dict(n_bounds_diag),
                    "cost_validation": {
                        "min_step_pct_required": float(min_step_pct_required),
                        "step_pct_actual": float(step_pct_actual),
                        "ok": bool(step_cost_block_reason is None),
                        "attempts": list(sizing.get("attempts", [])),
                    },
                },
                "tick_size": float(self._infer_tick_size(step_price)),
                "post_only": True,
                "fill_detection": {
                    "fill_confirmation_mode": str(self.fill_confirmation_mode),
                    "no_repeat_lsi_guard": bool(self.fill_no_repeat_lsi_guard),
                    "cooldown_bars": int(self.fill_no_repeat_cooldown_bars),
                },
                "rung_density_bias": {
                    "enabled": bool(self.micro_vap_enabled),
                    "source": "micro_vap_hvn_lvn_cvd_buy_ratio_order_flow",
                    "hvn_boost": float(self.rung_weight_hvn_boost),
                    "lvn_penalty": float(self.rung_weight_lvn_penalty),
                    "weight_min": float(self.rung_weight_min),
                    "weight_max": float(self.rung_weight_max),
                    "buy_ratio_bias": dict(buy_ratio_state),
                    "order_flow_confidence_modifier": float(order_flow_state.get("confidence_modifier", 1.0) or 1.0),
                    "weights_by_level_index": [float(x) for x in rung_weights],
                },
            },
            "exit": {
                "enabled": True,
                "tp_price": float(tp_price_plan),
                "tp_price_base": float(tp_price),
                "sl_price": float(sl_price),
                "tp_step_multiple": float(self.tp_step_multiple),
                "sl_step_multiple": float(self.sl_step_multiple),
                "source": "nearest_conservative",
                "tp_candidates": tp_candidates,
                "midline_bias": dict(midline_bias),
                "tp_nudges": {
                    "squeeze": bool(squeeze_tp_nudged),
                    "hvp_quiet_exit": bool(hvp_quiet_exit_tp_nudged),
                    "smart_channel": bool(smart_channel_tp_nudged),
                    "session_sweep": bool(session_sweep_tp_nudged),
                    "buy_ratio_bearish": bool(buy_ratio_tp_nudged),
                },
                "sl_selection": sl_selection,
            },
            "signals": {
                "mode": str(active_mode),
                "neutral_mode_active": bool(neutral_mode_active),
                "mode_pause": bool(mode_pause),
                "mode_desired": str(desired_mode),
                "planner_health_state": str(planner_health_state),
                "planner_health_ok": bool(planner_health_ok),
                "adx_4h": adx4h,
                "adx_enter_max_4h": float(gate_adx_4h_max),
                "adx_exit_min_4h": float(gate_adx_4h_exit_min),
                "adx_exit_max_4h": float(gate_adx_4h_exit_max),
                "adx_rising_bars_4h": int(adx_rising_count),
                "adx_rising_required_4h": int(gate_adx_rising_bars),
                "adx_rising_confirmed_4h": bool(adx_rising_confirmed),
                "adx_exit_overheat": bool(adx_exit_overheat),
                "plus_di_4h": plus_di_4h,
                "minus_di_4h": minus_di_4h,
                "adx_di_up": bool(adx_di_up),
                "adx_di_down": bool(adx_di_down),
                "adx_di_down_risk_stop": bool(adx_di_down_risk_stop),
                "bb_width_15m": bbw15m,
                "bb_width_1h": bbw1h,
                "bb_width_4h": bbw4h,
                "bb_width_1h_pct": bbw1h_pct,
                "bb_width_percentile_ok_1h": bool(bbw_percentile_ok),
                "bb_width_trend_nonexpanding_1h": bool(bbw_trend_nonexp_ok),
                "bb_width_nonexpanding_1h": bool(bbw_nonexp),
                "bb_width_nonexp_lookback_bars_1h": int(gate_bbw_nonexp_lookback_bars),
                "bb_width_nonexp_tolerance_frac_1h": float(gate_bbw_nonexp_tolerance_frac),
                "bbwp_15m_pct": bbwp_s,
                "bbwp_1h_pct": bbwp_m,
                "bbwp_4h_pct": bbwp_l,
                "bbwp_allow": bool(bbwp_allow),
                "bbwp_veto": bool(bbwp_veto),
                "bbwp_cooloff": bool(bbwp_cooloff),
                "bbwp_nonexp_bars": int(self.bbwp_nonexp_bars),
                "bbwp_nonexp_ok": bool(bbwp_nonexp_ok),
                "bbwp_s_enter_low": float(gate_bbwp_s_enter_low),
                "bbwp_s_enter_high": float(gate_bbwp_s_enter_high),
                "bbwp_m_enter_low": float(gate_bbwp_m_enter_low),
                "bbwp_m_enter_high": float(gate_bbwp_m_enter_high),
                "bbwp_l_enter_low": float(gate_bbwp_l_enter_low),
                "bbwp_l_enter_high": float(gate_bbwp_l_enter_high),
                "bbwp_stop_high": float(gate_bbwp_stop_high),
                "bbwp_expansion_stop": bool(bbwp_expansion_stop),
                "bbwp_gate_ok": bool(bbwp_gate_ok),
                "band_slope_veto_enabled": bool(self.band_slope_veto_enabled),
                "band_slope_pct": float(band_slope_pct) if band_slope_pct is not None else None,
                "band_slope_gate_ok": bool(band_slope_gate_ok),
                "excursion_asymmetry_ratio": float(excursion_asymmetry_ratio) if excursion_asymmetry_ratio is not None else None,
                "excursion_asymmetry_gate_ok": bool(excursion_asymmetry_gate_ok),
                "ema50_1h": ema50,
                "ema100_1h": ema100,
                "ema_dist_frac_1h": ema_dist_frac,
                "atr_1h": atr_1h,
                "atr_4h": atr_4h,
                "atr_1h_pct": atr_1h_pct,
                "atr_4h_pct": atr_4h_pct,
                "atr_mode_source": str(gate_atr_source),
                "atr_mode_pct": atr_mode_pct,
                "atr_mode_max": float(gate_atr_pct_max),
                "atr_ok": bool(atr_ok),
                "vol_bucket": str(vol_bucket),
                "volatility_adapter_enabled": bool(self.n_volatility_adapter_enabled),
                "volatility_n_min": int(n_low),
                "volatility_n_max": int(n_high),
                "volatility_box_width_min_pct": float(box_width_min_effective),
                "volatility_box_width_max_pct": float(box_width_max_effective),
                "volatility_min_step_buffer_bps": float(min_step_buffer_bps_effective),
                "volatility_cooldown_minutes": float(cooldown_minutes_effective),
                "volatility_min_runtime_minutes": float(min_runtime_minutes_effective),
                "volatility_strictness_ok": bool(volatility_strictness_ok),
                "vol_ratio_1h": vol_ratio,
                "vol_ratio_ok_1h": bool(vol_1h_ok),
                "rvol_15m": rvol_15m,
                "rvol_15m_ok": bool(rvol_15m_ok),
                "rvol_15m_max": float(gate_rvol_15m_max),
                "inside_7d": bool(inside_7d),
                "inside_7d_gate_ok": bool(inside_7d_gate_ok),
                "context_7d_hard_veto": bool(gate_context_7d_hard_veto),
                "box_position": float(box_position),
                "start_box_position_ok": bool(start_box_position_ok),
                "box_diagnostics": dict(box_diag) if box_diag else None,
                "basis_raw_15m": basis_raw_now,
                "basis_prev_15m": basis_raw_prev,
                "basis_mid_15m": basis_mid,
                "basis_upper_15m": basis_upper,
                "basis_lower_15m": basis_lower,
                "basis_cross_confirm": bool(basis_cross_confirm),
                "basis_cross_ok": bool(basis_cross_ok),
                "poc_alignment_enabled": bool(poc_alignment.get("enabled", False)),
                "poc_alignment_strict": bool(poc_alignment.get("strict", False)),
                "poc_alignment_ok": bool(poc_alignment_ok),
                "poc_alignment_misaligned": bool(poc_alignment.get("misaligned", False)),
                "poc_alignment_diff": self._safe_float(poc_alignment.get("diff")),
                "poc_alignment_threshold": self._safe_float(poc_alignment.get("threshold")),
                "vrvp_source": str(active_vrvp_source),
                "vrvp_fallback_used": bool(active_fallback_used),
                "width_avg_veto_enabled": bool(width_avg_state.get("enabled", False)),
                "width_avg_veto": bool(width_avg_state.get("veto", False)),
                "width_avg_ratio": self._safe_float(width_avg_state.get("ratio_to_rolling_avg")),
                "midline_bias_enabled": bool(midline_bias.get("enabled", False)),
                "midline_bias_active": bool(midline_bias.get("active", False)),
                "midline_bias_poc_neutral": bool(midline_bias.get("poc_neutral", False)),
                "midline_bias_source": midline_bias.get("source"),
                "midline_bias_anchor": self._safe_float(midline_bias.get("anchor")),
                "midline_bias_direction": midline_bias.get("direction"),
                "midline_bias_tp_candidate": self._safe_float(midline_bias.get("tp_candidate")),
                "squeeze_on_1h": bool(squeeze_on_1h) if squeeze_on_1h is not None else None,
                "squeeze_released_1h": bool(squeeze_released_1h),
                "squeeze_val_1h": squeeze_val_1h,
                "squeeze_val_prev_1h": squeeze_val_prev_1h,
                "squeeze_gate_ok": bool(squeeze_gate_ok),
                "squeeze_require_on_1h": bool(self.squeeze_require_on_1h),
                "squeeze_release_against_bias": bool(squeeze_release_against_bias),
                "squeeze_momentum_flip_against_edge": bool(squeeze_momentum_flip_against_edge),
                "squeeze_momentum_decelerating": bool(squeeze_momentum_decelerating),
                "squeeze_tp_nudged": bool(squeeze_tp_nudged),
                "smart_channel_tp_nudged": bool(smart_channel_tp_nudged),
                "session_sweep_tp_nudged": bool(session_sweep_tp_nudged),
                "buy_ratio_tp_nudged": bool(buy_ratio_tp_nudged),
                "vrvp_box_ok": bool(vrvp_box_ok),
                "micro_vap_ok": bool(micro_vap_ok),
                "fvg_gate_ok": bool(fvg_gate_ok),
                "fvg_straddle_veto": bool(fvg_straddle_veto),
                "fvg_defensive_conflict": bool(fvg_defensive_conflict),
                "fvg_fresh_pause": bool(fvg_fresh_pause),
                "session_fvg_pause_active": bool(session_fvg_pause_active),
                "session_fvg_inside_block": bool(session_fvg_inside_block),
                "mrvd_gate_ok": bool(mrvd_gate_ok),
                "mrvd_overlap_count": int(mrvd_overlap_count),
                "mrvd_overlap_ok": bool(mrvd_overlap_ok),
                "mrvd_near_any_poc": bool(mrvd_near_any_poc),
                "mrvd_proximity_ok": bool(mrvd_proximity_ok),
                "mrvd_pause_entries": bool(mrvd_pause_entries),
                "mrvd_drift_guard_triggered": bool(mrvd_drift_guard_triggered),
                "mrvd_drift_delta_steps": mrvd_drift_delta_steps,
                "mrvd_day_poc": mrvd_day_poc,
                "mrvd_week_poc": mrvd_week_poc,
                "mrvd_month_poc": mrvd_month_poc,
                "cvd": self._safe_float(cvd_state.get("cvd")),
                "cvd_delta": self._safe_float(cvd_state.get("cvd_delta")),
                "cvd_near_bottom": bool(cvd_state.get("near_bottom", False)),
                "cvd_near_top": bool(cvd_state.get("near_top", False)),
                "cvd_bull_divergence": bool(cvd_state.get("bull_divergence", False)),
                "cvd_bear_divergence": bool(cvd_state.get("bear_divergence", False)),
                "cvd_bull_divergence_near_bottom": bool(cvd_state.get("bull_divergence_near_bottom", False)),
                "cvd_bear_divergence_near_top": bool(cvd_state.get("bear_divergence_near_top", False)),
                "cvd_bos_up": bool(cvd_state.get("bos_up", False)),
                "cvd_bos_down": bool(cvd_state.get("bos_down", False)),
                "cvd_bos_up_near_bottom": bool(cvd_state.get("bos_up_near_bottom", False)),
                "cvd_bos_down_near_top": bool(cvd_state.get("bos_down_near_top", False)),
                "cvd_bos_against_range": bool(cvd_bos_against_range),
                "cvd_quick_tp_trigger": bool(cvd_quick_tp_trigger),
                "cvd_quick_tp_candidate": cvd_quick_tp_candidate,
                "cvd_freeze_bars_left": int(cvd_freeze_left),
                "cvd_freeze_active": bool(cvd_freeze_active),
                "cvd_gate_ok": bool(cvd_gate_ok),
                "drift_slope_gate_ok": bool(drift_slope_gate_ok),
                "breakout_detected": bool(breakout),
                "breakout_direction": str(breakout_direction) if breakout_direction is not None else None,
                "breakout_last_up_level": breakout_up_level,
                "breakout_last_dn_level": breakout_dn_level,
                "breakout_bars_since": int(breakout_bars_since) if breakout_bars_since is not None else None,
                "breakout_fresh_block_active": bool(breakout_fresh_block_active),
                "breakout_confirm_bars": int(breakout_confirm_state.get("confirm_bars", 0)),
                "breakout_confirm_buffer": float(breakout_confirm_state.get("buffer", 0.0)),
                "breakout_confirmed_up": bool(breakout_confirmed_up),
                "breakout_confirmed_dn": bool(breakout_confirmed_dn),
                "breakout_confirm_gate_ok": bool(breakout_confirm_gate_ok),
                "breakout_confirm_block_reason": breakout_confirm_reason_state.get("block_reason"),
                "breakout_confirm_stop_reason": breakout_confirm_reason_state.get("stop_reason"),
                "min_range_len_bars": int(min_range_len_required),
                "range_len_bars_current": int(range_len_bars_current),
                "min_range_len_ok": bool(min_range_len_ok),
                "box_gen_id": str(box_gen_id),
                "ml_overlay_enabled": bool(self.freqai_overlay_enabled),
                "ml_overlay_source": ml_source,
                "ml_do_predict": ml_do_predict,
                "ml_gate_mode": str(ml_gate_mode),
                "ml_gate_raw_ok": bool(ml_gate_ok),
                "ml_gate_ok": bool(ml_gate_effective_ok),
                "ml_breakout_risk_high": bool(ml_breakout_risk_high),
                "ml_quick_tp_candidate": ml_quick_tp_candidate,
                "ml_applied_adjustments": list(ml_applied_adjustments),
                "micro_poc": micro_poc,
                "micro_hvn_levels": [float(x) for x in micro_hvn_levels],
                "micro_lvn_levels": [float(x) for x in micro_lvn_levels],
                "micro_void_slope": float(micro_void_slope),
                "micro_poc_vrvp_dist_steps": micro_poc_vrvp_steps,
                "buy_ratio_bias": dict(buy_ratio_state),
                "fvg_vp_state": dict(fvg_vp_state),
                "smart_channel": dict(smart_channel_state),
                "order_blocks": dict(order_block_state),
                "session_sweep": dict(session_sweep_state),
                "order_flow": dict(order_flow_state),
                "drawdown_guard": dict(drawdown_state),
                "max_stops_window": dict(max_stops_window_state),
                "micro_reentry": dict(micro_reentry_state),
                "zigzag_contraction": dict(zigzag_contraction_state),
                "os_dev_raw": int(os_dev_raw),
                "os_dev_norm": os_dev_norm,
                "os_dev_state": int(os_dev_state),
                "os_dev_candidate_count": int(os_dev_candidate_count),
                "os_dev_zero_persist_bars": int(os_dev_zero_persist),
                "os_dev_rvol_ok": bool(os_dev_rvol_ok),
                "os_dev_build_ok": bool(os_dev_build_ok),
                "funding_filter_enabled": bool(self.funding_filter_enabled),
                "fr_8h_pct": float(fr_8h_pct) if fr_8h_pct is not None else None,
                "funding_bias": int(funding_bias),
                "funding_gate_ok": bool(funding_gate_ok),
                "hvp_enabled": bool(self.hvp_enabled),
                "hvp_current": float(hvp_current) if hvp_current is not None else None,
                "hvp_sma": float(hvp_sma) if hvp_sma is not None else None,
                "hvp_gate_ok": bool(hvp_gate_ok),
                "hvp_quiet_exit_bias": bool(hvp_quiet_exit_bias),
                "hvp_quiet_exit_tp_nudged": bool(hvp_quiet_exit_tp_nudged),
                "cost_model_source": str(cost_floor.get("source", "static")),
                "cost_model_selection_reason": str(cost_floor.get("selection_reason", "unknown")),
                "min_step_pct_required": float(min_step_pct_required),
                "step_pct_actual": float(step_pct_actual),
                "step_cost_ok": bool(step_cost_block_reason is None),
                "step_cost_block_reason": str(step_cost_block_reason) if step_cost_block_reason is not None else None,
                "n_candidate": int(sizing.get("candidate_n", n_levels)),
                "n_clamped": int(sizing.get("clamped_n", n_levels)),
                "n_final": int(n_levels),
                "capacity_hint_available": bool(capacity_hint.get("available", False)),
                "capacity_hint_allow_start": bool(capacity_hint_allow),
                "capacity_hint_advisory_only": bool(capacity_hint_advisory_only),
                "capacity_hint_ok": bool(capacity_hint_ok),
                "capacity_hint_reason": capacity_hint.get("reason"),
                "preferred_rung_cap_hint": capacity_hint.get("preferred_rung_cap"),
                "max_concurrent_rebuilds_hint": capacity_hint.get("max_concurrent_rebuilds"),
                "gate_profile": gate_profile,
                "regime_threshold_profile": str(self._active_threshold_profile()),
                "gate_pass_count": int(gate_pass_count),
                "gate_total_count": int(gate_total_count),
                "gate_pass_ratio": float(gate_pass_ratio),
                "gate_required_ratio": float(gate_start_min_pass_ratio_effective),
                "gate_required_ratio_base": float(gate_start_min_pass_ratio),
                "volatility_policy_gate_ratio_delta": float(volatility_gate_ratio_delta),
                "gate_ratio_ok": bool(gate_ratio_ok),
                "vol_bucket": str(vol_bucket),
                "volatility_policy": dict(volatility_policy),
                "volatility_strictness_ok": bool(volatility_strictness_ok),
                "start_stability_score": float(start_stability.get("score", 0.0)),
                "start_stability_passed": int(start_stability.get("passed", 0)),
                "start_stability_total": int(start_stability.get("total", 0)),
                "start_stability_k_required": int(start_stability.get("k_required", 0)),
                "start_stability_min_score": float(start_stability.get("min_score", 0.0)),
                "start_stability_ok": bool(start_stability_ok),
                "core_gates_ok": bool(core_gates_ok),
                "meta_drift_soft_block": bool(meta_drift_soft_block),
                "meta_drift_soft_block_mrvd": bool(meta_drift_soft_block_mrvd),
                "meta_drift_detected": bool(meta_drift_state.get("drift_detected", False)),
                "meta_drift_severity": str(meta_drift_state.get("severity", "none")),
                "meta_drift_recommended_action": str(meta_drift_recommended_action),
                "meta_drift_channels": [str(x) for x in meta_drift_state.get("drift_channels", [])],
                "meta_drift_soft_channels": [str(x) for x in meta_drift_state.get("soft_channels", [])],
                "meta_drift_hard_channels": [str(x) for x in meta_drift_state.get("hard_channels", [])],
                "meta_drift_hard_stop": bool(meta_drift_hard_stop),
                "meta_drift_cooldown_extended": bool(meta_drift_cooldown_extended),
                "rsi_15m": rsi,
                "vwap_15m": vwap,
                "rule_range_ok": bool(rule_range_ok),
                "rule_range_fail_reasons": rule_range_fail_reasons,
                "mode_handoff_required_stop": bool(mode_handoff_required_stop),
                "router_pause_stop": bool(router_pause_stop),
                "start_filters": dict(start_filter_states),
                "p_range": p_range,
                "p_breakout": p_breakout,
                "ml_confidence": ml_confidence,
                "instrumentation": instrumentation_features,
            },
            "risk": {
                "stop_confirm_bars": int(self.stop_confirm_bars),
                "fast_stop_step_multiple": float(self.fast_stop_step_multiple),
                "range_shift_stop_pct": float(self.range_shift_stop_pct),
                "tp_price": float(tp_price_plan),
                "tp_price_base": float(tp_price),
                "sl_price": float(sl_price),
                "stop_rule_triggered": bool(stop_rule),
                "stop_rule_triggered_raw": bool(raw_stop_rule),
                "min_runtime_blocked_stop": bool(min_runtime_blocked_stop),
                "stop_reasons": {
                    "two_consecutive_outside_up": bool(stop_reason_flags_raw["two_consecutive_outside_up"]),
                    "two_consecutive_outside_dn": bool(stop_reason_flags_raw["two_consecutive_outside_dn"]),
                    str(StopReason.STOP_BREAKOUT_CONFIRM_UP): bool(
                        stop_reason_flags_raw[str(StopReason.STOP_BREAKOUT_CONFIRM_UP)]
                    ),
                    str(StopReason.STOP_BREAKOUT_CONFIRM_DN): bool(
                        stop_reason_flags_raw[str(StopReason.STOP_BREAKOUT_CONFIRM_DN)]
                    ),
                    "fast_outside_up": bool(stop_reason_flags_raw["fast_outside_up"]),
                    "fast_outside_dn": bool(stop_reason_flags_raw["fast_outside_dn"]),
                    "adx_hysteresis_stop": bool(stop_reason_flags_raw["adx_hysteresis_stop"]),
                    "adx_di_down_risk_stop": bool(stop_reason_flags_raw["adx_di_down_risk_stop"]),
                    "bbwp_expansion_stop": bool(stop_reason_flags_raw["bbwp_expansion_stop"]),
                    "squeeze_release_break_stop": bool(stop_reason_flags_raw["squeeze_release_break_stop"]),
                    "squeeze_release_against_bias": bool(squeeze_release_against_bias),
                    "os_dev_trend_stop": bool(stop_reason_flags_raw["os_dev_trend_stop"]),
                    "lvn_corridor_stop_override": bool(stop_reason_flags_raw["lvn_corridor_stop_override"]),
                    "lvn_corridor_stop_up": bool(stop_reason_flags_raw["lvn_corridor_stop_up"]),
                    "lvn_corridor_stop_dn": bool(stop_reason_flags_raw["lvn_corridor_stop_dn"]),
                    "lvn_corridor_width": float(lvn_corridor_width),
                    "fvg_conflict_stop_override": bool(stop_reason_flags_raw["fvg_conflict_stop_override"]),
                    "fvg_conflict_stop_up": bool(stop_reason_flags_raw["fvg_conflict_stop_up"]),
                    "fvg_conflict_stop_dn": bool(stop_reason_flags_raw["fvg_conflict_stop_dn"]),
                    "fvg_vp_stop_override": bool(stop_reason_flags_raw["fvg_vp_stop_override"]),
                    "smart_channel_stop": bool(stop_reason_flags_raw["smart_channel_stop"]),
                    "session_break_retest_stop": bool(stop_reason_flags_raw["session_break_retest_stop"]),
                    "drawdown_guard_triggered": bool(stop_reason_flags_raw["drawdown_guard_triggered"]),
                    "neutral_adx_overheat_stop": bool(stop_reason_flags_raw["neutral_adx_overheat_stop"]),
                    "neutral_bbwp_expansion_stop": bool(stop_reason_flags_raw["neutral_bbwp_expansion_stop"]),
                    "neutral_box_break_stop": bool(stop_reason_flags_raw["neutral_box_break_stop"]),
                    "mode_handoff_required_stop": bool(stop_reason_flags_raw["mode_handoff_required_stop"]),
                    "router_pause_stop": bool(stop_reason_flags_raw["router_pause_stop"]),
                    "meta_drift_hard_stop": bool(stop_reason_flags_raw["meta_drift_hard_stop"]),
                    "fresh_breakout_idle_reclaim_stop": bool(
                        stop_reason_flags_raw["fresh_breakout_idle_reclaim_stop"]
                    ),
                    "upper_edge_lvn": bool(upper_edge_lvn),
                    "lower_edge_lvn": bool(lower_edge_lvn),
                    "close_outside_up": bool(flags["close_outside_up"]),
                    "close_outside_dn": bool(flags["close_outside_dn"]),
                    "range_shift_stop": bool(stop_reason_flags_raw["range_shift_stop"]),
                    "range_shift_frac": shift_frac,
                    "neutral_box_break_bars": int(box_break_bars),
                    "breakout_confirm_bars": int(breakout_confirm_state.get("confirm_bars", 0)),
                    "breakout_confirm_buffer": float(breakout_confirm_state.get("buffer", 0.0)),
                    "breakout_confirm_up_threshold": float(
                        breakout_confirm_state.get("up_threshold", hi_p)
                    ),
                    "breakout_confirm_dn_threshold": float(
                        breakout_confirm_state.get("dn_threshold", lo_p)
                    ),
                },
                "stop_reason_primary": stop_reason_primary,
                "stop_policy": "DANGER_TO_QUOTE",
                "stop_reason_enum": [str(x) for x in stop_reason_enum_active],
            },
            "update_policy": {
                "exec_candle_check": True,
                "event_driven": True,
                "soft_adjust_max_step_frac": float(self.soft_adjust_max_step_frac),
                "bbwp": {
                    "enabled": bool(self.bbwp_enabled),
                    "s_max": float(gate_bbwp_s_max),
                    "m_max": float(gate_bbwp_m_max),
                    "l_max": float(gate_bbwp_l_max),
                    "nonexp_bars": int(self.bbwp_nonexp_bars),
                    "veto_pct": float(gate_bbwp_veto_pct),
                    "cooloff_trigger_pct": float(gate_bbwp_cooloff_trigger_pct),
                    "cooloff_release_s": float(gate_bbwp_cooloff_release_s),
                    "cooloff_release_m": float(gate_bbwp_cooloff_release_m),
                },
                "squeeze": {
                    "enabled": bool(self.squeeze_enabled),
                    "require_on_1h": bool(self.squeeze_require_on_1h),
                    "momentum_block_enabled": bool(self.squeeze_momentum_block_enabled),
                    "tp_nudge_enabled": bool(self.squeeze_tp_nudge_enabled),
                    "tp_nudge_step_multiple": float(self.squeeze_tp_nudge_step_multiple),
                    "kc_atr_mult": float(self.kc_atr_mult),
                },
                "os_dev": {
                    "enabled": bool(self.os_dev_enabled),
                    "n_strike": int(self.os_dev_n_strike),
                    "range_band": float(self.os_dev_range_band),
                    "persist_bars": int(gate_os_dev_persist_bars),
                    "history_bars": int(self.os_dev_history_bars),
                    "rvol_max": float(gate_os_dev_rvol_max),
                },
                "gating": {
                    "profile": gate_profile,
                    "regime_threshold_profile": str(self._active_threshold_profile()),
                    "active_mode": str(active_mode),
                    "start_min_gate_pass_ratio": float(gate_start_min_pass_ratio_effective),
                    "start_min_gate_pass_ratio_base": float(gate_start_min_pass_ratio),
                    "vol_bucket": str(vol_bucket),
                    "volatility_policy_gate_ratio_delta": float(volatility_gate_ratio_delta),
                    "volatility_strictness_ok": bool(volatility_strictness_ok),
                    "volatility_strictness": dict(volatility_strictness),
                    "adx_4h_max": float(gate_adx_4h_max),
                    "adx_4h_exit_min": float(gate_adx_4h_exit_min),
                    "adx_4h_exit_max": float(gate_adx_4h_exit_max),
                    "adx_rising_bars": int(gate_adx_rising_bars),
                    "bbw_1h_pct_max": float(gate_bbw_1h_pct_max),
                    "bbw_nonexp_lookback_bars": int(gate_bbw_nonexp_lookback_bars),
                    "bbw_nonexp_tolerance_frac": float(gate_bbw_nonexp_tolerance_frac),
                    "ema_dist_max_frac": float(gate_ema_dist_max_frac),
                    "vol_spike_mult": float(gate_vol_spike_mult),
                    "rvol_15m_max": float(gate_rvol_15m_max),
                    "context_7d_hard_veto": bool(gate_context_7d_hard_veto),
                    "atr_source": str(gate_atr_source),
                    "atr_pct_max": float(gate_atr_pct_max),
                    "bbwp_s_enter_low": float(gate_bbwp_s_enter_low),
                    "bbwp_s_enter_high": float(gate_bbwp_s_enter_high),
                    "bbwp_m_enter_low": float(gate_bbwp_m_enter_low),
                    "bbwp_m_enter_high": float(gate_bbwp_m_enter_high),
                    "bbwp_l_enter_low": float(gate_bbwp_l_enter_low),
                    "bbwp_l_enter_high": float(gate_bbwp_l_enter_high),
                    "bbwp_stop_high": float(gate_bbwp_stop_high),
                    "band_slope_pct": float(self.band_slope_veto_pct),
                    "band_slope_bars": int(self.band_slope_veto_bars),
                    "band_slope_enabled": bool(self.band_slope_veto_enabled),
                    "excursion_asymmetry_min_ratio": float(self.excursion_asymmetry_min_ratio),
                    "excursion_asymmetry_max_ratio": float(self.excursion_asymmetry_max_ratio),
                    "excursion_asymmetry_enabled": bool(self.excursion_asymmetry_veto_enabled),
                    "drift_slope_veto_enabled": bool(self.drift_slope_veto_enabled),
                    "funding_filter_enabled": bool(self.funding_filter_enabled),
                    "funding_filter_pct": float(self.funding_filter_pct),
                    "hvp_enabled": bool(self.hvp_enabled),
                    "hvp_lookback_bars": int(self.hvp_lookback_bars),
                    "hvp_sma_bars": int(self.hvp_sma_bars),
                    "hvp_quiet_exit_bias_enabled": bool(self.hvp_quiet_exit_bias_enabled),
                    "hvp_quiet_exit_step_multiple": float(self.hvp_quiet_exit_step_multiple),
                    "planner_health_quarantine_on_gap": bool(self.planner_health_quarantine_on_gap),
                    "planner_health_quarantine_on_misalign": bool(self.planner_health_quarantine_on_misalign),
                    "meta_drift_soft_block_enabled": bool(self.meta_drift_soft_block_enabled),
                    "meta_drift_soft_block_steps": float(self.meta_drift_soft_block_steps),
                    "meta_drift_guard_enabled": bool(self.meta_drift_guard_enabled),
                    "meta_drift_guard_window": int(self.meta_drift_guard_window),
                    "meta_drift_guard_min_samples": int(self.meta_drift_guard_min_samples),
                    "meta_drift_guard_smoothing_alpha": float(self.meta_drift_guard_smoothing_alpha),
                    "meta_drift_guard_z_soft": float(self.meta_drift_guard_z_soft),
                    "meta_drift_guard_z_hard": float(self.meta_drift_guard_z_hard),
                    "meta_drift_guard_cusum_k_sigma": float(self.meta_drift_guard_cusum_k_sigma),
                    "meta_drift_guard_cusum_soft": float(self.meta_drift_guard_cusum_soft),
                    "meta_drift_guard_cusum_hard": float(self.meta_drift_guard_cusum_hard),
                    "meta_drift_guard_ph_delta_sigma": float(self.meta_drift_guard_ph_delta_sigma),
                    "meta_drift_guard_ph_soft": float(self.meta_drift_guard_ph_soft),
                    "meta_drift_guard_ph_hard": float(self.meta_drift_guard_ph_hard),
                    "meta_drift_guard_soft_min_channels": int(self.meta_drift_guard_soft_min_channels),
                    "meta_drift_guard_hard_min_channels": int(self.meta_drift_guard_hard_min_channels),
                    "meta_drift_guard_cooldown_extend_minutes": float(
                        self.meta_drift_guard_cooldown_extend_minutes
                    ),
                    "meta_drift_guard_spread_proxy_scale": float(
                        self.meta_drift_guard_spread_proxy_scale
                    ),
                    "start_stability_min_score": float(self.start_stability_min_score),
                    "start_stability_k_fraction": float(self.start_stability_k_fraction),
                    "start_box_position_guard_enabled": bool(self.start_box_position_guard_enabled),
                    "start_box_position_min_frac": float(self.start_box_position_min_frac),
                    "start_box_position_max_frac": float(self.start_box_position_max_frac),
                    "box_width_avg_veto_enabled": bool(self.box_width_avg_veto_enabled),
                    "box_width_avg_veto_lookback": int(self.box_width_avg_veto_lookback),
                    "box_width_avg_veto_min_samples": int(self.box_width_avg_veto_min_samples),
                    "box_width_avg_veto_max_ratio": float(self.box_width_avg_veto_max_ratio),
                    "min_range_len_bars": int(self.min_range_len_bars),
                    "breakout_confirm_bars": int(self.breakout_confirm_bars),
                    "breakout_confirm_buffer_mode": str(self.breakout_confirm_buffer_mode),
                    "breakout_confirm_buffer_value": float(self.breakout_confirm_buffer_value),
                    "fallback_poc_estimator_enabled": bool(self.fallback_poc_estimator_enabled),
                    "fallback_poc_lookback_bars": int(self.fallback_poc_lookback_bars),
                    "poc_alignment_enabled": bool(self.poc_alignment_enabled),
                    "poc_alignment_strict_enabled": bool(self.poc_alignment_strict_enabled),
                    "poc_alignment_lookback_bars": int(self.poc_alignment_lookback_bars),
                    "poc_alignment_max_step_diff": float(self.poc_alignment_max_step_diff),
                    "poc_alignment_max_width_frac": float(self.poc_alignment_max_width_frac),
                    "basis_cross_confirm_enabled": bool(self.basis_cross_confirm_enabled),
                    "capacity_hint_hard_block": bool(self.capacity_hint_hard_block),
                },
                "volatility_policy": {
                    "enabled": bool(self.n_volatility_adapter_enabled),
                    "strength": float(self.n_volatility_adapter_strength),
                    "vol_bucket": str(vol_bucket),
                    "inputs": dict(volatility_policy.get("inputs", {})),
                    "base": dict(volatility_policy_base),
                    "adapted": dict(volatility_policy_adapted),
                },
                "regime_router": {
                    "enabled": bool(self.regime_router_enabled),
                    "default_mode": self._normalize_mode_name(self.regime_router_default_mode),
                    "force_mode": (
                        self._normalize_mode_name(self.regime_router_force_mode)
                        if str(self.regime_router_force_mode or "").strip()
                        else None
                    ),
                    "threshold_profile": str(self._active_threshold_profile()),
                    "allow_pause": bool(self.regime_router_allow_pause),
                    "switch_persist_bars": int(self.regime_router_switch_persist_bars),
                    "switch_cooldown_bars": int(self.regime_router_switch_cooldown_bars),
                    "switch_margin": float(self.regime_router_switch_margin),
                },
                "intraday": self._mode_threshold_block("intraday"),
                "swing": self._mode_threshold_block("swing"),
                "plan_history": {
                    "per_candle_backtest_enabled": bool(self.emit_per_candle_history_backtest),
                    "per_candle_active": bool(history_mode),
                    "runmode": self._runmode_name(),
                },
                "micro_vap": {
                    "enabled": bool(self.micro_vap_enabled),
                    "lookback_bars": int(self.micro_vap_lookback_bars),
                    "bins": int(self.micro_vap_bins),
                    "hvn_quantile": float(self.micro_hvn_quantile),
                    "lvn_quantile": float(self.micro_lvn_quantile),
                    "extrema_count": int(self.micro_extrema_count),
                    "lvn_corridor_steps": float(self.micro_lvn_corridor_steps),
                    "void_slope_threshold": float(self.micro_void_slope_threshold),
                },
                "fvg": {
                    "enabled": bool(self.fvg_enabled),
                    "lookback_bars": int(self.fvg_lookback_bars),
                    "min_gap_atr": float(self.fvg_min_gap_atr),
                    "straddle_veto_steps": float(self.fvg_straddle_veto_steps),
                    "position_avg_count": int(self.fvg_position_avg_count),
                    "imfvg_enabled": bool(self.imfvg_enabled),
                    "imfvg_mitigated_relax": bool(self.imfvg_mitigated_relax),
                    "defensive_enabled": bool(self.defensive_fvg_enabled),
                    "defensive_min_gap_atr": float(self.defensive_fvg_min_gap_atr),
                    "defensive_body_frac": float(self.defensive_fvg_body_frac),
                    "defensive_fresh_bars": int(self.defensive_fvg_fresh_bars),
                    "session_enabled": bool(self.session_fvg_enabled),
                    "session_inside_gate": bool(self.session_fvg_inside_gate),
                    "session_pause_bars": int(self.session_fvg_pause_bars),
                },
                "mrvd": {
                    "enabled": bool(self.mrvd_enabled),
                    "bins": int(self.mrvd_bins),
                    "value_area_pct": float(self.mrvd_value_area_pct),
                    "day_lookback_bars": int(self.mrvd_day_lookback_bars),
                    "week_lookback_bars": int(self.mrvd_week_lookback_bars),
                    "month_lookback_bars": int(self.mrvd_month_lookback_bars),
                    "required_overlap_count": int(self.mrvd_required_overlap_count),
                    "va_overlap_min_frac": float(self.mrvd_va_overlap_min_frac),
                    "near_poc_steps": float(self.mrvd_near_poc_steps),
                    "drift_guard_enabled": bool(self.mrvd_drift_guard_enabled),
                    "drift_guard_steps": float(self.mrvd_drift_guard_steps),
                },
                "cvd": {
                    "enabled": bool(self.cvd_enabled),
                    "lookback_bars": int(self.cvd_lookback_bars),
                    "pivot_left": int(self.cvd_pivot_left),
                    "pivot_right": int(self.cvd_pivot_right),
                    "divergence_max_age_bars": int(self.cvd_divergence_max_age_bars),
                    "near_value_steps": float(self.cvd_near_value_steps),
                    "bos_lookback": int(self.cvd_bos_lookback),
                    "bos_freeze_bars": int(self.cvd_bos_freeze_bars),
                    "rung_bias_strength": float(self.cvd_rung_bias_strength),
                },
                "ml_overlay": {
                    "enabled": bool(self.freqai_overlay_enabled),
                    "gate_mode": str(ml_gate_mode),
                    "strict_predict": bool(self.freqai_overlay_strict_predict),
                    "confidence_min": float(self.freqai_overlay_confidence_min),
                    "breakout_scale": float(self.freqai_overlay_breakout_scale),
                    "breakout_quick_tp_thresh": float(self.freqai_overlay_breakout_quick_tp_thresh),
                    "rung_edge_cut_max": float(self.freqai_overlay_rung_edge_cut_max),
                },
                "midline_bias": {
                    "enabled": bool(self.midline_bias_fallback_enabled),
                    "tp_candidate_enabled": bool(self.midline_bias_tp_candidate_enabled),
                    "poc_neutral_step_frac": float(self.midline_bias_poc_neutral_step_frac),
                    "poc_neutral_width_frac": float(self.midline_bias_poc_neutral_width_frac),
                    "source_buffer_steps": float(self.midline_bias_source_buffer_steps),
                    "source_buffer_width_frac": float(self.midline_bias_source_buffer_width_frac),
                    "deadband_steps": float(self.midline_bias_deadband_steps),
                    "deadband_width_frac": float(self.midline_bias_deadband_width_frac),
                },
                "rung_bias": {
                    "hvn_boost": float(self.rung_weight_hvn_boost),
                    "lvn_penalty": float(self.rung_weight_lvn_penalty),
                    "weight_min": float(self.rung_weight_min),
                    "weight_max": float(self.rung_weight_max),
                    "buy_ratio_enabled": bool(self.buy_ratio_bias_enabled),
                    "buy_ratio_strength": float(self.buy_ratio_rung_bias_strength),
                },
                "smart_channel": {
                    "enabled": bool(self.smart_channel_enabled),
                    "breakout_step_buffer": float(self.smart_channel_breakout_step_buffer),
                    "volume_confirm_enabled": bool(self.smart_channel_volume_confirm_enabled),
                    "volume_rvol_min": float(self.smart_channel_volume_rvol_min),
                    "tp_nudge_step_multiple": float(self.smart_channel_tp_nudge_step_multiple),
                },
                "order_blocks": {
                    "enabled": bool(self.ob_enabled),
                    "tf": str(self.ob_tf),
                    "use_wick_zone": bool(self.ob_use_wick_zone),
                    "impulse_lookahead": int(self.ob_impulse_lookahead),
                    "impulse_atr_len": int(self.ob_impulse_atr_len),
                    "impulse_atr_mult": float(self.ob_impulse_atr_mult),
                    "fresh_bars": int(self.ob_fresh_bars),
                    "max_age_bars": int(self.ob_max_age_bars),
                    "mitigation_mode": str(self.ob_mitigation_mode),
                    "straddle_min_step_mult": float(self.ob_straddle_min_step_mult),
                    "tp_nudge_max_steps": float(self.ob_tp_nudge_max_steps),
                },
                "session_sweep": {
                    "enabled": bool(self.session_sweep_enabled),
                    "retest_lookback_bars": int(self.session_sweep_retest_lookback_bars),
                    "pivot_len": int(self.sweep_pivot_len),
                    "max_age_bars": int(self.sweep_max_age_bars),
                    "break_buffer_mode": str(self.sweep_break_buffer_mode),
                    "break_buffer_value": float(self.sweep_break_buffer_value),
                    "retest_window_bars": int(self.sweep_retest_window_bars),
                    "retest_buffer_mode": str(self.sweep_retest_buffer_mode),
                    "retest_buffer_value": float(self.sweep_retest_buffer_value),
                    "retest_validation_mode": str(self.sweep_retest_validation_mode),
                    "stop_if_through_box_edge": bool(self.sweep_stop_if_through_box_edge),
                    "min_level_separation_steps": float(self.sweep_min_level_separation_steps),
                },
                "order_flow": {
                    "enabled": bool(self.order_flow_enabled),
                    "spread_soft_max_pct": float(self.order_flow_spread_soft_max_pct),
                    "depth_thin_soft_max": float(self.order_flow_depth_thin_soft_max),
                    "imbalance_extreme": float(self.order_flow_imbalance_extreme),
                    "jump_soft_max_pct": float(self.order_flow_jump_soft_max_pct),
                    "soft_veto_min_flags": int(self.order_flow_soft_veto_min_flags),
                    "hard_block": bool(self.order_flow_hard_block),
                },
                "runtime_controls": {
                    "reclaim_hours": float(self.reclaim_hours),
                    "cooldown_minutes": float(cooldown_minutes_effective),
                    "cooldown_minutes_base": float(self.cooldown_minutes),
                    "min_runtime_hours": float(min_runtime_minutes_effective / 60.0),
                    "min_runtime_hours_base": float(self.min_runtime_hours),
                    "min_runtime_minutes": float(min_runtime_minutes_effective),
                    "min_runtime_secs": int(min_runtime_secs),
                    "drawdown_guard_enabled": bool(self.drawdown_guard_enabled),
                    "drawdown_guard_lookback_bars": int(self.drawdown_guard_lookback_bars),
                    "drawdown_guard_max_pct": float(self.drawdown_guard_max_pct),
                    "max_stops_window_enabled": bool(self.max_stops_window_enabled),
                    "max_stops_window_minutes": float(self.max_stops_window_minutes),
                    "max_stops_window_count": int(self.max_stops_window_count),
                    "micro_reentry_pause_bars": int(self.micro_reentry_pause_bars),
                    "breakout_idle_reclaim_on_fresh": bool(self.breakout_idle_reclaim_on_fresh),
                },
                "cost_model": {
                    "target_net_step_pct": float(cost_floor.get("target_net_step_pct", self.target_net_step_pct)),
                    "static_floor_pct": float(static_gross_min),
                    "chosen_floor_base_pct": float(min_step_pct_required_base),
                    "chosen_floor_pct": float(min_step_pct_required),
                    "min_step_buffer_bps": float(min_step_buffer_bps_effective),
                    "source": str(cost_floor.get("source", "static")),
                    "selection_reason": str(cost_floor.get("selection_reason", "unknown")),
                    "empirical_enabled": bool(self.empirical_cost_enabled),
                    "empirical_conservative_mode": bool(self.empirical_cost_conservative_mode),
                    "empirical_window": int(self.empirical_cost_window),
                    "empirical_percentile": float(self.empirical_cost_percentile),
                    "empirical_min_samples": int(self.empirical_cost_min_samples),
                    "empirical_stale_bars": int(self.empirical_cost_stale_bars),
                    "empirical_require_live_samples": bool(self.empirical_cost_require_live_samples),
                    "empirical_min_live_samples": int(
                        self._safe_float(getattr(self, "empirical_cost_min_live_samples", 0.0)) or 0
                    ),
                },
                "fill_detection": {
                    "mode": str(self.fill_confirmation_mode),
                    "no_repeat_lsi_guard": bool(self.fill_no_repeat_lsi_guard),
                    "cooldown_bars": int(self.fill_no_repeat_cooldown_bars),
                    "tick_size": float(self._infer_tick_size(step_price)),
                },
            },
            "runtime_state": {
                "clock_ts": int(clock_ts),
                "clock_time_utc": self._ts_to_iso(int(clock_ts)),
                "active_mode": str(active_mode),
                "running": bool(running_now),
                "running_mode": (
                    self._normalize_mode_name(self._running_mode_by_pair.get(pair))
                    if bool(running_now)
                    else None
                ),
                "mode_at_entry": self._mode_at_entry_by_pair.get(pair),
                "mode_at_exit": self._mode_at_exit_by_pair.get(pair),
                "active_since_ts": int(active_since_ts) if active_since_ts is not None else None,
                "active_since_utc": self._ts_to_iso(int(active_since_ts)) if active_since_ts is not None else None,
                "runtime_secs": int(runtime_secs) if runtime_secs is not None else None,
                "reclaim_until_ts": int(reclaim_until_ts) if reclaim_until_ts else None,
                "reclaim_until_utc": self._ts_to_iso(int(reclaim_until_ts)) if reclaim_until_ts else None,
                "reclaim_active": bool(reclaim_active_now),
                "cooldown_until_ts": int(cooldown_until_ts) if cooldown_until_ts else None,
                "cooldown_until_utc": self._ts_to_iso(int(cooldown_until_ts)) if cooldown_until_ts else None,
                "cooldown_active": bool(cooldown_active_now),
                "router_target_mode": router_state.get("target_mode"),
                "router_target_reason": router_state.get("target_reason"),
                "router_desired_mode": router_state.get("desired_mode"),
                "router_desired_reason": router_state.get("desired_reason"),
                "router_switched": bool(router_state.get("switched", False)),
                "planner_health_state": str(planner_health_state),
                "planner_health_ok": bool(planner_health_ok),
                "start_signal": bool(start_signal),
                "start_blocked": bool(start_blocked),
                "start_stability_score": float(start_stability.get("score", 0.0)),
                "start_stability_ok": bool(start_stability_ok),
                "start_block_reasons": [str(x) for x in start_block_reasons],
                "start_filters": dict(start_filter_states),
                "midline_bias": dict(midline_bias),
                "meta_drift_detected": bool(meta_drift_state.get("drift_detected", False)),
                "meta_drift_severity": str(meta_drift_state.get("severity", "none")),
                "meta_drift_recommended_action": str(meta_drift_recommended_action),
                "meta_drift_channels": [str(x) for x in meta_drift_state.get("drift_channels", [])],
                "meta_drift_hard_stop": bool(meta_drift_hard_stop),
                "meta_drift_cooldown_extended": bool(meta_drift_cooldown_extended),
                "warning_codes": warning_codes,
                "structured_events": list(structured_event_types),
                "vol_bucket": str(vol_bucket),
                "volatility_policy": dict(volatility_policy),
                "order_flow": dict(order_flow_state),
                "drawdown_guard": dict(drawdown_state),
                "max_stops_window": dict(max_stops_window_state),
                "micro_reentry": dict(micro_reentry_state),
                "stop_reason_flags_raw_active": [str(x) for x in stop_reason_flags_raw_active],
                "stop_reason_flags_applied_active": [str(x) for x in stop_reason_flags_applied_active],
                "neutral_runtime": {
                    "enter_persist_bars": int(neutral_enter_persist),
                    "exit_persist_bars": int(neutral_exit_persist),
                    "cooldown_multiplier": float(neutral_cooldown_multiplier),
                    "min_runtime_offset_secs": int(neutral_min_runtime_offset_secs),
                    "cooldown_secs_base": int(cooldown_base_secs_raw),
                    "cooldown_secs_adapted": int(cooldown_base_secs),
                    "cooldown_secs_effective": int(cooldown_secs),
                    "min_runtime_secs_base": int(min_runtime_base_secs_raw),
                    "min_runtime_secs_adapted": int(min_runtime_base_secs),
                    "min_runtime_secs_effective": int(min_runtime_secs),
                },
            },
            "diagnostics": {
                "active_mode": str(active_mode),
                "mode_pause": bool(mode_pause),
                "planner_health_state": str(planner_health_state),
                "planner_health_ok": bool(planner_health_ok),
                "start_gate_ok": bool(start_gate_ok),
                "start_stability_score": float(start_stability.get("score", 0.0)),
                "start_stability_ok": bool(start_stability_ok),
                "price_in_box": bool(price_in_box),
                "rsi_ok": bool(rsi_ok),
                "start_signal": bool(start_signal),
                "start_blocked": bool(start_blocked),
                "start_block_reasons": [str(x) for x in start_block_reasons],
                "start_filters": dict(start_filter_states),
                "midline_bias": dict(midline_bias),
                "meta_drift_detected": bool(meta_drift_state.get("drift_detected", False)),
                "meta_drift_severity": str(meta_drift_state.get("severity", "none")),
                "meta_drift_recommended_action": str(meta_drift_recommended_action),
                "meta_drift_channels": [str(x) for x in meta_drift_state.get("drift_channels", [])],
                "meta_drift_hard_stop": bool(meta_drift_hard_stop),
                "meta_drift_cooldown_extended": bool(meta_drift_cooldown_extended),
                "warning_codes": warning_codes,
                "structured_events": list(structured_event_types),
                "order_flow": dict(order_flow_state),
                "drawdown_guard": dict(drawdown_state),
                "max_stops_window": dict(max_stops_window_state),
                "micro_reentry": dict(micro_reentry_state),
                "zigzag_contraction": dict(zigzag_contraction_state),
                "stop_rule_triggered": bool(stop_rule),
                "stop_rule_triggered_raw": bool(raw_stop_rule),
                "stop_reason_flags_raw_active": [str(x) for x in stop_reason_flags_raw_active],
                "stop_reason_flags_applied_active": [str(x) for x in stop_reason_flags_applied_active],
                "router_target_mode": router_state.get("target_mode"),
                "router_target_reason": router_state.get("target_reason"),
                "router_desired_mode": router_state.get("desired_mode"),
                "router_desired_reason": router_state.get("desired_reason"),
                "router_switched": bool(router_state.get("switched", False)),
            },
            "meta_drift": {
                "enabled": bool(meta_drift_state.get("enabled", False)),
                "drift_detected": bool(meta_drift_state.get("drift_detected", False)),
                "severity": str(meta_drift_state.get("severity", "none")),
                "recommended_action": str(meta_drift_recommended_action),
                "drift_channels": [str(x) for x in meta_drift_state.get("drift_channels", [])],
                "soft_channels": [str(x) for x in meta_drift_state.get("soft_channels", [])],
                "hard_channels": [str(x) for x in meta_drift_state.get("hard_channels", [])],
                "soft_block": bool(meta_drift_state.get("soft_block", False)),
                "hard_stop": bool(meta_drift_hard_stop),
                "cooldown_extended": bool(meta_drift_cooldown_extended),
                "cooldown_extend_minutes": float(self.meta_drift_guard_cooldown_extend_minutes),
                "bars_seen": int(meta_drift_state.get("bars_seen", 0)),
                "ready_channels": [str(x) for x in meta_drift_state.get("ready_channels", [])],
                "min_samples": int(meta_drift_state.get("min_samples", 0)),
                "channels_input": meta_drift_state.get("channels_input", {}),
                "channels": meta_drift_state.get("channels", {}),
            },
            "capital_policy": {
                "mode": "QUOTE_ONLY",
                "inventory_mode": str(self.inventory_mode),
                "grid_budget_pct": float(grid_budget_pct_effective),
                "reserve_pct": float(self.reserve_pct),
                "inventory_target_bands": {
                    "base_min_pct": float(self.inventory_target_base_min_pct),
                    "base_max_pct": float(self.inventory_target_base_max_pct),
                },
                "topup_policy": str(self.topup_policy),
                "max_concurrent_rebuilds": int(
                    capacity_hint.get("max_concurrent_rebuilds")
                    if capacity_hint.get("max_concurrent_rebuilds") is not None
                    else self.max_concurrent_rebuilds
                ),
                "preferred_rung_cap": int(
                    capacity_hint.get("preferred_rung_cap")
                    if capacity_hint.get("preferred_rung_cap") is not None
                    else self.preferred_rung_cap
                ),
            },
            "notes": {
                "brain_mode": "deterministic_v1",
                "ml": "freqai_confidence_overlay_v1",
                "expect_0_trades_in_freqtrade": True,
            },
        }

        mode_scores_raw = router_state.get("scores", {})
        mode_scores = mode_scores_raw if isinstance(mode_scores_raw, dict) else {}
        mode_score = self._safe_float(mode_scores.get(str(active_mode)))
        materiality_class = str(materiality_info.get("class", MaterialityClass.NOOP))
        replan_reasons = [str(x) for x in materiality_info.get("reasons", [])]
        replan_decision = "publish" if bool(materiality_info.get("publish", False)) else "defer"
        valid_for_candle_ts = int(candle_ts) if candle_ts is not None else int(clock_ts)
        expires_at = None
        if int(self.plan_expiry_seconds) > 0:
            expires_at = self._ts_to_iso(valid_for_candle_ts + int(self.plan_expiry_seconds))

        if action == "STOP":
            action_reason = str(stop_reason_primary or "STOP_RULE_TRIGGERED")
        elif action == "START":
            action_reason = "START_GATES_PASSED"
        else:
            action_reason = str(start_block_reasons[0]) if start_block_reasons else "HOLD_NO_ACTION"

        plan["schema_version"] = str(self.plan_schema_version)
        plan["planner_version"] = str(self.planner_version)
        plan["pair"] = str(pair)
        plan["mode_score"] = mode_score
        plan["action_reason"] = action_reason
        plan["blockers"] = [str(x) for x in start_block_reasons]
        plan["planner_health_state"] = str(planner_health_state)
        plan["materiality_class"] = materiality_class
        plan["replan_decision"] = replan_decision
        plan["replan_reasons"] = replan_reasons
        plan["generated_at"] = str(ts)
        plan["valid_for_candle_ts"] = int(valid_for_candle_ts)
        plan["expires_at"] = expires_at
        plan["supersedes_plan_id"] = None
        plan["range_diagnostics"] = {
            "lookback_bars_used": int(used_lb),
            "pad": float(pad),
            "box_block_reasons": [str(x) for x in box_block_reasons],
            "width_avg_veto": dict(width_avg_state),
            "poc_alignment": dict(poc_alignment),
            "vrvp_source": str(active_vrvp_source),
            "vrvp_fallback_used": bool(active_fallback_used),
            "quartile_space": str(quartile_space),
            "extension_factor": float(extension_factor),
            "extension_1386": {
                "lo": float(ext_lo),
                "hi": float(ext_hi),
            },
            "midline_bias": dict(midline_bias),
            "breakout_fresh_block_active": bool(breakout_fresh_block_active),
            "breakout_levels": {
                "up": float(breakout_up_level),
                "dn": float(breakout_dn_level),
            },
            "zigzag_contraction": dict(zigzag_contraction_state),
            "order_blocks": dict(order_block_state),
            "session_sweep": dict(session_sweep_state),
            "smart_channel": dict(smart_channel_state),
        }
        plan["box"] = {
            "low": float(lo_p),
            "high": float(hi_p),
            "mid": float(mid),
            "width_pct": float(width_pct),
            "lookback_bars_used": int(used_lb),
            "pad": float(pad),
            "quartiles": {"q1": float(q1), "q2": float(q2), "q3": float(q3)},
            "extensions": {
                "x1386_lo": float(ext_lo),
                "x1386_hi": float(ext_hi),
                "space": str(quartile_space),
                "factor": float(extension_factor),
            },
        }
        plan["signals_snapshot"] = dict(plan.get("signals", {}))
        plan["runtime_hints"] = {
            "clock_ts": int(clock_ts),
            "clock_time_utc": self._ts_to_iso(int(clock_ts)),
            "running": bool(running_now),
            "running_mode": (
                self._normalize_mode_name(self._running_mode_by_pair.get(pair))
                if bool(running_now)
                else None
            ),
            "reclaim_active": bool(reclaim_active_now),
            "cooldown_active": bool(cooldown_active_now),
            "router_target_mode": router_state.get("target_mode"),
            "router_desired_mode": router_state.get("desired_mode"),
            "capacity_hint": dict(capacity_hint),
            "vol_bucket": str(vol_bucket),
            "order_flow": dict(order_flow_state),
            "max_stops_window": dict(max_stops_window_state),
            "micro_reentry": dict(micro_reentry_state),
            "volatility_policy": {
                "base": dict(volatility_policy_base),
                "adapted": dict(volatility_policy_adapted),
            },
        }
        plan["event_signals"] = {
            "types": list(structured_event_types),
            "metadata": dict(structured_event_metadata),
        }
        plan["start_stability_score"] = float(start_stability.get("score", 0.0))
        plan["meta_drift_state"] = {
            "detected": bool(meta_drift_state.get("drift_detected", False)),
            "severity": str(meta_drift_state.get("severity", "none")),
            "recommended_action": str(meta_drift_recommended_action),
            "channels": [str(x) for x in meta_drift_state.get("drift_channels", [])],
            "hard_stop": bool(meta_drift_hard_stop),
            "cooldown_extended": bool(meta_drift_cooldown_extended),
        }
        plan["cost_model_snapshot"] = {
            "source": str(cost_floor.get("source", "static")),
            "selection_reason": str(cost_floor.get("selection_reason", "unknown")),
            "target_net_step_pct": float(cost_floor.get("target_net_step_pct", self.target_net_step_pct)),
            "static_floor_pct": float(static_gross_min),
            "chosen_floor_base_pct": float(min_step_pct_required_base),
            "chosen_floor_pct": float(min_step_pct_required),
            "min_step_buffer_bps": float(min_step_buffer_bps_effective),
            "step_pct_actual": float(step_pct_actual),
            "empirical_snapshot": cost_floor.get("empirical_snapshot", {}),
            "empirical_sample": cost_floor.get("empirical_sample", {}),
        }
        plan["module_states"] = {
            "cost_model": {
                "source": str(cost_floor.get("source", "static")),
                "selection_reason": str(cost_floor.get("selection_reason", "unknown")),
            },
            "start_stability": {"ok": bool(start_stability_ok)},
            "planner_health": {"state": str(planner_health_state)},
            "meta_drift_guard": {"enabled": bool(self.meta_drift_guard_enabled)},
            "volatility_policy_adapter": {
                "enabled": bool(self.n_volatility_adapter_enabled),
                "vol_bucket": str(vol_bucket),
                "base": dict(volatility_policy_base),
                "adapted": dict(volatility_policy_adapted),
            },
            "poc_acceptance_gate": {"enabled": bool(self.poc_acceptance_enabled)},
            "fill_detection": {
                "mode": str(self.fill_confirmation_mode),
                "no_repeat_lsi_guard": bool(self.fill_no_repeat_lsi_guard),
                "cooldown_bars": int(self.fill_no_repeat_cooldown_bars),
            },
            "protections": {
                "drawdown_guard_enabled": bool(self.drawdown_guard_enabled),
                "max_stops_window_enabled": bool(self.max_stops_window_enabled),
            },
            "structured_event_bus": {
                "enabled": True,
                "event_count": int(len(structured_event_types)),
            },
            "fvg_vp": {"enabled": bool(self.fvg_vp_enabled)},
            "smart_channel": {"enabled": bool(self.smart_channel_enabled)},
            "order_blocks": {
                "enabled": bool(self.ob_enabled),
                "fresh_block": bool(order_block_state.get("fresh_block", False)),
                "straddle_veto": bool(order_block_state.get("straddle_veto", False)),
            },
            "session_sweep": {
                "enabled": bool(self.session_sweep_enabled and self.sweeps_enabled),
                "retest_validation_mode": str(self.sweep_retest_validation_mode),
            },
            "buy_ratio_bias": {"enabled": bool(self.buy_ratio_bias_enabled)},
            "order_flow_metrics": {"enabled": bool(self.order_flow_enabled)},
        }
        prev_material_plan = self._last_material_plan_payload_by_pair.get(pair)
        max_changed_fields = max(int(self.decision_event_log_max_changed_fields), 1)
        changed_fields_all = material_plan_changed_fields(prev_material_plan, plan)
        changed_fields = changed_fields_all[:max_changed_fields]
        if len(changed_fields_all) > max_changed_fields:
            plan["plan_diff_truncated_fields"] = int(len(changed_fields_all) - max_changed_fields)
        plan["changed_fields"] = [str(x) for x in changed_fields]
        plan_diff_snapshot = material_plan_diff_snapshot(
            prev_material_plan,
            plan,
            max_fields=max_changed_fields,
        )
        if plan_diff_snapshot:
            plan["plan_diff_snapshot"] = plan_diff_snapshot

        base_plan_hash = compute_plan_hash(plan)
        last_base_hash = self._last_plan_base_hash_by_pair.get(pair)
        base_hash_changed = bool(last_base_hash is None or (base_plan_hash != last_base_hash))
        prev_plan_hash = self._last_plan_hash_by_pair.get(pair)
        event_ids_emitted = self._emit_decision_and_event_logs(
            ex_name,
            pair,
            plan,
            prev_plan_hash=prev_plan_hash,
            new_plan_hash=base_plan_hash,
            changed_fields=changed_fields,
            diff_snapshot=plan_diff_snapshot,
            mode_candidate=str(router_state.get("desired_mode") or active_mode),
            mode_final=str(active_mode),
            start_stability=start_stability,
            meta_drift_state=meta_drift_state,
            planner_health_state=str(planner_health_state),
            blocker_codes=[str(x) for x in start_block_reasons],
            warning_codes=[str(x) for x in warning_codes],
            stop_codes=[str(x) for x in stop_reason_flags_applied_active],
            close_price=float(close),
            event_types=list(structured_event_types),
            event_metadata=dict(structured_event_metadata),
        )
        if event_ids_emitted:
            plan["event_ids_emitted"] = list(event_ids_emitted)

        # Write plan once per base candle timestamp
        if base_hash_changed and bool(materiality_info.get("publish", False)):
            should_write = False
            if candle_ts is not None:
                last_written = self._last_written_ts_by_pair.get(pair)
                if last_written != candle_ts:
                    should_write = True
            else:
                should_write = True
            if should_write:
                plan_id, decision_seq, supersedes_plan_id = self._next_plan_identity(ex_name, pair)
                plan["plan_id"] = str(plan_id)
                plan["decision_seq"] = int(decision_seq)
                plan["plan_hash"] = str(base_plan_hash)
                plan["generated_at"] = datetime.now(timezone.utc).isoformat()
                plan["supersedes_plan_id"] = supersedes_plan_id
                plan_guard_decision_count = int(self._plan_guard_decision_count_by_pair.get(pair, 0) + 1)
                self._plan_guard_decision_count_by_pair[pair] = plan_guard_decision_count
                plan["plan_guard"] = {
                    "decision_count": int(plan_guard_decision_count),
                    "base_plan_hash": base_plan_hash,
                }
                if candle_ts is not None:
                    self._write_plan(ex_name, pair, plan, base_plan_hash=base_plan_hash)
                    self._last_written_ts_by_pair[pair] = candle_ts
                else:
                    self._write_plan(ex_name, pair, plan, base_plan_hash=base_plan_hash)

        # Cache mid for shift detection next candle
        self._last_mid_by_pair[pair] = float(mid)
        self._last_box_step_by_pair[pair] = float(step_price)
        self._last_width_pct_by_pair[pair] = float(width_pct)
        self._last_tp_price_by_pair[pair] = float(tp_price_plan)
        self._last_sl_price_by_pair[pair] = float(sl_price)

        return dataframe

    # ========= Trading signals intentionally disabled =========
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["enter_long"] = 0
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["exit_long"] = 0
        return dataframe


class GridBrainV1(GridBrainV1Core):
    """Legacy alias for GridBrainV1Core to keep imports stable."""
    pass
